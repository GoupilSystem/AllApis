﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Hosting;

namespace BirkKodeverkAPI.UnitTests
{

    public class CustomWebApplicationFactoryTest<TProgram>
    : WebApplicationFactory<TProgram> where TProgram : class
    {
        private readonly string _environment = "Development";

        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {

            //olesj: If we need to have custom settings for integrationtests, then this file can be configured
            //to have different values than configuration in Program-file. But for now this is sufficient

            //Ref: https://learn.microsoft.com/en-us/aspnet/core/test/integration-tests?view=aspnetcore-7.0 


            builder.UseEnvironment(_environment);
        }

    }
}