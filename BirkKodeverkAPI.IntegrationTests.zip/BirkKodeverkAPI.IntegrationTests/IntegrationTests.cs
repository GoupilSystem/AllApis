﻿
using BirkKodeverkAPI.Api.Dtos;
using BirkKodeverkAPI.Api.Models;
using BirkKodeverkAPI.UnitTests;
using Newtonsoft.Json;
using System.Net;

namespace BirkKodeverkAPI.IntegrationTests;

public class IntegrationTests : IClassFixture<CustomWebApplicationFactoryTest<Program>>
{
    private readonly CustomWebApplicationFactoryTest<Program> _factory;
    private readonly HttpClient _client;

    public IntegrationTests(CustomWebApplicationFactoryTest<Program> factory)
    {
        _factory = factory;
        _client = _factory.CreateClient();
    }

    [Fact]
    public async Task Barneverntjenestes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/barneverntjenestes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();

        Assert.NotNull(jsonResponse);

        var barneverntjenestes = JsonConvert.DeserializeObject<List<BarneverntjenesteDto>>(jsonResponse);
        Assert.NotEmpty(barneverntjenestes);
    }

    [Fact]
    public async Task BarneverntjenestesByKommunenavn_ReturnsOK_Test()
    {
        // Act
        var kommunenavn = "Halden";
        var response = await _client.GetAsync($"/barneverntjenestesbykommunenavn?kommunenavn={kommunenavn}");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();

        Assert.NotNull(jsonResponse);

        var barneverntjenestesbykommunenavn = JsonConvert.DeserializeObject<List<BarneverntjenesteDto>>(jsonResponse);
        Assert.NotEmpty(barneverntjenestesbykommunenavn);
        Assert.True(barneverntjenestesbykommunenavn[0].Kommunenavn.Trim().ToLower() == kommunenavn.Trim().ToLower());
    }

    [Fact]
    public async Task BarnTypes_ReturnsOK_Test()
    {        
        // Act
        var response = await _client.GetAsync("/barntypes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        
        Assert.NotNull(jsonResponse);

        var barnTypes = JsonConvert.DeserializeObject<List<BarnTypeDto>>(jsonResponse);
        Assert.NotEmpty(barnTypes);
    }

    [Fact]
    public async Task BestillingnAarsakTypes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/bestillingnaarsaktypes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var bestillingnAarsakTypes = JsonConvert.DeserializeObject<List<BestillingnAarsakTypeDto>>(jsonResponse);
        Assert.NotEmpty(bestillingnAarsakTypes);
    }

    [Fact]
    public async Task BestillingTypes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/bestillingtypes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);
        
        var bestillingTypes = JsonConvert.DeserializeObject<List<BestillingTypeDto>>(jsonResponse);
        Assert.NotEmpty(bestillingTypes);
    }

    [Fact]
    public async Task BistandTypes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/bistandtypes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var bistandTypes = JsonConvert.DeserializeObject<List<BistandTypeDto>>(jsonResponse);
        Assert.NotEmpty(bistandTypes);
    }

    [Fact]
    public async Task HjemmelTypes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/hjemmeltypes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var hjemmelTypes = JsonConvert.DeserializeObject<List<HjemmelTypeDto>>(jsonResponse);
        Assert.NotEmpty(hjemmelTypes);
    }

    [Fact]
    public async Task Kommunes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/kommunes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var kommunes = JsonConvert.DeserializeObject<List<KommuneDto>>(jsonResponse);
        Assert.NotEmpty(kommunes);
    }

    [Fact]
    public async Task KommuneByKommunePk_ReturnsCorrectResponse()
    {
        // Act
        int kommunePk = 867;
        var response = await _client.GetAsync($"/kommunebykommunepk?kommunepk={kommunePk}");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var kommune = JsonConvert.DeserializeObject<KommuneDto>(jsonResponse);
        Assert.True(kommune.Pk == kommunePk);
    }

    [Fact]
    public async Task KommuneByKommunenavn_ReturnsCorrectResponse()
    {
        // Act
        var kommunenavn = "Halden";
        var response = await _client.GetAsync($"/kommunebykommunenavn?kommunenavn={kommunenavn}");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var kommune = JsonConvert.DeserializeObject<KommuneDto>(jsonResponse);
        Assert.True(kommune.Navn.Trim().ToLower() == kommunenavn.Trim().ToLower());
    }

    [Fact]
    public async Task KommuneByKommunenunmmer_ReturnsCorrectResponse()
    {
        // Act
        var kommunenummer = "0101";
        var response = await _client.GetAsync($"/kommunebykommunenummer?kommunenummer={kommunenummer}");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var kommune = JsonConvert.DeserializeObject<KommuneDto>(jsonResponse);
        Assert.True(kommune.Nummer.Trim().ToLower() == kommunenummer.Trim().ToLower());
    }

    [Fact]
    public async Task VedtakFattetAvnHjemmels_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/vedtakfattetavnhjemmels");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var vedtakFattetAvnHjemmels = JsonConvert.DeserializeObject<List<VedtakFattetAvnHjemmelDto>>(jsonResponse);
        Assert.NotEmpty(vedtakFattetAvnHjemmels);
    }

    [Fact]
    public async Task Vedtakfattetavtypes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/vedtakfattetavtypes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var vedtakFattetAvTypes = JsonConvert.DeserializeObject<List<VedtakFattetAvTypeDto>>(jsonResponse);
        Assert.NotEmpty(vedtakFattetAvTypes);
    }

    [Fact]
    public async Task Vedtakomtypes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/vedtakomtypes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var vedtakOmTypes = JsonConvert.DeserializeObject<List<VedtakOmTypeDto>>(jsonResponse);
        Assert.NotEmpty(vedtakOmTypes);
    }

    [Fact]
    public async Task AarsakTypes_ReturnsOK_Test()
    {
        // Act
        var response = await _client.GetAsync("/aarsaktypes");

        // Assert
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var jsonResponse = await response.Content.ReadAsStringAsync();
        Assert.NotNull(jsonResponse);

        var aarsakTypes = JsonConvert.DeserializeObject<List<AarsakTypeDto>>(jsonResponse);
        Assert.NotEmpty(aarsakTypes);
    }

}
