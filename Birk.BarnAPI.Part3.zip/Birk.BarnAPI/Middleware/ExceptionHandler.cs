﻿using Birk.BarnAPI.Dto;
using System.Data.Common;
using System.Net;

namespace Birk.BarnAPI.Web.Middleware
{
    public class ExceptionHandler : IMiddleware
    {
        private readonly ILogger<ExceptionHandler> _logger;

        public ExceptionHandler(ILogger<ExceptionHandler> logger)
        {
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            string message;
            switch (exception)
            {
                case DbException:
                    _logger.LogError(exception, exception.Message);
                    message = "Et problem oppstod under kall til databasen.";
                    break;
                default:
                    _logger.LogError(exception, exception.Message);
                    message = "En ukjent feil har oppstått.";
                    break;
            }

            return context.Response.WriteAsync(new ErrorDto
            {
                StatusCode = context.Response.StatusCode,
                Message = message
            }.ToString());
        }
    }
}
