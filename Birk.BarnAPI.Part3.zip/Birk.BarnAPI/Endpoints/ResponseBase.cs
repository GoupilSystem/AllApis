﻿using Ardalis.Result;

namespace Birk.BarnAPI.Web.Endpoints
{
    public class ResponseBase
    {
        public string ErrorMessage { get; set; }

        protected ResponseBase()
        {
        }

        protected ResponseBase(ResultStatus status)
        {
            ErrorMessage = $"An error occurred with status {status}";
        }
    }
}
