﻿using Ardalis.ApiEndpoints;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Dto.Validation;
using FluentValidation;
using FluentValidation.Results;
using Ardalis.Result.FluentValidation;
using Ardalis.Result;
using Ardalis.Result.AspNetCore;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByFnr : EndpointBaseAsync
      .WithRequest<GetBarnByFnrRequest>
      .WithActionResult<GetBarnByFnrResponse>
    {
        private readonly IBarnQueryService _searchService;
        private IValidator<GenericArgument> _validator;
        private readonly ILogger<GetBarnByFnr> _logger;

        // Register dependencies in Infrastrcutre.DefaultInfrastructureModule
        public GetBarnByFnr(IBarnQueryService searchService, IValidator<GenericArgument> validator, ILogger<GetBarnByFnr> logger)
        {
            _searchService = searchService;
            _validator = validator;
            _logger = logger;
        }

        [HttpGet(GetBarnByFnrRequest.Route)]
        [SwaggerOperation(
          Summary = "Gets a single barn by et 11-siffret fødselsnummer",
          Description = "Gets a single barn by et 11-siffret fødselsnummer",
          OperationId = "Barn.GetBarnByFnr",
          Tags = new[] { "BarnEndpoints" })
        ]
        public override async Task<ActionResult<GetBarnByFnrResponse>> HandleAsync([FromRoute] GetBarnByFnrRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(GetBarnByFnr));

            ValidationResult validationResult = await _validator.ValidateAsync(
                new GenericArgument(ValidationType.Fnr, request.Fnr));

            if (!validationResult.IsValid)
            {
                return Result<GetBarnByFnrResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            var result = await _searchService.GetBarnByFnr(request.Fnr);

            return result
                .Map(value => value == null
                    ? new GetBarnByFnrResponse(result.Status)
                    : new GetBarnByFnrResponse(BarnMapper.ToDto(value)))
                .ToActionResult(this);
        }
    }
}
