﻿using Ardalis.ApiEndpoints;
using Ardalis.Result.FluentValidation;
using Ardalis.Result;
using Ardalis.Result.AspNetCore;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using FluentValidation;
using Birk.BarnAPI.Dto;
using FluentValidation.Results;
using Birk.BarnAPI.Core.Interfaces;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{

    public class AddOrUpdateBarnWithPlan : EndpointBaseAsync
    .WithRequest<UpdateBarnWithPlanRequest>
    .WithActionResult<UpdateBarnWithPlanResponse>
    {
        private readonly IBarnCommandService _barnCommandService;
        private readonly IBarnQueryService _searchService;
        private IValidator<IndividuellHelsePlanDto> _validator;
        private readonly ILogger<AddOrUpdateBarnWithPlan> _logger;

        // Register dependencies in Infrastrcutre.DefaultInfrastructureModule
        public AddOrUpdateBarnWithPlan(
            IBarnCommandService barnCommandService,
            IBarnQueryService searchService,
            IValidator<IndividuellHelsePlanDto> validator,
            ILogger<AddOrUpdateBarnWithPlan> logger)
        {
            _barnCommandService = barnCommandService;
            _searchService = searchService;
            _validator = validator;
            _logger = logger;
        }

        [HttpPost(UpdateBarnWithPlanRequest.Route)]
        [SwaggerOperation(
          Summary = "Adds or updates a barn with an individuell helse plan",
          Description = "Adds or updates a barn entity with an associated individuell helse plan",
          OperationId = "Barn.AddOrUpdateBarnWithPlan",
          Tags = new[] { "BarnEndpoints" })
        ]
        public override async Task<ActionResult<UpdateBarnWithPlanResponse>> HandleAsync([FromBody] UpdateBarnWithPlanRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(AddOrUpdateBarnWithPlan));

            var planDto = request.PlanDto;

            ValidationResult validationResult = await _validator.ValidateAsync(planDto);

            if (!validationResult.IsValid)
            {
                return Result<UpdateBarnWithPlanResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            var updateResult = await _barnCommandService.AddOrUpdateHelsePlan(IndividuellHelsePlanMapper.ToEntity(planDto), request.CanUpdate, cancellationToken);

            // updateResult is type Ardalis.Result<Barn>, we need to map it as UpdateBarnWithPlanResponse
            return updateResult
                .Map(value => value == null
                    ? new UpdateBarnWithPlanResponse(updateResult.Status)
                    : new UpdateBarnWithPlanResponse(BarnMapper.ToDto(value)))
                .ToActionResult(this);
        }
    }
}