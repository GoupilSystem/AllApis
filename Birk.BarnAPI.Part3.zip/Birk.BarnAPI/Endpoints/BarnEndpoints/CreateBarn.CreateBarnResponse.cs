﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class CreateBarnResponse : ResponseBase
    {
        public CreateBarnResponse(BarnDto barnDto, PersonDto barnSomEnPersonDto)
        {
            BarnDto = barnDto;
            BarnSomEnPersonDto = barnSomEnPersonDto;
        }

        public CreateBarnResponse(ResultStatus status) : base(status)
        {
        }

        public CreateBarnResponse()
        {
        }

        public BarnDto BarnDto { get; set; }
        public PersonDto BarnSomEnPersonDto { get; set; }
    }
}
