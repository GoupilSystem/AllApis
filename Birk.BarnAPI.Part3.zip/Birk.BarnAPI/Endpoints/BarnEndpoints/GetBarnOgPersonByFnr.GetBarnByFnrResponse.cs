﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnOgPersonByFnrResponse : ResponseBase
    {
        public GetBarnOgPersonByFnrResponse(BarnOgPersonDto barnOgPersonDto)
        {
            BarnOgPersonDto = barnOgPersonDto;
        }

        public GetBarnOgPersonByFnrResponse(ResultStatus status) : base(status)
        {
        }

        public GetBarnOgPersonByFnrResponse()
        {
        }

        public BarnOgPersonDto BarnOgPersonDto { get; set; }
    }
}
