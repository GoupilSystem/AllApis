﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByPkResponse : ResponseBase
    {
        public GetBarnByPkResponse(BarnDto barnDto)
        {
            BarnDto = barnDto;
        }

        public GetBarnByPkResponse(ResultStatus status) : base(status)
        {
        }

        public GetBarnByPkResponse()
        {
        }

        public BarnDto BarnDto { get; set; }
    }
}
