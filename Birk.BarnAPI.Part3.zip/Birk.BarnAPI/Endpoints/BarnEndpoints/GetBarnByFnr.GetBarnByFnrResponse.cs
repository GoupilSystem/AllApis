﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByFnrResponse : ResponseBase
    {
        public GetBarnByFnrResponse(BarnDto barnDto)
        {
            BarnDto = barnDto;
        }

        public GetBarnByFnrResponse(ResultStatus status) : base(status)
        {
        }

        public GetBarnByFnrResponse()
        {
        }

        public BarnDto BarnDto { get; set; }
    }
}
