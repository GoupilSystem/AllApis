﻿namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByPkRequest
    {
        public const string Route = "/Barn/{Pk:int}";
        public static string BuildRoute(int pk) => Route.Replace("{Pk:int}", pk.ToString());

        public int Pk { get; set; }
    }
}
