﻿namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnOgPersonByFnrRequest
    {
        public const string Route = "/BarnOgPersonByFnr/{Fnr}";
        public static string BuildRoute(string fnr) => Route.Replace("{Fnr}", fnr);

        public string Fnr { get; set; }
    }
}
