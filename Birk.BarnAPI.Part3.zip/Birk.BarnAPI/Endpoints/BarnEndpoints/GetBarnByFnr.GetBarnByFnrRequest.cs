﻿namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByFnrRequest
    {
        public const string Route = "/BarnByFnr/{Fnr}";
        public static string BuildRoute(string fnr) => Route.Replace("{Fnr}", fnr);

        public string Fnr { get; set; }
    }
}
