﻿using Ardalis.ApiEndpoints;
using Ardalis.Result;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Dto.Validation;
using FluentValidation;
using FluentValidation.Results;
using Ardalis.Result.FluentValidation;
using Ardalis.Result.AspNetCore;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnOgPersonByFnr : EndpointBaseAsync
      .WithRequest<GetBarnOgPersonByFnrRequest>
      .WithActionResult<GetBarnOgPersonByFnrResponse>
    {
        private readonly IBarnQueryService _searchService;
        private IValidator<GenericArgument> _validator;
        private readonly ILogger<GetBarnOgPersonByFnr> _logger;

        // Register dependencies in Infrastrcutre.DefaultInfrastructureModule
        public GetBarnOgPersonByFnr(IBarnQueryService searchService, IValidator<GenericArgument> validator, ILogger<GetBarnOgPersonByFnr> logger)
        {
            _searchService = searchService;
            _validator = validator;
            _logger = logger;
        }

        [HttpGet(GetBarnOgPersonByFnrRequest.Route)]
        [SwaggerOperation(
          Summary = "Gets a single BarnOgPerson by et 11-siffret fødselsnummer",
          Description = "Gets a single BarnOgPerson by et 11-siffret fødselsnummer",
          OperationId = "BarnOgPerson.GetBarnOgPersonByFnr",
          Tags = new[] { "BarnEndpoints" })
        ]
        public override async Task<ActionResult<GetBarnOgPersonByFnrResponse>> HandleAsync([FromRoute] GetBarnOgPersonByFnrRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(GetBarnOgPersonByFnr));

            ValidationResult validationResult = await _validator.ValidateAsync(
                new GenericArgument(ValidationType.Fnr, request.Fnr));

            if (!validationResult.IsValid)
            {
                return Result<GetBarnOgPersonByFnrResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            var result = await _searchService.GetBarnOgPersonByFnr(request.Fnr);

            return result
                .Map(value => value == null
                    ? new GetBarnOgPersonByFnrResponse(result.Status)
                    : new GetBarnOgPersonByFnrResponse(BarnOgPersonMapper.ToDto(result)))
                .ToActionResult(this);
        }
    }
}
