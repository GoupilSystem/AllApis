﻿namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByBirkIdRequest
    {
        public const string Route = "/BarnByBirkId/{BirkId}";
        public static string BuildRoute(string birkId) => Route.Replace("{BirkId}", birkId);

        public string BirkId { get; set; }
    }
}
