﻿using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class CreateBarnRequest
    {
        public const string Route = "/Barn";

        public CreateBarnDto CreateBarnDto { get; set; }
    }
}
