﻿using Ardalis.ApiEndpoints;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Birk.BarnAPI.Core.Interfaces;
using FluentValidation;
using FluentValidation.Results;
using Birk.BarnAPI.Dto.Validation;
using Ardalis.Result.FluentValidation;
using Ardalis.Result;
using Ardalis.Result.AspNetCore;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByBirkId : EndpointBaseAsync
      .WithRequest<GetBarnByBirkIdRequest>
      .WithActionResult<GetBarnByBirkIdResponse>
    {
        private readonly IBarnQueryService _searchService;
        private IValidator<GenericArgument> _validator;
        private readonly ILogger<GetBarnByBirkId> _logger;

        // Register dependencies in Infrastrcutre.DefaultInfrastructureModule
        public GetBarnByBirkId(IBarnQueryService searchService, IValidator<GenericArgument> validator, ILogger<GetBarnByBirkId> logger)
        {
            _searchService = searchService;
            _validator = validator;
            _logger = logger;
        }

        [HttpGet(GetBarnByBirkIdRequest.Route)]
        [SwaggerOperation(
          Summary = "Gets a single barn by BirkId",
          Description = "Gets a single barn by BirkId",
          OperationId = "Barn.GetBarnByBirkId",
          Tags = new[] { "BarnEndpoints" })
        ]
        public override async Task<ActionResult<GetBarnByBirkIdResponse>> HandleAsync([FromRoute] GetBarnByBirkIdRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(GetBarnByBirkId));

            ValidationResult validationResult = await _validator.ValidateAsync(new GenericArgument(ValidationType.BirkId, request.BirkId));
            
            if (!validationResult.IsValid)
            {
                return Result<GetBarnByBirkIdResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            var result = await _searchService.GetBarnByBirkId(request.BirkId);

            return result
                .Map(value => value == null
                    ? new GetBarnByBirkIdResponse(result.Status)
                    : new GetBarnByBirkIdResponse(BarnMapper.ToDto(value)))
                .ToActionResult(this);
        }
    }
}
