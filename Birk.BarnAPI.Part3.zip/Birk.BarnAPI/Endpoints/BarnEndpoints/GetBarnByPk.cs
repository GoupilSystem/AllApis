﻿using Ardalis.ApiEndpoints;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Birk.BarnAPI.Core.Interfaces;
using FluentValidation;
using Birk.BarnAPI.Dto.Validation;
using FluentValidation.Results;
using Ardalis.Result.FluentValidation;
using Ardalis.Result;
using Ardalis.Result.AspNetCore;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByPk : EndpointBaseAsync
      .WithRequest<GetBarnByPkRequest>
      .WithActionResult<GetBarnByPkResponse>
    {
        private readonly IBarnQueryService _searchService;
        private IValidator<GenericArgument> _validator;
        private readonly ILogger<GetBarnByPk> _logger;

        // Register dependencies in Infrastrcutre.DefaultInfrastructureModule
        public GetBarnByPk(IBarnQueryService searchService, IValidator<GenericArgument> validator, ILogger<GetBarnByPk> logger)
        {
            _searchService = searchService;
            _validator = validator;
            _logger = logger;
        }

        [HttpGet(GetBarnByPkRequest.Route)]
        [SwaggerOperation(
          Summary = "Gets a single barn by primary key (BarnPK)",
          Description = "Gets a single barn by by primary key (BarnPK)",
          OperationId = "Barn.GetBarnByPk",
          Tags = new[] { "BarnEndpoints" })
        ]
        public override async Task<ActionResult<GetBarnByPkResponse>> HandleAsync([FromRoute] GetBarnByPkRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(GetBarnByPk));

            ValidationResult validationResult = await _validator.ValidateAsync(new GenericArgument(0, request.Pk));

            if (!validationResult.IsValid)
            {
                return Result<GetBarnByPkResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            var result = await _searchService.GetBarnByPk(request.Pk);

            return result
                .Map(value => value == null
                    ? new GetBarnByPkResponse(result.Status)
                    : new GetBarnByPkResponse(BarnMapper.ToDto(value)))
                .ToActionResult(this);
        }
    }
}
