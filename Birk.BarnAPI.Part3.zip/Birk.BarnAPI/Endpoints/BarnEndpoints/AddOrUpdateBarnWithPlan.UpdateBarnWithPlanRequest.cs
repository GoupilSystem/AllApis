﻿using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class UpdateBarnWithPlanRequest
    {
        public const string Route = "/AddOrUpdateBarnWithPlan";

        public IndividuellHelsePlanDto PlanDto { get; set; }
        public bool CanUpdate{ get; set; }
    }
}
