﻿using Ardalis.ApiEndpoints;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using FluentValidation;
using Birk.BarnAPI.Dto;
using FluentValidation.Results;
using Birk.BarnAPI.Core.Interfaces;
using Ardalis.Result.FluentValidation;
using Ardalis.Result;
using Ardalis.Result.AspNetCore;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{

    public class CreateBarn : EndpointBaseAsync
      .WithRequest<CreateBarnRequest>
      .WithActionResult<CreateBarnResponse>
    {
        private readonly IPersonCommandService _personCommandService;
        private readonly IPersonQueryService _personQueryService;
        private IValidator<CreateBarnDto> _validator;
        private readonly ILogger<CreateBarn> _logger;

        // Register dependencies in Infrastrcutre.DefaultInfrastructureModule
        public CreateBarn(IPersonCommandService personCommandService, IPersonQueryService personQueryService, 
            IValidator<CreateBarnDto> validator, ILogger<CreateBarn> logger)
        {
            _personCommandService = personCommandService;
            _personQueryService = personQueryService;
            _validator = validator;
            _logger = logger;
        }

        [HttpPost(CreateBarnRequest.Route)]
        [SwaggerOperation(
          Summary = "Creates a new barn",
          Description = "Creates a new barn and its equivalence as a person",
          OperationId = "Barn.CreateBarn",
          Tags = new[] { "BarnEndpoints" })
        ]
        public override async Task<ActionResult<CreateBarnResponse>> HandleAsync([FromBody] CreateBarnRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(CreateBarn));

            var createBarnDto = request.CreateBarnDto;

            ValidationResult validationResult = await _validator.ValidateAsync(createBarnDto);

            if (!validationResult.IsValid)
            {
                return Result<CreateBarnResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            // Does a person with the requested fødselsnummer already exist?
            var existingPersonResult = await _personQueryService.GetPersonByFødtOgPersonnummer(
                createBarnDto.Født, createBarnDto.Personnummer);
            if (existingPersonResult.Status == ResultStatus.Ok)
            {
                if (existingPersonResult != null) return BadRequest("A person with this Fødselsnummer already exists");
            }

            // Barn + person creation
            var personToCreate = PersonMapper.ToEntity(createBarnDto);
            var createResult = await _personCommandService.CreatePerson(personToCreate, cancellationToken);

            return createResult
                .Map(value =>
                {
                    if (value == null) { return new CreateBarnResponse(createResult.Status); }
                    else
                    {
                        var (barnDto, personDto) = PersonMapper.ToBarnOgPersonDtos(value);
                        return new CreateBarnResponse(barnDto, personDto);
                    }
                })
                .ToActionResult(this);
        }
    }
}