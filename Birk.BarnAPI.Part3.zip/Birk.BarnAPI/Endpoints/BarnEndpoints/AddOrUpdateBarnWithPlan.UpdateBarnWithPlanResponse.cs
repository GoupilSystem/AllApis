﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class UpdateBarnWithPlanResponse : ResponseBase
    {
        public UpdateBarnWithPlanResponse(BarnDto barnDto)
        {
            BarnDto = barnDto;
        }

        public UpdateBarnWithPlanResponse(ResultStatus status) : base(status)
        {
        }

        public BarnDto BarnDto { get; set; }
    }
}
