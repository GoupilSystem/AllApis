﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.BarnEndpoints
{
    public class GetBarnByBirkIdResponse : ResponseBase
    {
        public GetBarnByBirkIdResponse(BarnDto barnDto)
        {
            BarnDto = barnDto;
        }

        public GetBarnByBirkIdResponse(ResultStatus status) : base(status)
        {
        }

        public GetBarnByBirkIdResponse()
        {
        }

        public BarnDto BarnDto { get; set; }
    }
}
