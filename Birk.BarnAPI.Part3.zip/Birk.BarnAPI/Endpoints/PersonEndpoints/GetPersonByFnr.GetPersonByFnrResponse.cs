﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    public class GetPersonByFnrResponse : ResponseBase
    {
        public GetPersonByFnrResponse(PersonDto personDto)
        {
            PersonDto = personDto;
        }

        public GetPersonByFnrResponse(ResultStatus status) : base(status)
        {
        }

        public GetPersonByFnrResponse()
        {
        }

        public PersonDto PersonDto { get; set; }
    }
}
