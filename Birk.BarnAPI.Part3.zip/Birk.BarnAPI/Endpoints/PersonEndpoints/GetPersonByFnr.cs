﻿using Ardalis.ApiEndpoints;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Dto.Validation;
using FluentValidation;
using FluentValidation.Results;
using Birk.BarnAPI.Core.ProjectAggregate.Specifications;
using Birk.BarnAPI.Web.Endpoints.BarnEndpoints;
using Ardalis.Result.FluentValidation;
using Ardalis.Result;
using Ardalis.Result.AspNetCore;

namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    public class GetPersonByFnr : EndpointBaseAsync
      .WithRequest<GetPersonByFnrRequest>
      .WithActionResult<GetPersonByFnrResponse>
    {
        private readonly IPersonQueryService _searchService;
        private IValidator<GenericArgument> _validator;
        private readonly ILogger<GetPersonByFnr> _logger;

        // Register dependencies in Infrastrcutre.DefaultInfrastructureModule
        public GetPersonByFnr(IPersonQueryService searchService, IValidator<GenericArgument> validator, ILogger<GetPersonByFnr> logger)
        {
            _searchService = searchService;
            _validator = validator;
            _logger = logger;
        }

        [HttpGet(GetPersonByFnrRequest.Route)]
        [SwaggerOperation(
          Summary = "Gets a single person by et 11-siffret fødselsnummer",
          Description = "Gets a single person by et 11-siffret fødselsnummer",
          OperationId = "Person.GetPersonByFnr",
          Tags = new[] { "PersonEndpoints" })
        ]
        public override async Task<ActionResult<GetPersonByFnrResponse>> HandleAsync(
            [FromRoute] GetPersonByFnrRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(GetPersonByFnr));

            ValidationResult validationResult = await _validator.ValidateAsync(
                new GenericArgument(ValidationType.Fnr, request.Fnr));

            if (!validationResult.IsValid)
            {
                return Result<GetPersonByFnrResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            var result = await _searchService.GetPersonByFnr(request.Fnr);

            return result
                .Map(value => value == null
                    ? new GetPersonByFnrResponse(result.Status)
                    : new GetPersonByFnrResponse(PersonMapper.ToPersonDto(value)))
                .ToActionResult(this);
        }
    }
}
