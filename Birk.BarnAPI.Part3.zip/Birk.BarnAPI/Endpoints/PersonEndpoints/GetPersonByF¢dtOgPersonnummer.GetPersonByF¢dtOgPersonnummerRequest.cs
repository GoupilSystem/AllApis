﻿namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    public class GetPersonByFødtOgPersonnummerRequest
    {
        public const string Route = "/PersonByFødtOgPersonnummer/{Født}/{Personnummer}";
        public static string BuildRoute(string født, string personnummer) 
            => Route.Replace("{Født}/{Personnummer}", $"{født}/{personnummer}");

        public DateTime Født { get; set; }
        public string Personnummer { get; set; }
    }
}
