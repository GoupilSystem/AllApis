﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    public class CreatePersonResponse : ResponseBase
    {
        public CreatePersonResponse(PersonDto personDto)
        {
            PersonDto = personDto;
        }

        public CreatePersonResponse(ResultStatus status) : base(status)
        {
        }

        public CreatePersonResponse()
        {
        }

        public PersonDto PersonDto { get; set; }
    }
}
