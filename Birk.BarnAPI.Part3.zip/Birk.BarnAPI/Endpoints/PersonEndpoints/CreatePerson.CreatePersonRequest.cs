﻿using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    public class CreatePersonRequest
    {
        public const string Route = "/Person";

        public CreatePersonDto CreatePersonDto { get; set; }
    }
}
