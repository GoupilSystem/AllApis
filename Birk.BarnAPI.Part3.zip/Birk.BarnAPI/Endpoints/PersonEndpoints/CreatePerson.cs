﻿using Ardalis.ApiEndpoints;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using FluentValidation;
using Birk.BarnAPI.Dto;
using FluentValidation.Results;
using Birk.BarnAPI.Core.Interfaces;
using Ardalis.Result.FluentValidation;
using Ardalis.Result;
using Ardalis.Result.AspNetCore;

namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    
    public class CreatePerson : EndpointBaseAsync
      .WithRequest<CreatePersonRequest>
      .WithActionResult<CreatePersonResponse>
    {
        private readonly IPersonCommandService _personCommandService;
        private readonly IPersonQueryService _personQueryService;
        private IValidator<CreatePersonDto> _validator;
        private readonly ILogger<CreatePerson> _logger;

        public CreatePerson(IPersonCommandService personCommandService, IPersonQueryService personQueryService, 
            IValidator<CreatePersonDto> validator, ILogger<CreatePerson> logger)
        {
            _personCommandService = personCommandService;
            _personQueryService = personQueryService;
            _validator = validator;
            _logger = logger;
        }

        [HttpPost(CreatePersonRequest.Route)]
        [SwaggerOperation(
          Summary = "Creates a new person",
          Description = "Creates a new person",
          OperationId = "Person.CreatePerson",
          Tags = new[] { "PersonEndpoints" })
        ]
        public override async Task<ActionResult<CreatePersonResponse>> HandleAsync([FromBody] CreatePersonRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(CreatePerson));

            var createPersonDto = request.CreatePersonDto;

            ValidationResult validationResult = await _validator.ValidateAsync(createPersonDto);

            if (!validationResult.IsValid)
            {
                return Result<CreatePersonResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            // Does a person with the requested fødselsnummer already exist?
            var existingPersonResult = await _personQueryService.GetPersonByFødtOgPersonnummer(
                createPersonDto.Født, createPersonDto.Personnummer);
            if (existingPersonResult.Status == Ardalis.Result.ResultStatus.Ok)
            {
                if (existingPersonResult != null) return BadRequest("A person with this Fødselsnummer already exists");
            }

            // Person creation
            var personToCreate = PersonMapper.ToEntity(createPersonDto);
            var createResult = await _personCommandService.CreatePerson(personToCreate, cancellationToken);

            return createResult

                .Map(value => value == null
                    ? new CreatePersonResponse(createResult.Status)
                    : new CreatePersonResponse(PersonMapper.ToPersonDto(value)))
                .ToActionResult(this);
        }
    }
}