﻿namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    public class GetPersonByFnrRequest
    {
        public const string Route = "/PersonByFnr/{Fnr}";
        public static string BuildRoute(string fnr) => Route.Replace("{Fnr}", fnr);

        public string Fnr { get; set; }
    }
}
