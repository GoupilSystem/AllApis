﻿using Ardalis.ApiEndpoints;
using Birk.BarnAPI.Web.Mapping;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Dto.Validation;
using FluentValidation;
using FluentValidation.Results;
using Ardalis.Result.FluentValidation;
using Ardalis.Result;
using Ardalis.Result.AspNetCore;

namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    public class GetPersonByFødtOgPersonnummer : EndpointBaseAsync
      .WithRequest<GetPersonByFødtOgPersonnummerRequest>
      .WithActionResult<GetPersonByFødtOgPersonnummerResponse>
    {
        private readonly IPersonQueryService _searchService;
        private IValidator<GenericArgument> _validator;
        private readonly ILogger<GetPersonByFødtOgPersonnummer> _logger;

        // Register dependencies in Infrastrcutre.DefaultInfrastructureModule
        public GetPersonByFødtOgPersonnummer(IPersonQueryService searchService, IValidator<GenericArgument> validator, ILogger<GetPersonByFødtOgPersonnummer> logger)
        {
            _searchService = searchService;
            _validator = validator;
            _logger = logger;
        }

        [HttpGet(GetPersonByFødtOgPersonnummerRequest.Route)]
        [SwaggerOperation(
          Summary = "Gets a single person by et 11-siffret fødselsnummer",
          Description = "Gets a single person by et 11-siffret fødselsnummer",
          OperationId = "Person.GetPersonByFødtPersonnummer",
          Tags = new[] { "PersonEndpoints" })
        ]
        public override async Task<ActionResult<GetPersonByFødtOgPersonnummerResponse>> HandleAsync(
            [FromRoute] GetPersonByFødtOgPersonnummerRequest request, CancellationToken cancellationToken = new())
        {
            _logger.LogInformation("Entering {Method}", nameof(GetPersonByFødtOgPersonnummer));

            ValidationResult validationResult = await _validator.ValidateAsync(
                new GenericArgument(ValidationType.FødtOgPersonnummer, request.Født, request.Personnummer));

            if (!validationResult.IsValid)
            {
                return Result<GetPersonByFødtOgPersonnummerResponse>.Invalid(validationResult.AsErrors()).ToActionResult(this);
            }

            var result = await _searchService.GetPersonByFødtOgPersonnummer(
                request.Født, request.Personnummer); ;

            return result
                .Map(value => value == null
                    ? new GetPersonByFødtOgPersonnummerResponse(result.Status)
                    : new GetPersonByFødtOgPersonnummerResponse(PersonMapper.ToPersonDto(value)))
                .ToActionResult(this);
        }
    }
}
