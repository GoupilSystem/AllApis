﻿using Ardalis.Result;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Endpoints.PersonEndpoints
{
    public class GetPersonByFødtOgPersonnummerResponse : ResponseBase
    {
        public GetPersonByFødtOgPersonnummerResponse(PersonDto personDto)
        {
            PersonDto = personDto;
        }

        public GetPersonByFødtOgPersonnummerResponse(ResultStatus status) : base(status)
        {
        }

        public GetPersonByFødtOgPersonnummerResponse()
        {
        }

        public PersonDto PersonDto { get; set; }
    }
}
