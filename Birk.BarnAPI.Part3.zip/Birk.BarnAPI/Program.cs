using Ardalis.ListStartupServices;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Birk.BarnAPI.Core;
using Birk.BarnAPI.Dto;
using Birk.BarnAPI.Dto.Validation;
using Birk.BarnAPI.Infrastructure;
using Birk.BarnAPI.Web.Endpoints.BarnEndpoints;
using Birk.BarnAPI.Web.Endpoints.PersonEndpoints;
using Birk.BarnAPI.Web.Middleware;
using FluentValidation;
using Microsoft.OpenApi.Models;
using Prometheus;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Configure services

builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());
string connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext(connectionString);

builder.Services.AddControllers();
builder.Services.AddControllersWithViews().AddNewtonsoftJson();

// Fluent validation
builder.Services.AddScoped<IValidator<CreateBarnDto>, CreateBarnDtoValidator>();
builder.Services.AddScoped<IValidator<CreatePersonDto>, CreatePersonDtoValidator>();
builder.Services.AddScoped<IValidator<IndividuellHelsePlanDto>, IndividuellHelsePlanDtoValidator>();
builder.Services.AddScoped<IValidator<GenericArgument>, GenericValidator>();

builder.Services.AddTransient<ExceptionHandler>();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Barn API", Version = "v1" });
    c.EnableAnnotations();
});

builder.Host.ConfigureContainer<ContainerBuilder>(containerBuilder =>
{
    containerBuilder.RegisterModule(new DefaultCoreModule());
    containerBuilder.RegisterModule(new DefaultInfrastructureModule(builder.Environment.EnvironmentName == "Development"));
});

// Logging
builder.Services.AddHttpContextAccessor();
// Serilog
var logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .CreateLogger();
builder.Logging.ClearProviders();
builder.Logging.AddSerilog(logger);

var app = builder.Build();

// Configure
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseShowAllServicesMiddleware();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
app.UseRouting();
app.UseHttpsRedirection();
app.UseCookiePolicy();
app.UseMiddleware<ExceptionHandler>();
app.UseSwagger();
// Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "Barn API V1"));
app.UseHttpMetrics();

app.UseEndpoints(endpoints =>
{
    endpoints.MapDefaultControllerRoute();
    //Expose metrics endpoint for Prometheus
    endpoints.MapMetrics();
});


app.Run();

public partial class Program { }