﻿using Microsoft.AspNetCore.Mvc;

namespace Birk.BarnAPI.Web.Api
{
    [Route("api/[controller]")]
    [ApiController]
    [Produces("application/json")]
    public abstract class BaseApiController : Controller
    {
    }
}
