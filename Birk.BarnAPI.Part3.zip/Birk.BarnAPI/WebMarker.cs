﻿namespace Birk.BarnAPI.Web
{
    // This is a simple marker class that is used by the integration tests to reference the correct assembly for host building
    public class WebMarker
    {

    }
}