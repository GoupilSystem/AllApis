﻿using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Birk.BarnAPI.Web;


//TODO: Generere mer testdata her. Teste ut Bogus nuget pakke for generering
public static class SeedData
{
    public static readonly Barn testBarn = new Barn
    {
        BarnPk = 1,
        BarnTypeFk = 1,
        BirkId = "B000-0001",
        RegAv = "Person 1",
        PersonFk = 1,
    };

    public static readonly Person testPerson = new Person
    {
        PersonPk = 1,
        Fødselsnummer = "11111111111",
        IsPerson = true,
        RegAv = "Person 1",
        UsikkerFødselsdato = false,
        UsikkerFødselsnummer = false
    };

    public static void Initialize(IServiceProvider serviceProvider)
    {
        using (var dbContext = new BarnDbContext(serviceProvider.GetRequiredService<DbContextOptions<BarnDbContext>>()))
        {
            // Look for any TODO items.
            if (dbContext.Barn.Any() && dbContext.Person.Any())
            {
                return;   // DB has been seeded
            }

            PopulateTestData(dbContext);

        }
    }
    public static void PopulateTestData(BarnDbContext dbContext)
    {
        foreach (var item in dbContext.Barn)
        {
            dbContext.Remove(item);
        }
        dbContext.Barn.Add(testBarn);
        dbContext.SaveChanges();

        foreach (var item in dbContext.Person)
        {
            dbContext.Remove(item);
        }
        dbContext.Person.Add(testPerson);
        dbContext.SaveChanges();
    }
}
