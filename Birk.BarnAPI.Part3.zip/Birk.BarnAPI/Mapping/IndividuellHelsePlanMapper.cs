﻿using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Mapping
{
    public static class IndividuellHelsePlanMapper
    {
        public static IndividuellHelsePlanDto ToDto(IndividuellHelsePlan entity)
        {
            if (entity == null)
                return null;

            return new IndividuellHelsePlanDto
            {
                BarnFk = entity.BarnFk,
                Id = entity.IndividuellHelsePlanPk,
                Koordinator = entity.Koordinator,
                KoordinatorArbeidsted = entity.KoordinatorArbeidsted,
                Merknad = entity.Merknad,
                GyldigFraDato = entity.GyldigFraDato,
                GyldigTilDato = entity.GyldigTilDato,
                RegAv = entity.RegAv,
                RegDato = entity.RegDato,
                EndretAv = entity.EndretAv,
                EndretDato = entity.EndretDato,
                IndividuellHelsePlanStatusTypeFk = entity.IndividuellHelsePlanStatusTypeFk,
                BehandletFerdigDato = entity.BehandletFerdigDato
            };
        }

        public static int ToPk(IndividuellHelsePlan entity)
        {
            return entity.IndividuellHelsePlanPk;
        }

        public static IndividuellHelsePlan ToEntity(IndividuellHelsePlanDto dto)
        {
            if (dto == null)
                return null;

            return new IndividuellHelsePlan
            {
                BarnFk = dto.BarnFk,
                IndividuellHelsePlanPk = dto.Id,
                Koordinator = dto.Koordinator,
                KoordinatorArbeidsted = dto.KoordinatorArbeidsted,
                Merknad = dto.Merknad,
                GyldigFraDato = dto.GyldigFraDato,
                GyldigTilDato = dto.GyldigTilDato,
                RegAv = dto.RegAv,
                RegDato = dto.RegDato,
                EndretAv = dto.EndretAv,
                EndretDato = dto.EndretDato,
                IndividuellHelsePlanStatusTypeFk = dto.IndividuellHelsePlanStatusTypeFk == 0 ? null : dto.IndividuellHelsePlanStatusTypeFk,
                BehandletFerdigDato = dto.BehandletFerdigDato
            };
        }
    }

}
