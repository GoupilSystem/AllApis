﻿using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Dto;
using System.Runtime.CompilerServices;

namespace Birk.BarnAPI.Web.Mapping
{
    public class PersonMapper
    {
        public static Person ToEntity(CreatePersonDto createPersonDto)
        {
            var person = new Person()
            {
                Fornavn = createPersonDto.Fornavn,
                Etternavn = createPersonDto.Etternavn,
                Født = createPersonDto.Født,
                Personnummer = createPersonDto.Personnummer,
                StatborgerskapFk = createPersonDto.StatborgerskapFk,
                KjønnTypeFk = createPersonDto.KjønnTypeFk,
                SivilstandTypeFk = createPersonDto.SivilstandTypeFk,
                RegAv = createPersonDto.RegAv,
                RegDato = createPersonDto.RegDato,
                EndretAv = createPersonDto.EndretAv,
                EndretDato = createPersonDto.EndretDato,
                IsPerson = createPersonDto.IsPerson,
                UsikkerFødselsdato = createPersonDto.UsikkerFødselsdato,
                UsikkerFødselsnummer = createPersonDto.UsikkerFødselsnummer,
                Dufnummer = createPersonDto.Dufnummer,
            };

            return person;
        }

        public static Person ToEntity(CreateBarnDto createBarnDto)
        {
            var person = new Person()
            {
                Fornavn = createBarnDto.Fornavn,
                Etternavn = createBarnDto.Etternavn,
                Født = createBarnDto.Født,
                Personnummer = createBarnDto.Personnummer,
                KjønnTypeFk = createBarnDto.KjønnTypeFk,
                StatborgerskapFk = createBarnDto.StatborgerskapFk,
                SivilstandTypeFk = createBarnDto.SivilstandTypeFk,
                RegAv = createBarnDto.RegAv,
                RegDato = createBarnDto.RegDato,
                EndretAv = createBarnDto.EndretAv,
                EndretDato = createBarnDto.EndretDato,
                IsPerson = true,
                UsikkerFødselsdato = createBarnDto.UsikkerFødselsdato,
                UsikkerFødselsnummer = createBarnDto.UsikkerFødselsnummer,
                Dufnummer = createBarnDto.Dufnummer,
            };
            person.Barn = BarnMapper.ToEntity(createBarnDto);

            return person;
        }

        public static PersonDto ToPersonDto(Person person)
        {
            return new PersonDto()
            {
                Pk = person.PersonPk,
                PartyFk = person.PartyFk,
                Fornavn = person.Fornavn,
                Etternavn = person.Etternavn,
                Født = person.Født,
                Personnummer = person.Personnummer,
                Fødselsnummer = person.Fødselsnummer,
                StatborgerskapFk = person.StatborgerskapFk,
                KjønnTypeFk = person.KjønnTypeFk,
                SivilstandTypeFk = person.SivilstandTypeFk,
                RegAv = person.RegAv,
                RegDato = person.RegDato,
                EndretAv = person.EndretAv,
                EndretDato = person.EndretDato,
                IsPerson = true,
                UsikkerFødselsdato = person.UsikkerFødselsdato ?? false,
                UsikkerFødselsnummer = person.UsikkerFødselsnummer ?? false,
                Dufnummer = person.Dufnummer,
                Død = person.Død
    };
        }

        public static (BarnDto, PersonDto) ToBarnOgPersonDtos(Person person)
        {
            BarnDto barnDto = BarnMapper.ToDto(person.Barn);
            barnDto.PersonFk = person.PersonPk;

            return (barnDto, ToPersonDto(person));
        }
    }
}
