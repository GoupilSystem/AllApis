﻿using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Mapping
{
    public class BarnOgPersonMapper
    {
        public static BarnOgPersonDto ToDto(BarnOgPerson barnOgPerson)
        {
            return new BarnOgPersonDto
            {
                Pk = barnOgPerson.BarnPk,
                BarnTypeFk = barnOgPerson.BarnTypeFk,
                BirkId = barnOgPerson.BirkId,
                RegAv = barnOgPerson.RegAv,
                RegDato = barnOgPerson.RegDato,
                EndretAv = barnOgPerson.EndretAv,
                EndretDato = barnOgPerson.EndretDato,
                Fornavn = barnOgPerson.Fornavn,
                Etternavn = barnOgPerson.Etternavn,
                KjønnTypeFk = barnOgPerson.KjønnTypeFk,
                Født = barnOgPerson.Født,
                Fødselsnummer = barnOgPerson.Fødselsnummer,
                Personnummer = barnOgPerson.Personnummer,
                HasExistingIndividuellHelsePlan = barnOgPerson.HasExistingIndividuellHelsePlan
            };
        }
    }
}
