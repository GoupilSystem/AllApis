﻿using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Dto;

namespace Birk.BarnAPI.Web.Mapping
{
    public class BarnMapper
    {
        public static Barn ToEntity(CreateBarnDto dto)
        {
            return new Barn
            {
                BarnTypeFk = dto.BarnTypeFk,
                Invandrerbakgrunn = dto.Invandrerbakgrunn,
                RefOdanr = dto.RefOdanr,
                Sikkerhetsnivå = dto.Sikkerhetsnivå,
                ReligionMerknad = dto.ReligionMerknad,
                Termin = dto.Termin,
                ErArbeidssøker = dto.ErArbeidssøker,
                FolkeGruppeTypeFk = dto.FolkeGruppeTypeFk,
                OpprinnelseslandTypeFk = dto.OpprinnelseslandTypeFk,
                BarnetBeherskerEngelsk = dto.BarnetBeherskerEngelsk,
                ForeldreBeherskerEngelsk = dto.ForeldreBeherskerEngelsk,
                BarnetTrengerTolk = dto.BarnetTrengerTolk,
                ForeldreTrengerTolk = dto.ForeldreTrengerTolk,
                ReligionViktig = dto.ReligionViktig,
                EtnisitetViktig = dto.EtnisitetViktig,
                EtnisitetMerknad = dto.EtnisitetMerknad,
                EtnisitetTypeFk = dto.EtnisitetTypeFk,
                EtnisitetAnnet = dto.EtnisitetAnnet,
                ReligionTypeFk = dto.ReligionTypeFk,
                ReligionAnnet = dto.ReligionAnnet,
                HjemmespråkFk = dto.HjemmespråkFk,
                HjemmespråkAnnet = dto.HjemmespråkAnnet,
                SpråkLandMerknad = dto.SpråkLandMerknad,
                NasjonalitetTypeFk = dto.NasjonalitetTypeFk,
                BarnetsSpråkFk = dto.BarnetsSpråkFk,
                TrosamfunnFk = dto.TrosamfunnFk,
                BarnetErForsvunnet = false,
                VerdensdelTypeFk = dto.VerdensdelTypeFk,
                VerdensregionTypeFk = dto.VerdensregionTypeFk,
                RegAv = dto.RegAv,
                RegDato = dto.RegDato,
                EndretAv = dto.EndretAv,
                EndretDato = dto.EndretDato,
                BarnetsKommunalePersonId = dto.BarnetsKommunalePersonId,
                RefOdaBarnNr = dto.RefOdanr,
                Agressonummer = dto.Agressonr,
                RefBirkId = "",
                AntallAktiveTiltak = 0,
                ErEnsligMindreårig = dto.ErEnsligMindreårig,
                BarnStatusTypeFk = 0,
                ErAsylsøker = dto.ErAsylsøker,
                FlyktningFraDato = dto.FlyktningFraDato,
                BarnStatusEndretDato = null,
                Duplikat = false
            };
        }

        public static BarnDto ToDto(Barn barn)
        {
            return new BarnDto
            {
                Pk = barn.BarnPk,
                Invandrerbakgrunn = barn.Invandrerbakgrunn,
                Sikkerhetsnivå = barn.Sikkerhetsnivå,
                ReligionMerknad = barn.ReligionMerknad,
                BirkId = barn.BirkId,
                BirkidÅr = barn.BirkidÅr,
                BirkidSeq = barn.BirkidSeq,
                Termin = barn.Termin,
                PersonFk = barn.PersonFk,
                ErArbeidssøker = barn.ErArbeidssøker,
                FolkeGruppeTypeFk = barn.FolkeGruppeTypeFk,
                OpprinnelseslandTypeFk = barn.OpprinnelseslandTypeFk,
                BarnetBeherskerEngelsk = barn.BarnetBeherskerEngelsk,
                ForeldreBeherskerEngelsk = barn.ForeldreBeherskerEngelsk,
                BarnetTrengerTolk = barn.BarnetTrengerTolk,
                ForeldreTrengerTolk = barn.ForeldreTrengerTolk,
                ReligionViktig = barn.ReligionViktig,
                EtnisitetViktig = barn.EtnisitetViktig,
                EtnisitetMerknad = barn.EtnisitetMerknad,
                EtnisitetTypeFk = barn.EtnisitetTypeFk,
                EtnisitetAnnet = barn.EtnisitetAnnet,
                ReligionTypeFk = barn.ReligionTypeFk,
                ReligionAnnet = barn.ReligionAnnet,
                HjemmespråkFk = barn.HjemmespråkFk,
                HjemmespråkAnnet = barn.HjemmespråkAnnet,
                SpråkLandMerknad = barn.SpråkLandMerknad,
                NasjonalitetTypeFk = barn.NasjonalitetTypeFk,
                BarnetsSpråkFk = barn.BarnetsSpråkFk,
                TrosamfunnFk = barn.TrosamfunnFk,
                TrosamfunnAnnet = barn.TrosamfunnAnnet,
                VerdensdelTypeFk = barn.VerdensdelTypeFk,
                VerdensregionTypeFk = barn.VerdensregionTypeFk,
                EndretAv = barn.EndretAv,
                EndretDato = barn.EndretDato,
                ErEnsligMindreårig = barn.ErEnsligMindreårig,
                HasExistingIndividuellHelsePlan = barn.IndividuellHelsePlan != null
            };
        }
    }
}
