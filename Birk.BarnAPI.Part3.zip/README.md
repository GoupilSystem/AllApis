https://dev.azure.com/Smidig/Birk/_git/Birk.Barn.Api
# Introduksjon
Dette repository inneholder Api for Birk.Barn.Api
# Konfigurasjon
- Set "ConnectionStrings:DefaultConnection" til riktige verdi for � kj�re database.
- Set Visual launch settings til Solution Platform: AnyCPU, StartUp Project: Birk.BarnAPI.Web