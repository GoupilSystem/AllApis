﻿using Ardalis.Specification;

namespace Birk.BarnAPI.SharedKernel.Interfaces
{
    public interface IReadRepository<T> : IReadRepositoryBase<T> where T : class, IAggregateRoot
    {
    }

}