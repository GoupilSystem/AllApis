﻿using Ardalis.HttpClientTestExtensions;
using Ardalis.Result;
using Birk.BarnAPI.Web;
using Birk.BarnAPI.Web.Endpoints.PersonEndpoints;
using Microsoft.VisualStudio.TestPlatform.Utilities;
using System.Net;
using Xunit;

namespace Birk.BarnAPI.FunctionalTests.ApiEndpoints;

[Collection("Sequential")]
public class TestGetPersonByFødtOgPersonnummer : IClassFixture<CustomWebApplicationFactory<WebMarker>>
{
    private readonly HttpClient _client;

    public TestGetPersonByFødtOgPersonnummer(CustomWebApplicationFactory<WebMarker> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetPersonByFødtOgPersonnummer_ReturnsExpectedBarn()
    {
        // Arrange
        var route = GetPersonByFødtOgPersonnummerRequest.BuildRoute("11-11-11","11111");

        // Act
        var result = await _client.GetAndDeserializeAsync<GetPersonByFødtOgPersonnummerResponse>(route);

        // Assert
        Assert.IsType<GetPersonByFødtOgPersonnummerResponse>(result);

        var personResult = result.PersonDto;
        Assert.NotNull(personResult);
    }

    [Fact]
    public async Task GetPersonByFødtOgPersonnummer_ReturnsNotFoundGivenFødtOgPersonnummer0()
    {
        // Arrange
        var route = GetPersonByFødtOgPersonnummerRequest.BuildRoute("01-01-99", "00000");

        // Act
        var result = await _client.GetAsync(route);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
    }
}
