﻿using Ardalis.HttpClientTestExtensions;
using Azure;
using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Dto;
using Birk.BarnAPI.Web;
using Birk.BarnAPI.Web.Endpoints.BarnEndpoints;
using Birk.BarnAPI.Web.Endpoints.PersonEndpoints;
using Microsoft.VisualStudio.TestPlatform.Utilities;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using Xunit;
using Xunit.Abstractions;

namespace Birk.BarnAPI.FunctionalTests.ApiEndpoints;

[Collection("Sequential")]
public class CreatePersonTest : IClassFixture<CustomWebApplicationFactory<WebMarker>>
{
    private readonly HttpClient _client;

    public CreatePersonTest(CustomWebApplicationFactory<WebMarker> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task CreatePerson_ReturnsExpectedAnswerTest()
    {
        // Arrange
        var personDto = new CreatePersonDto()
        {
            KjønnTypeFk = 1,
            StatborgerskapFk = 1,
            SivilstandTypeFk = 1,
            Fornavn = "string",
            Etternavn = "string",
            Født = DateTime.Now,
            Personnummer = "11111",
            IsPerson = true,
            RegAv = "string",
            RegDato = DateTime.Now,
            EndretAv = "string",
            EndretDato = DateTime.Now,
            UsikkerFødselsdato = true,
            UsikkerFødselsnummer = true
        };
        var route = CreatePersonRequest.Route;

        // Act
        var personRequest = new CreatePersonRequest() { CreatePersonDto = personDto };
        var serializedRequest = JsonConvert.SerializeObject(personRequest);
        var scRequest = new StringContent(serializedRequest, Encoding.UTF8, "application/json");
        var result = await _client.PostAndDeserializeAsync<CreatePersonResponse>(route, scRequest, null);

        // Assert
        Assert.NotNull(result);
        Assert.NotNull(result.PersonDto);
        // Already a person med Pk = 1 registered in MemoryDb
        Assert.True(result.PersonDto.Pk > 1);
    }

    [Fact]
    public async Task CreatePerson_ReturnsNotFound()
    {
        // Arrange
        var personDto = new CreatePersonDto();
        var route = "WrongUrl";

        // Act
        var personRequest = new CreatePersonRequest() { CreatePersonDto = personDto };
        var serializedRequest = JsonConvert.SerializeObject(personRequest);
        var scRequest = new StringContent(serializedRequest, Encoding.UTF8, "application/json");
        var result = await _client.PostAsync(route, scRequest);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task CreatePerson_ReturnsBadRequest()
    {
        // Arrange
        var personDto = new CreatePersonDto();
        var route = CreatePersonRequest.Route;

        // Act
        var personRequest = new CreatePersonRequest() { CreatePersonDto = personDto };
        var serializedRequest = JsonConvert.SerializeObject(personRequest);
        var scRequest = new StringContent(serializedRequest, Encoding.UTF8, "application/json");
        var result = await _client.PostAsync(route, scRequest);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.BadRequest);
    }


}
