﻿using Ardalis.HttpClientTestExtensions;
using Ardalis.Result;
using Birk.BarnAPI.Web;
using Birk.BarnAPI.Web.Endpoints.BarnEndpoints;
using System.Net;
using Xunit;

namespace Birk.BarnAPI.FunctionalTests.ApiEndpoints;

[Collection("Sequential")]
public class TestGetBarnByFnr : IClassFixture<CustomWebApplicationFactory<WebMarker>>
{
    private readonly HttpClient _client;

    public TestGetBarnByFnr(CustomWebApplicationFactory<WebMarker> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetBarnByFnr_ReturnsExpectedBarn()
    {
        // Arrange
        var route = GetBarnByFnrRequest.BuildRoute("11111111111");

        // Act
        var result = await _client.GetAndDeserializeAsync<GetBarnByFnrResponse>(route);

        // Assert
        Assert.IsType<GetBarnByFnrResponse>(result);

        var barnResult = result.BarnDto;
        Assert.NotNull(barnResult);
    }

    [Fact]
    public async Task GetBarnByFnr_ReturnsNotFoundGivenFnr0()
    {
        // Arrange
        var route = GetBarnByFnrRequest.BuildRoute("00000000000");

        // Act
        var result = await _client.GetAsync(route);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
    }
}
