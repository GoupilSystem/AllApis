﻿using Ardalis.HttpClientTestExtensions;
using Azure;
using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Dto;
using Birk.BarnAPI.Web;
using Birk.BarnAPI.Web.Endpoints.BarnEndpoints;
using Birk.BarnAPI.Web.Endpoints.PersonEndpoints;
using Microsoft.VisualStudio.TestPlatform.Utilities;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using Xunit;
using Xunit.Abstractions;

namespace Birk.BarnAPI.FunctionalTests.ApiEndpoints;

[Collection("Sequential")]
public class CreateBarnTest : IClassFixture<CustomWebApplicationFactory<WebMarker>>
{
    private readonly HttpClient _client;

    public CreateBarnTest(CustomWebApplicationFactory<WebMarker> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task CreateBarn_ReturnsExpectedAnswerTest()
    {
        // Arrange
        var createBarnDto = new CreateBarnDto()
        {
            BarnetsSpråkFk = 1,
            BarnTypeFk = 1,
            EtnisitetTypeFk = 1,
            FolkeGruppeTypeFk = 1,
            HjemmespråkFk = 1,
            OpprinnelseslandTypeFk = 1,
            ReligionTypeFk = 1,
            TrosamfunnFk = 1,
            VerdensregionTypeFk = 1,
            VerdensdelTypeFk = 1,
            RegAv = "XCOMMON\\xjamoy",
            RegDato = DateTime.Now,

            // Person
            KjønnTypeFk = 1,
            SivilstandTypeFk = 1,
            Fornavn = "string",
            Etternavn = "string",
            Født = DateTime.Now,
            Personnummer = "11111",
            EndretAv = "string",
            EndretDato = DateTime.Now,
            UsikkerFødselsdato = true,
            UsikkerFødselsnummer = true,
        };
        var route = CreateBarnRequest.Route;

        // Act
        var personRequest = new CreateBarnRequest() { CreateBarnDto = createBarnDto };
        var serializedRequest = JsonConvert.SerializeObject(personRequest);
        var scRequest = new StringContent(serializedRequest, Encoding.UTF8, "application/json");        
        var result = await _client.PostAndDeserializeAsync<CreateBarnResponse>(route, scRequest, null);
        
        // Assert        
        Assert.NotNull(result.BarnDto);
        // Already a person med Pk = 1 registered in MemoryDb
        Assert.True(result.BarnDto.Pk > 1);
    }

    [Fact]
    public async Task CreateBarn_ReturnsNotFoundTest()
    {
        // Arrange
        var barnDto = new CreateBarnDto();
        var route = "WrongUrl";

        // Act
        var barnRequest = new CreateBarnRequest() { CreateBarnDto = barnDto };
        var serializedRequest = JsonConvert.SerializeObject(barnRequest);
        var scRequest = new StringContent(serializedRequest, Encoding.UTF8, "application/json");
        var result = await _client.PostAsync(route, scRequest);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
    }

    [Fact]
    public async Task CreateBarn_ReturnsNotAllowedTest()
    {
        // Arrange
        var requestContent = string.Empty;
        var route = GetBarnByBirkIdRequest.Route;

        // Act
        var scRequest = new StringContent(requestContent, Encoding.UTF8, "application/json");
        var result = await _client.PostAsync(route, scRequest);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.MethodNotAllowed);
    }

    [Fact]
    public async Task CreateBarn_ReturnsBadRequestTest()
    {
        // Arrange
        var barnDto = new CreateBarnDto();
        var route = CreateBarnRequest.Route;

        // Act
        var barnRequest = new CreateBarnRequest() { CreateBarnDto = barnDto };
        var serializedRequest = JsonConvert.SerializeObject(barnRequest);
        var scRequest = new StringContent(serializedRequest, Encoding.UTF8, "application/json");
        var result = await _client.PostAsync(route, scRequest);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.BadRequest);
    }


}
