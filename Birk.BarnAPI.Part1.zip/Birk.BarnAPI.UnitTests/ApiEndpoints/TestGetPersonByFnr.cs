﻿using Ardalis.HttpClientTestExtensions;
using Birk.BarnAPI.Web;
using Birk.BarnAPI.Web.Endpoints.PersonEndpoints;
using System.Net;
using Xunit;

namespace Birk.BarnAPI.FunctionalTests.ApiEndpoints;

[Collection("Sequential")]
public class TestGetPersonByFnr : IClassFixture<CustomWebApplicationFactory<WebMarker>>
{
    private readonly HttpClient _client;

    public TestGetPersonByFnr(CustomWebApplicationFactory<WebMarker> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetPersonByFnr_ReturnsExpectedBarn()
    {
        // Arrange
        var route = GetPersonByFnrRequest.BuildRoute("11111111111");

        // Act
        var result = await _client.GetAndDeserializeAsync<GetPersonByFnrResponse>(route);

        // Assert
        Assert.IsType<GetPersonByFnrResponse>(result);

        var personResult = result.PersonDto;
        Assert.NotNull(personResult);
    }

    [Fact]
    public async Task GetPersonByFnr_ReturnsNotFoundGivenFnr0()
    {
        // Arrange
        var route = GetPersonByFnrRequest.BuildRoute("01019900000");

        // Act
        var result = await _client.GetAsync(route);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
    }
}
