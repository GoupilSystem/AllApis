﻿using Ardalis.HttpClientTestExtensions;
using Birk.BarnAPI.Web;
using Birk.BarnAPI.Web.Endpoints.BarnEndpoints;
using System.Net;
using Xunit;

namespace Birk.BarnAPI.FunctionalTests.ApiEndpoints;

[Collection("Sequential")]
public class TestGetBarnByPk : IClassFixture<CustomWebApplicationFactory<WebMarker>>
{
    private readonly HttpClient _client;

    public TestGetBarnByPk(CustomWebApplicationFactory<WebMarker> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetBarnByPk_ReturnsExpectedBarn()
    {
        // Arrange
        var barnPk = 1;
        var route = GetBarnByPkRequest.BuildRoute(barnPk);

        // Act
        var result = await _client.GetAndDeserializeAsync<GetBarnByPkResponse>(route);

        // Assert
        Assert.Equal(result.BarnDto.Pk, barnPk);
    }

    [Fact]
    public async Task GetBarnByPk_ReturnsNotFoundGivenPk0()
    {
        // Arrange
        var route = GetBarnByPkRequest.BuildRoute(0);

        // Act
        var result = await _client.GetAsync(route);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
    }
}
