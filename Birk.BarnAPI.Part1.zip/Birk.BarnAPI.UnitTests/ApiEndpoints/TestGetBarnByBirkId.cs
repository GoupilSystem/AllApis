﻿using Ardalis.HttpClientTestExtensions;
using Birk.BarnAPI.Core.ProjectAggregate.Specifications;
using Birk.BarnAPI.Web;
using Birk.BarnAPI.Web.Endpoints.BarnEndpoints;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.VisualStudio.TestPlatform.Utilities;
using Newtonsoft.Json;
using System.Net;
using Xunit;

namespace Birk.BarnAPI.FunctionalTests.ApiEndpoints;

[Collection("Sequential")]
public class TestGetBarnByBirkId : IClassFixture<CustomWebApplicationFactory<WebMarker>>
{
    private readonly HttpClient _client;

    public TestGetBarnByBirkId(CustomWebApplicationFactory<WebMarker> factory)
    {
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task GetBarnByBirkId_ReturnsExpectedBarn()
    {
        // Arrange
        var birkId = "B000-0001";
        var route = GetBarnByBirkIdRequest.BuildRoute(birkId);

        // Act
        var result = await _client.GetAndDeserializeAsync<GetBarnByBirkIdResponse>(route);

        // Assert
        Assert.Equal(result.BarnDto.BirkId, birkId);
    }

    [Fact]
    public async Task GetBarnByBirkId_ReturnsNotFoundGivenBirkId0()
    {
        // Arrange
        var route = GetBarnByBirkIdRequest.BuildRoute("B000-0000");

        // Act
        var result = await _client.GetAsync(route);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
    }
}
