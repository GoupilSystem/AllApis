using AutoMapper; 
using BirkKodeverkAPI.Api.Data;
using BirkKodeverkAPI.Api.Dtos;
using BirkKodeverkAPI.Api.Models;
using BirkKodeverkAPI.Api.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Logging;
using Moq;

namespace BirkKodeverkAPI.UnitTests
{
    public class UnitTests
    {
        private Logger<ApiRepository> _nullLogger;
        
        public UnitTests()
        {
            _nullLogger = new Logger<ApiRepository>(new NullLoggerFactory());
        }

        [Fact]
        public void Barneverntjenestes_ReturnsListOfBarneverntjenesteDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new BarneverntjenesteDto();
            mockMapper.Setup(x => x.Map<VGetEnhetAdresse, BarneverntjenesteDto>(It.IsAny<VGetEnhetAdresse>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.Barneverntjenestes();

            // Assert
            var typedResult = Assert.IsType<List<BarneverntjenesteDto>>(result.Result);
        }

        [Fact]
        public void BarneverntjenestesByKommunenavn_ReturnsBarneverntjenesteDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new BarneverntjenesteDto();
            mockMapper.Setup(x => x.Map<VGetEnhetAdresse, BarneverntjenesteDto>(It.IsAny<VGetEnhetAdresse>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.BarneverntjenestesByKommunenavn(It.IsAny<string>());

            // Assert
            var typedResult = Assert.IsType<List<BarneverntjenesteDto>>(result.Result);
        }

        [Fact]
        public void BarnTypes_ReturnsListOfBarnTypeDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new BarnTypeDto();
            mockMapper.Setup(x => x.Map<BarnType, BarnTypeDto>(It.IsAny<BarnType>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.BarnTypes();

            // Assert
            var typedResult = Assert.IsType<List<BarnTypeDto>>(result.Result);
        }

        [Fact]
        public void BestillingnAarsakTypes_ReturnsListOfBestillingnAarsakDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new BestillingnAarsakTypeDto();
            mockMapper.Setup(x => x.Map<BestillingnAarsakType, BestillingnAarsakTypeDto>(It.IsAny<BestillingnAarsakType>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.BestillingnAarsakTypes();

            // Assert
            var typedResult = Assert.IsType<List<BestillingnAarsakTypeDto>>(result.Result);
        }

        [Fact]
        public void BestillingTypes_ReturnsListOfBestillingTypeDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new BestillingTypeDto();
            mockMapper.Setup(x => x.Map<BestillingType, BestillingTypeDto>(It.IsAny<BestillingType>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.BestillingTypes();

            // Assert
            var typedResult = Assert.IsType<List<BestillingTypeDto>>(result.Result);
        }

        [Fact]
        public void BistandTypes_ReturnsListOfBistandTypeDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new BistandTypeDto();
            mockMapper.Setup(x => x.Map<BistandType, BistandTypeDto>(It.IsAny<BistandType>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.BistandTypes();

            // Assert
            var typedResult = Assert.IsType<List<BistandTypeDto>>(result.Result);
        }

        [Fact]
        public void HjemmelTypes_ReturnsListOfHjemmelTypeDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new HjemmelTypeDto();
            mockMapper.Setup(x => x.Map<HjemmelType, HjemmelTypeDto>(It.IsAny<HjemmelType>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.HjemmelTypes();

            // Assert
            var typedResult = Assert.IsType<List<HjemmelTypeDto>>(result.Result);
        }

        [Fact]
        public async Task Kommunes_ReturnsListOfKommuneDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new KommuneDto();
            mockMapper.Setup(x => x.Map<Kommune, KommuneDto>(It.IsAny<Kommune>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = await repository.Kommunes();

            // Asert
            Assert.IsType<List<KommuneDto>>(result);
        }

        [Fact]
        public async Task KommuneByKommunePk_ReturnsKommuneDtoWithRightKommunePk_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new KommuneDto();
            mockMapper.Setup(x => x.Map<Kommune, KommuneDto>(It.IsAny<Kommune>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            int kommunePk = new Random().Next(1, 3);

            // Act
            var result = await repository.KommuneByField(new KeyValuePair<FilterKey, string>(FilterKey.KommunePk, kommunePk.ToString()));

            // Assert
            Assert.IsType<KommuneDto>(result);
            Assert.True(result.Pk == kommunePk);
        }

        [Fact]
        public async Task KommuneByKommunename_ReturnsKommuneDtoWithRightKommunename_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new KommuneDto();
            mockMapper.Setup(x => x.Map<Kommune, KommuneDto>(It.IsAny<Kommune>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            string kommunenavn = $"Kommunenavn{new Random().Next(1, 3)}";

            // Act
            var result = await repository.KommuneByField(new KeyValuePair<FilterKey, string>(FilterKey.Kommunenavn, kommunenavn));

            // Assert
            Assert.IsType<KommuneDto>(result);
            Assert.True(result.Navn == kommunenavn);
        }

        [Fact]
        public async Task KommuneByKommunenummer_ReturnsKommuneDtoWithRightKommunenummer_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new KommuneDto();
            mockMapper.Setup(x => x.Map<Kommune, KommuneDto>(It.IsAny<Kommune>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            string kommunenummer = $"Kommunenummer{new Random().Next(1, 3)}";

            // Act
            var result = await repository.KommuneByField(new KeyValuePair<FilterKey, string>(FilterKey.Kommunenummer, kommunenummer));

            // Assert
            Assert.IsType<KommuneDto>(result);
            Assert.True(result.Nummer == kommunenummer);
        }

        [Fact]
        public void VedtakFattetAvnHjemmels_ReturnsListOfVedtakFattetAvnHjemmelDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new VedtakFattetAvnHjemmelDto();
            mockMapper.Setup(x => x.Map<VedtakFattetAvnHjemmel, VedtakFattetAvnHjemmelDto>(It.IsAny<VedtakFattetAvnHjemmel>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.VedtakFattetAvnHjemmels();

            // Assert
            var typedResult = Assert.IsType<List<VedtakFattetAvnHjemmelDto>>(result.Result);
        }

        [Fact]
        public void VedtakFattetAvTypes_ReturnsListOfVedtakFattetAvTypeDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new VedtakFattetAvTypeDto();
            mockMapper.Setup(x => x.Map<VedtakFattetAvType, VedtakFattetAvTypeDto>(It.IsAny<VedtakFattetAvType>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.VedtakFattetAvTypes();

            // Assert
            var typedResult = Assert.IsType<List<VedtakFattetAvTypeDto>>(result.Result);
        }

        [Fact]
        public void VedtakOmTypes_ReturnsListOfVedtakOmTypeDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new VedtakOmTypeDto();
            mockMapper.Setup(x => x.Map<VedtakOmType, VedtakOmTypeDto>(It.IsAny<VedtakOmType>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.VedtakOmTypes();

            // Assert
            var typedResult = Assert.IsType<List<VedtakOmTypeDto>>(result.Result);
        }

        [Fact]
        public void AarsakTypes_ReturnsCorrectListOfAarsakTypeDto_Test()
        {
            // Arrange
            var mockMapper = new Mock<IMapper>();
            var expectedDto = new AarsakTypeDto();
            mockMapper.Setup(x => x.Map<AarsakType, AarsakTypeDto>(It.IsAny<AarsakType>())).Returns(expectedDto);

            var contextFactory = new DbContextFactoryTest();
            var context = contextFactory.CreateDbContext();

            var repository = new ApiRepository(context, mockMapper.Object, _nullLogger);

            // Act
            var result = repository.AarsakTypes();

            // Assert
            var typedResult = Assert.IsType<List<AarsakTypeDto>>(result.Result);
        }
    }
}

public class DbContextFactoryTest : IDbContextFactory<ApiDbContext>
{
    private DbContextOptions<ApiDbContext> _options;

    public DbContextFactoryTest()
    {
        _options = new DbContextOptionsBuilder<ApiDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
    }

    public ApiDbContext CreateDbContext()
    {
        var context = new ApiDbContext(_options);

        context.Kommune.Add(CreateKommune(1));
        context.Kommune.Add(CreateKommune(2));
        context.Kommune.Add(CreateKommune(3));

        context.SaveChanges();
        context.Database.EnsureCreated();

        return context;
    }

    public Kommune CreateKommune(int i)
    {
        return new Kommune()
        {
            KommunePk = i,
            Kommunenavn = $"Kommunenavn{i}",
            Kommunenummer = $"Kommunenummer{i}",
            BufRegionFk = 0,
            EndretAv = "",
            EndretDato = DateTime.Now,
            ErBydelObligatorisk = false,
            FakturaReferanse = "",
            FosterhjemstjenesteFk = 0,
            Fradato = DateTime.Now,
            FylkeFk = null,
            InntaksenhetFk = 0,
            InntaksenhetFakturaFk = 0,
            KommuneInntakFk = 0,
            Kundenummer = "",
            RegAv = "",
            RegDato = DateTime.Now,
            Rekkefolge = 0,
            Tildato = DateTime.Now
        };
    }
}