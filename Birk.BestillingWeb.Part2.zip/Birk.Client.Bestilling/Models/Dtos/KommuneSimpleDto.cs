﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class KommuneSimpleDto
    {
        public string Navn { get; set; }
        public int Pk { get; set; }
    }
}