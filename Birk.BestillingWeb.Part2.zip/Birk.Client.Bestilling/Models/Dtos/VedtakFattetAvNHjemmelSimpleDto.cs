﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class VedtakFattetAvNHjemmelSimpleDto
    {
        public int Pk { get; set; }
        public int? BestillingTypeFk { get; set; }
        public int VedtakFattetTypeAvFk { get; set; }
        public int HjemmelTypeFk { get; set; }
    }
}
