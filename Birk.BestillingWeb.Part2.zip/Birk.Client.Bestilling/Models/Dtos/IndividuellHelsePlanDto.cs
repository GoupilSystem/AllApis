﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class IndividuellHelsePlanDto
    {
        public int BarnFk { get; set; }
        public string? Koordinator { get; set; }
        public string? KoordinatorArbeidsted { get; set; }
        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
        public string RegAv { get; set; }
        public DateTime RegDato { get; set; }
    }
}
