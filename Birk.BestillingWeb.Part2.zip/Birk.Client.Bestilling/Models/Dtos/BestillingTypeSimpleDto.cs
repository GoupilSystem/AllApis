﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class BestillingTypeSimpleDto : ExtendedBaseDto
    {
        public string Verdi { get; set; }
        public int Pk { get; set; }
    }
}
