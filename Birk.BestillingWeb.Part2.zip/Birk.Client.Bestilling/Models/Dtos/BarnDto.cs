﻿using System.ComponentModel;

namespace Birk.Client.Bestilling.Models.Dtos
{
    public class BarnDto
    {
        public int Pk { get; set; }

        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
        public int? ReligionTypeFk { get; set; }
        public int? TrosamfunnFk { get; set; }
        public int? HjemmespråkFk { get; set; }
        public int? VerdensregionTypeFk { get; set; }
        public int? VerdensdelTypeFk { get; set; }
        public int? OpprinnelseslandTypeFk { get; set; }
        public bool ReligionViktig { get; set; }
        public bool BarnetBeherskerEngelsk { get; set; }
        public bool BarnetTrengerTolk { get; set; }
        public bool ForeldreBeherskerEngelsk { get; set; }
        public bool ForeldreTrengerTolk { get; set; }
        public int BarnTypeFk { get; set; } = 1;
        public bool Invandrerbakgrunn { get; set; }
        public int? RefOdanr { get; set; }
        public bool? ErEnsligMindreårig { get; set; }
        public string? Agressonr { get; set; }
        public int Sikkerhetsnivå { get; set; }
        public string? ReligionMerknad { get; set; }
        public string? BirkId { get; set; }
        public int? BirkidÅr { get; set; }
        public int? BirkidSeq { get; set; }
        public DateTime? Termin { get; set; }
        public int PersonFk { get; set; }
        public bool ErArbeidssøker { get; set; }
        public int? FolkeGruppeTypeFk { get; set; }
        public bool EtnisitetViktig { get; set; }
        public string? EtnisitetMerknad { get; set; }
        public int? EtnisitetTypeFk { get; set; }
        public string? EtnisitetAnnet { get; set; }
        public string? ReligionAnnet { get; set; }
        public string? HjemmespråkAnnet { get; set; }
        public string? SpråkLandMerknad { get; set; }
        public int? NasjonalitetTypeFk { get; set; }
        public int? BarnetsSpråkFk { get; set; }
        public string? TrosamfunnAnnet { get; set; }
        public bool HasIndividuellHelsePlan { get; set; }
    }

    public class CreateBarnDto
    {
        // Foreign keys
        [DefaultValue(1)]
        public int BarnTypeFk { get; set; }
        [DefaultValue(null)]
        public int? BarnetsSpråkFk { get; set; }
        [DefaultValue(null)]
        public int? EtnisitetTypeFk { get; set; }
        [DefaultValue(null)]
        public int? FolkeGruppeTypeFk { get; set; }
        [DefaultValue(null)]
        public int? HjemmespråkFk { get; set; }
        [DefaultValue(null)]
        public int? OpprinnelseslandTypeFk { get; set; }
        [DefaultValue(null)]
        public int? ReligionTypeFk { get; set; }
        [DefaultValue(null)]
        public int? StatborgerskapFk { get; set; }
        [DefaultValue(null)]
        public int? TrosamfunnFk { get; set; }
        [DefaultValue(null)]
        public int? VerdensregionTypeFk { get; set; }
        [DefaultValue(null)]
        public int? VerdensdelTypeFk { get; set; }

        // Person del
        [DefaultValue(1)]
        public int KjønnTypeFk { get; set; }
        [DefaultValue(null)]
        public int? SivilstandTypeFk { get; set; }
        public DateTime Født { get; set; }
        [DefaultValue("11111")]
        public string Personnummer { get; set; } = string.Empty;

        public int? NasjonalitetTypeFk { get; set; }
        public int? RefOdanr { get; set; }
        public string? Agressonr { get; set; }
        public bool BarnetBeherskerEngelsk { get; set; }
        public string? BarnetsKommunalePersonId { get; set; }
        public bool BarnetTrengerTolk { get; set; }
        public string? Dufnummer { get; set; }
        public short? Død { get; set; }
        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
        public bool ErArbeidssøker { get; set; }
        public bool ErAsylsøker { get; set; }
        public bool? ErEnsligMindreårig { get; set; }
        public string? EtnisitetAnnet { get; set; }
        public string? EtnisitetMerknad { get; set; }
        public bool EtnisitetViktig { get; set; }
        public string? Etternavn { get; set; }
        public DateTime? FlyktningFraDato { get; set; }
        public bool ForeldreBeherskerEngelsk { get; set; }
        public bool ForeldreTrengerTolk { get; set; }
        public string? Fornavn { get; set; }
        public string? HjemmespråkAnnet { get; set; }
        public int HjemmstedsKommunePk { get; set; }
        public bool Invandrerbakgrunn { get; set; }
        public string RegAv { get; set; } = string.Empty;
        public DateTime RegDato { get; set; }
        public string? ReligionAnnet { get; set; }
        public string? ReligionMerknad { get; set; }
        public bool ReligionViktig { get; set; }
        public int Sikkerhetsnivå { get; set; }
        public string? SpråkLandMerknad { get; set; }
        public DateTime? Termin { get; set; }
        public bool UsikkerFødselsdato { get; set; }
        public bool UsikkerFødselsnummer { get; set; }
    }
}
