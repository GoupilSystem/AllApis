﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class VedtakOmTypeSimpleDto
    {
        public string Verdi { get; set; }
        public int Pk { get; set; }
    }
}