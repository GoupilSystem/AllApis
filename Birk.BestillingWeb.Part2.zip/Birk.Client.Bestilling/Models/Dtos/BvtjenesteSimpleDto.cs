﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class BvtjenesteSimpleDto
    {
        public string EnhetsnavnOgBydelsnavn { get; set; }
        public string[] Kommunenavns { get; set; }
        public int EnhetPk { get; set; }
    }
}
