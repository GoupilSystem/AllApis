﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class TempBvtjenesteDto
    {
        public string EnhetsnavnOgBydelsnavn { get; set; }
        public string Kommunenavn { get; set; }
        public int EnhetPk { get; set; }
    }
}
