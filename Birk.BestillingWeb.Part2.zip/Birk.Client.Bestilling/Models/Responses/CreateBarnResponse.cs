﻿using Birk.Client.Bestilling.Models.Dtos;

namespace Birk.Client.Bestilling.Models.Responses
{
    public class CreateBarnResponse
    {
        public CreateBarnResponse(BarnDto barnDto)
        {
            BarnDto = barnDto;
        }

        public BarnDto BarnDto { get; set; }
    }
}
