﻿using Birk.Client.Bestilling.Models.Dtos;

namespace Birk.Client.Bestilling.Models.Responses
{
    public class UpdateBarnWithPlanResponse
    {
        public UpdateBarnWithPlanResponse(BarnDto barnDto)
        {
            BarnDto = barnDto;
        }

        public BarnDto BarnDto { get; set; }
    }
}
