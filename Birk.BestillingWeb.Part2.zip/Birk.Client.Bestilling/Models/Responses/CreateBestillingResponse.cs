﻿using Birk.Client.Bestilling.Models.Dtos;

namespace Birk.Client.Bestilling.Models.Responses
{
    public class CreateBestillingResponse
    {
        public CreateBestillingResponse(BestillingDto bestilling)
        {
            Bestilling = bestilling;
        }
        public BestillingDto? Bestilling { get; private set; }
    }

}