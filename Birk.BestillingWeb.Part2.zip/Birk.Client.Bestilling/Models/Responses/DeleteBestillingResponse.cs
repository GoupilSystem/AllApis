﻿using Birk.Client.Bestilling.Enums;

namespace Birk.Client.Bestilling.Models.Responses
{
    public class DeleteBestillingItemResponse
    {
        public DeleteStatus Status { get; set; }
    }
}