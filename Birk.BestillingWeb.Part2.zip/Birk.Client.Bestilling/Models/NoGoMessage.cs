﻿using Birk.Client.Bestilling.Enums;
using Birk.Client.Bestilling.Utils.Constants;

namespace Birk.Client.Bestilling.Models
{
    public class NoGoMessage
    {
        public string FieldName { get; set; }
        public string FieldId { get; set; }
        public string ModalMessage { get; set; }
        public string SnackbarMessage { get; set; }
        public NoGoMessageType NoGoMessageType { get; set; }
        public bool IsVisible { get; set; }

        public NoGoMessage(string fieldName, NoGoMessageType resultType)
        {
            // Id attribute can't contain any dot
            var notDottedFieldName = fieldName.Replace(".", "");
            FieldId = $"{notDottedFieldName}Id";

            NoGoMessageType = resultType;

            // Convert fieldName to a message understandable by the user.
            // F.ex., KommuneBvtjeneste.SelectedKommune is converted to Kommune
            FieldName = Language.NO[$"NoGo.{fieldName}"];

            ModalMessage =
                $"{(resultType == NoGoMessageType.Error ? Language.NO["RegistreringAv"] : string.Empty)} " +
                $"{FieldName}";

            SnackbarMessage =
                $"{(resultType == NoGoMessageType.IncompleteField ? Language.NO["IkkeUtfylt"] : Language.NO["Feil"])} " +
                $"{FieldName}";

        }
    }


}
