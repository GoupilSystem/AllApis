﻿namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class BestillingstypePanelModel
    {
        private const int HenvisningPk = 1;

        public string[] Bestillingstyper { get; set; } = Array.Empty<string>();

        public string SelectedBestilling { get; set; }

        public int BestillingstypePk { get; set; }

        public bool IsKommunesAndBvtjenestesSet { get; set; }

        public bool IsHenvisningSelected => BestillingstypePk == HenvisningPk;
    }
}
