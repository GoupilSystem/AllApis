﻿namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class KommuneBvtjenestePanelModel
    {
        public string SelectedKommune { get; set; }
        public string SelectedBvtjeneste { get; set; }
    }
}
