﻿using Birk.Client.Bestilling.Enums;

namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class BarnPanelModel
    {
        public int Pk{ get; set; }

        public string Fornavn { get; set; }

        public string Etternavn {  get; set; }

        public DateTime? Født { get; set; }

        public string Fødselsnummer { get; set; }

        public string Personnummer { get; set; }

        public int? KjønnTypeFk { get; set; }

        public string BirkId { get; set; }

        public SøkStatus SøkStatus { get; set; } = SøkStatus.IkkeSøkt;

        public string PlansKoordinator { get; set; }

        public string KoordinatorsArbeidssted { get; set; }

        public bool HasExistingIndividuellHelsePlan { get; set; }
    }
}
