﻿namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class VedtakPanelModel
    {
        public bool IsSelected { get; set; }
        public DateTime? Vedtaksdato { get; set; }
        public string VedtakFattetAvType { get; set; }
        public string HjemmelType { get; set; }
        public string VedtakOmType { get; set; }
        public int VedtakOmTypeFk { get; set; }
        public string VedtaksOppsummering { get; set; }
    }
}
