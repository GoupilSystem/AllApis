﻿namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class CheckBox
    {
        public bool IsChecked { get; set; }
        public string Name { get; set; }

        public CheckBox(bool isChecked, string name)
        {
            IsChecked = isChecked;
            Name = name;
        }
    }
}
