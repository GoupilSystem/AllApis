﻿namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class KontaktPanelModel
    {
        public string PersonNavn {  get; set; }
        public string LederNavn { get; set; }
    }
}
