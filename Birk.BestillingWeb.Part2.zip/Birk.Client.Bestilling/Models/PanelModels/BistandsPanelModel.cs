﻿using Birk.Client.Bestilling.Enums;

namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class BistandsPanelModel : List<bool>
    {
        public DateTime? ØnsketOppstart { get; set; }

        public BistandsPanelModel() : base()
        {
            foreach (BistandType bistandType in Enum.GetValues(typeof(BistandType)))
            {
                Add(false);
            }
        }
    }
}
