﻿using Birk.Client.Bestilling.Enums;

namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class PlanPanelModel
    {
        public PlanType PlanType { get; set; }
        public DateTime? Plansdato { get; set; }
        public string PlansKoordinator { get; set; }
        public string PlansKoordinatorsArbeidssted { get; set; }
    }
}
