﻿using Birk.Client.Bestilling.Enums;

namespace Birk.Client.Bestilling.Models.PanelModels
{
    public class MedvirkningsPanelModel : List<bool>
    {
        public MedvirkningsPanelModel() : base()
        {
            foreach (MedvirkningType medvirkningType in Enum.GetValues(typeof(MedvirkningType)))
            {
                Add(false);
            }
        }
    }
}
