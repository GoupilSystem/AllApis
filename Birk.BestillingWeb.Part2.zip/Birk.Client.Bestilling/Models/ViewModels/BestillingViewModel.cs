﻿using Birk.Client.Bestilling.Enums;
using Birk.Client.Bestilling.Models.PanelModels;

namespace Birk.Client.Bestilling.Models.ViewModels
{
    public class BestillingViewModel
    {
        public BestillingstypePanelModel Bestillingstype { get; set; }

        public BarnPanelModel Barn { get; set; }
        
        public KontaktPanelModel Kontakt { get; set; }

        public VedtakPanelModel Vedtak { get; set; }

        public BistandsPanelModel Bistands { get; set; }

        public PlanPanelModel Plan { get; set; }

        public MedvirkningsPanelModel Medvirknings { get; set; }

        public Bakgrunn Bakgrunn { get; set; }

        public string Kommune { get; set; }
        public string Bvtjeneste { get; set; }
        public string Merknad { get; set; }

        public bool? Tiltak { get; set; }

        public BestillingViewModel() 
        {
            Bestillingstype = new();
            Barn = new();            
            Bakgrunn = Bakgrunn.None; 
        }
    }
}
