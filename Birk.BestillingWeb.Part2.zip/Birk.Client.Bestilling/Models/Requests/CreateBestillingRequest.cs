﻿using Birk.Client.Bestilling.Models.Dtos;
using System.ComponentModel.DataAnnotations;

namespace Birk.Client.Bestilling.Models.Requests
{
    public class CreateBestillingRequest
    {
        public const string Route = "/Bestillings";

        [Required]
        public CreateBestillingDto? Bestilling;
    }
}