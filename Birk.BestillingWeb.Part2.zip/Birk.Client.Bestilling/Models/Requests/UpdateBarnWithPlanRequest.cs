﻿using Birk.Client.Bestilling.Models.Dtos;

namespace Birk.Client.Bestilling.Models.Requests
{
    public class UpdateBarnWithPlanRequest
    {
        public const string Route = "/AddOrUpdateBarnWithPlan";

        public IndividuellHelsePlanDto PlanDto { get; set; }
        public bool CanUpdate { get; set; }
    }
}
