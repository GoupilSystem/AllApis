﻿using Birk.Client.Bestilling.Enums;
using Birk.Client.Bestilling.Models;

namespace Birk.Client.Bestilling.Services.Interfaces
{
    public interface INoGoService
    {
        Dictionary<Panel, Dictionary<string, NoGoMessage>> NoGo { get; }
        bool HasNoGo => NoGo.Values.Any(innerDict => innerDict.Values.Any(message => message != null));

        void ValidateProperty(Panel panel, string propertyName, bool isValid, bool triggerUpdate = true);
        void ValidatePanelWithoutModel(Panel panel);
        void ValidateVedtakPanel(bool isSelected);
        void ValidatePlanPanel(PlanType planType);

        event Action OnNoGoUpdated;
    }
}
