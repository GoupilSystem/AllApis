﻿using Birk.Client.Bestilling.Enums;
using Birk.Client.Bestilling.Models.Requests;
using Birk.Client.Bestilling.Models;

namespace Birk.Client.Bestilling.Services.Interfaces
{
    public interface IBestillingService
    {
        Task<int> Create(CreateBestillingRequest request);
        Task<List<BestillingItem>> List();
    }
}
