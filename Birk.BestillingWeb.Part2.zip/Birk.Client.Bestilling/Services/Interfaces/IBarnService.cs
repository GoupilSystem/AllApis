﻿using Birk.Client.Bestilling.Models.HttpResults;
using Birk.Client.Bestilling.Models.PanelModels;
using Birk.Client.Bestilling.Models.Requests;

namespace Birk.Client.Bestilling.Services.Interfaces
{
    public interface IBarnService
    {
        Task<HttpResult<BarnPanelModel>> GetBarnByFnr(string fnr);
        Task<int?> CreateBarn(CreateBarnRequest request);
        Task<int?> AddOrUpdateBarnWithPlan(UpdateBarnWithPlanRequest request);
    }
}
