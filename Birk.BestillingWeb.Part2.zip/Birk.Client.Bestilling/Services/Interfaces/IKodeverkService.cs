﻿namespace Birk.Client.Bestilling.Services.Interfaces
{
    public interface IKodeverkService
    {
        Task FetchBestillingstypes();
        string[] GetBestillingstypeVerdis();
        int GetBestillingstypePkByVerdi(string verdi);
        Task FetchKommunesAndBvtjenestes();
        string[] GetKommuneNavns();
        int GetKommunePkByNavn(string navn);
        int GetKommuneIndexByBvtjeneste(string selectedBvtjeneste);
        string[] GetBvtjenesteNavns();
        string[] GetBvtjenesteNavnsByKommunenavn(string kommunenavn);
        int GetBvtjenesteEnhetByNavn(string navn);
        Task FetchVedtakAllTypesByBestillingstypePk(int bestillingstypePk);
        string[] GetVedtakFattetAvTypeVerdis();
        int GetVedtakFattetAvTypePkByVerdi(string verdi);
        string[] GetVedtakOmTypeVerdis();
        string[] GetVedtakOmTypeVerdisToDisplay();
        int GetVedtakOmTypePkByVerdi(string verdi);
        string[] GetHjemmelTypeVerdis(string vedtakFattetAvType);
        int GetHjemmelTypePkByVerdi(string verdi);
    }
}
