﻿using Birk.Client.Bestilling.Models.Dtos;
using Birk.Client.Bestilling.Models.HttpResults;
using Birk.Client.Bestilling.Models.PanelModels;
using Birk.Client.Bestilling.Models.Requests;
using Birk.Client.Bestilling.Models.Responses;
using Birk.Client.Bestilling.Services.Interfaces;
using Birk.Client.Bestilling.Utils.Mappers;

namespace Birk.Client.Bestilling.Services.Implementation
{
    public class BarnService : IBarnService
    {
        private readonly IHttpService _httpService;
        private readonly ILogger<BarnService> _logger;

        private KommuneSimpleDto[] _kommunes;
        private BvtjenesteSimpleDto[] _barneverntjenestes;

        public BarnService(IHttpService httpService, ILogger<BarnService> logger)
        {
            _httpService = httpService;
            _logger = logger;
        }

        public async Task<HttpResult<BarnPanelModel>> GetBarnByFnr(string fnr)
        {
            _logger.LogInformation("Entering {Method} in BarnService", nameof(GetBarnByFnr));

            var response = await _httpService.HttpGet<GetBarnByFnrResponse>($"BarnOgPersonByFnr/{fnr}");

            if (response.IsSuccess)
            {
                var barnViewModel = BarnMapper.DtoToViewModel(response.Data.barnOgPersonDto);
                _logger.LogInformation("{Method} successful", nameof(GetBarnByFnr));
                return new HttpResult<BarnPanelModel>(true, barnViewModel);
            }

            _logger.LogError("{Method} failed - HTTP Status Code: {StatusCode}. Problem Details: {Title}, {Detail}",
                    nameof(GetBarnByFnr), response.ProblemDetails.Status, response.ProblemDetails.Title, response.ProblemDetails.Detail);

            return new HttpResult<BarnPanelModel>(false, null, response.ProblemDetails);
        }

        public async Task<int?> CreateBarn(CreateBarnRequest request)
        {
            _logger.LogInformation("Entering {Method} in BarnService", nameof(CreateBarn));

            var response = await _httpService.HttpPost<CreateBarnResponse>("Barn", request);

            return response.IsSuccess ? response.Data.BarnDto.Pk : null;
        }

        public async Task<int?> AddOrUpdateBarnWithPlan(UpdateBarnWithPlanRequest request)
        {
            _logger.LogInformation("Entering {Method} in BarnService", nameof(AddOrUpdateBarnWithPlan));

            var response = await _httpService.HttpPost<UpdateBarnWithPlanResponse>("AddOrUpdateBarnWithPlan", request);

            return response.IsSuccess ? response.Data.BarnDto.Pk : null;
        }
    }
}
