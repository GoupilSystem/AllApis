﻿using Birk.Client.Bestilling.Enums;
using Birk.Client.Bestilling.Models;
using Birk.Client.Bestilling.Models.PanelModels;
using Birk.Client.Bestilling.Services.Interfaces;
using System.Reflection;

namespace Birk.Client.Bestilling.Services.Implementation
{
    public class NoGoService : INoGoService
    {
        public Dictionary<Panel, Dictionary<string, NoGoMessage>> NoGo { get; private set; }

        public NoGoService()
        {
            // Initialize the NoGo dictionary in the constructor
            NoGo = new Dictionary<Panel, Dictionary<string, NoGoMessage>>();

            foreach (Panel panel in Enum.GetValues(typeof(Panel)))
            {
                NoGo[panel] = new Dictionary<string, NoGoMessage>();

                switch (panel)
                {
                    case Panel.KommuneBvtjeneste:
                        InitPanelWithModel(panel, typeof(KommuneBvtjenestePanelModel), "selectedkommune", "selectedbvtjeneste");
                        break;
                    case Panel.Kontakt:
                        InitPanelWithModel(panel, typeof(KontaktPanelModel), "personnavn");
                        break;
                    case Panel.SøkBarn:
                        InitPanelWithModel(panel, typeof(BarnPanelModel), "søkstatus");
                        break;
                    case Panel.Vedtak:
                        InitPanelWithModel(panel, typeof(VedtakPanelModel), "isselected", "vedtaksdato", "vedtakfattetavtype", "hjemmeltype", "vedtakomtype");
                        break;
                    case Panel.Bakgrunn:
                    case Panel.Tiltak:
                        InitPanelWithoutModel(panel);
                        break;
                    case Panel.Bistands:
                        InitPanelWithModel(panel, typeof(BistandsPanelModel), "count");
                        break;
                    case Panel.Plan:
                        InitPanelWithModel(panel, typeof(PlanPanelModel), "plantype", "plansdato", "planskoordinator", "planskoordinatorsarbeidssted");
                        break;
                    default:
                        break;
                }
            }
        }

        // To initialize the properties to validate in each panel, we need the panel as a key, but also the type of the PanelModel used in the Panel
        // because both don't necessarily have the same name. F.ex: SøkBarnPanel doesn't use a model called SøkBarnPanelModel but BarnPanelModel
        private void InitPanelWithModel(Panel panel, Type panelModelType, params string[] propertyNames)
        {
            // Get all public properties of the class
            var properties = panelModelType.GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (var propertyInfo in properties)
            {
                var propertyName = propertyInfo.Name;
                // Check if the property name is in the specified propertyNames
                if (propertyNames.Contains(propertyName, StringComparer.OrdinalIgnoreCase))
                {
                    // Add the property name as an invalid field
                    NoGo[panel][propertyName] = new NoGoMessage($"{panel}.{propertyName}", NoGoMessageType.IncompleteField);
                }
            }
        }

        private void InitPanelWithoutModel(Panel panel)
        {
            // Example: _bestilling.Bakgrunn is null at initialization and Bakgrunn is just an enum
            // Then we display to the user the snackbar message: "Utfylt: Bakgrunn.IsSelected"
            NoGo[panel]["IsSelected"] = new NoGoMessage($"{panel}.IsSelected", NoGoMessageType.IncompleteField);
        }

        public void ValidateProperty(Panel panel, string propertyName, bool isValid, bool triggerUpdate = true)
        {
            if (!isValid)
            {
                NoGo[panel][propertyName] = new NoGoMessage($"{panel}.{propertyName}", NoGoMessageType.IncompleteField);
            }
            else
            {
                NoGo[panel].Remove(propertyName);
            }
            
            if (triggerUpdate)
            { 
                OnNoGoUpdated?.Invoke(); 
            }
        }

        // Panel without any panel model, like Bakgrunn which is bound to Bakgr8unnType enum.
        // Only "IsSelected" is set in this case.
        public void ValidatePanelWithoutModel(Panel panel)
        {
            NoGo[panel].Remove("IsSelected");
            OnNoGoUpdated?.Invoke();
        }

        public void ValidateVedtakPanel(bool isSelected)
        {
            NoGo[Panel.Vedtak].Clear();

            if (isSelected)
            {
                NoGo[Panel.Vedtak]["VedtakFattetAvType"] = new NoGoMessage($"{Panel.Vedtak}.VedtakFattetAvType", NoGoMessageType.IncompleteField);
                NoGo[Panel.Vedtak]["VedtakOmType"] = new NoGoMessage($"{Panel.Vedtak}.VedtakOmType", NoGoMessageType.IncompleteField);
                NoGo[Panel.Vedtak]["HjemmelType"] = new NoGoMessage($"{Panel.Vedtak}.HjemmelType", NoGoMessageType.IncompleteField);
                NoGo[Panel.Vedtak]["Vedtaksdato"] = new NoGoMessage($"{Panel.Vedtak}.Vedtaksdato", NoGoMessageType.IncompleteField);
            }

            OnNoGoUpdated?.Invoke();
        }

        public void ValidatePlanPanel(PlanType planType)
        {
            NoGo[Panel.Plan].Clear();

            if (planType != PlanType.None)
            {
                NoGo[Panel.Plan]["Plansdato"] = new NoGoMessage($"Plan.Plansdato", NoGoMessageType.IncompleteField);

                if (planType == PlanType.Foreligger)
                {
                    NoGo[Panel.Plan]["PlansKoordinator"] = new NoGoMessage($"{Panel.Plan}.PlansKoordinator", NoGoMessageType.IncompleteField);
                    NoGo[Panel.Plan]["PlansKoordinatorsArbeidssted"] = new NoGoMessage($"{Panel.Plan}.PlansKoordinatorsArbeidssted", NoGoMessageType.IncompleteField);
                }
            }

            OnNoGoUpdated?.Invoke();
        }

        public event Action OnNoGoUpdated;
    }

}
