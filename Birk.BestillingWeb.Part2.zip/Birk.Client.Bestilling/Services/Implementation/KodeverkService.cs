﻿using Birk.Client.Bestilling.Models;
using Birk.Client.Bestilling.Models.Dtos;
using Birk.Client.Bestilling.Models.Requests;
using Birk.Client.Bestilling.Models.Responses;
using Birk.Client.Bestilling.Services.Interfaces;
using Birk.Client.Bestilling.Utils.Constants;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace Birk.Client.Bestilling.Services.Implementation
{
    public class KodeverkService : IKodeverkService
    {
        private readonly IHttpService _httpService;
        private readonly ILogger<KodeverkService> _logger;

        private BestillingTypeSimpleDto[] _bestillingstypes;
        private KommuneSimpleDto[] _kommunes;
        private BvtjenesteSimpleDto[] _bvtjenestes;
        private VedtakFattetAvTypeSimpleDto[] _vedtakFattetAvTypes;
        private VedtakOmTypeSimpleDto[] _vedtakOmTypes;
        private VedtakFattetAvNHjemmelSimpleDto[] _vedtakFattetAvNHjemmels;
        private HjemmelTypeSimpleDto[] _hjemmelTypes;

        public KodeverkService(IHttpService httpService, ILogger<KodeverkService> logger)
        {
            _httpService = httpService;
            _logger = logger;
        }

        public async Task FetchBestillingstypes()
        {
            _logger.LogInformation("Entering {Method} in KodeverkService", nameof(FetchBestillingstypes));

            try
            {
                var bestillingstypeResponse = await _httpService.HttpGet<List<BestillingTypeSimpleDto>>("bestillingtypes");
                if (bestillingstypeResponse.IsSuccess)
                {
                    _bestillingstypes = bestillingstypeResponse.Data
                        .Where(bt => bt.GyldigTilDato == null || bt.GyldigTilDato >= DateTime.Now)
                        .ToArray();
                }
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "HTTP request error occurred in {Method} in KodeverkService", nameof(FetchBestillingstypes));
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "Timeout occurred while fetching data in {Method} in KodeverkService", nameof(FetchBestillingstypes));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred in {Method} in KodeverkService", nameof(FetchBestillingstypes));
            }
        }

        public string[] GetBestillingstypeVerdis() => _bestillingstypes?.Select(bt => bt.Verdi).ToArray() ?? new[] { Language.NO["NoData"] };

        public int GetBestillingstypePkByVerdi(string verdi)
        {
            var bestillingstype = _bestillingstypes?.FirstOrDefault(bt => bt.Verdi == verdi);
            return bestillingstype != null ? bestillingstype.Pk : -1;
        }

        public async Task FetchKommunesAndBvtjenestes()
        {
            _logger.LogInformation("Entering {Method} in KodeverkService", nameof(FetchKommunesAndBvtjenestes));

            try
            {
                var kommuneResponse = await _httpService.HttpGet<List<KommuneSimpleDto>>("kommunes");
                if (kommuneResponse.IsSuccess)
                {
                    _kommunes = kommuneResponse.Data.DistinctBy(k => k.Navn).OrderBy(k => k.Navn).ToArray();

                    var barneverntjenesteResponse = await _httpService.HttpGet<List<TempBvtjenesteDto>>("barneverntjenestes");
                    // We get from KodeverkApi a [] of TempBarneverntjenesteDto
                    // with non unique string values EnhetsnavnOgBydelsnavnproperty and Kommunenavn
                    // F.ex:
                    // TempBarneverntjenesteDto1: EnhetsnavnOgBydelsnavn = 'Indre Namdal barnevern', KommuneNavn = 'Grong'
                    // TempBarneverntjenesteDto2: EnhetsnavnOgBydelsnavn = 'Indre Namdal barnevern', KommuneNavn = 'Høylandet'
                    // We need to convert this to an [] of SimplifiedBarneverntjenesteDto with unique value EnhetsnavnOgBydelsnavnproperty
                    // and a string[] Kommunenavns
                    // F.ex:
                    // SimplifiedBarneverntjenesteDto: EnhetsnavnOgBydelsnavn = 'Indre Namdal barnevern', KommuneNavns = 'Grong', 'Høylandet'
                    if (barneverntjenesteResponse.IsSuccess)
                    {
                        var tjenestesWithDuplicatedNames = barneverntjenesteResponse.Data.ToArray();
                        _bvtjenestes = tjenestesWithDuplicatedNames
                            .GroupBy(t => t.EnhetsnavnOgBydelsnavn)
                            .Select(g => new BvtjenesteSimpleDto
                            {
                                EnhetsnavnOgBydelsnavn = g.Key,
                                EnhetPk = g.First().EnhetPk,
                                Kommunenavns = g.Select(s => s.Kommunenavn).OrderBy(k => k).ToArray(),
                            })
                            .OrderBy(sb => sb.Kommunenavns[0])
                            .ToArray();
                    }
                }
            }
            // Cyril Besnard 10.11.2023: this needs to we wrapped with exception middleware like in BirkIntegrationApi
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "HTTP request error occurred in {Method}", nameof(FetchKommunesAndBvtjenestes));
            }
            catch (TaskCanceledException ex)
            {
                _logger.LogError(ex, "Timeout occurred while fetching data in {Method}", nameof(FetchKommunesAndBvtjenestes));
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An unexpected error occurred in {Method}", nameof(FetchKommunesAndBvtjenestes));
            }
        }

        public string[] GetKommuneNavns() => _kommunes?.Select(k => k.Navn).ToArray() ?? new[] { Language.NO["NoData"] };

        public int GetKommunePkByNavn(string navn) => _kommunes?.FirstOrDefault(k => k.Navn.Equals(navn, StringComparison.OrdinalIgnoreCase))?.Pk ?? -1;

        public int GetKommuneIndexByBvtjeneste(string selectedBvtjeneste)
        {
            if (_bvtjenestes == null)
            {
                return -1;
            }

            foreach (var barneverntjeneste in _bvtjenestes)
            {
                if (barneverntjeneste.EnhetsnavnOgBydelsnavn == selectedBvtjeneste)
                {
                    var kommuneNavn = barneverntjeneste.Kommunenavns[0];
                    var kommune = _kommunes.FirstOrDefault(k => k.Navn == kommuneNavn);
                    return Array.IndexOf(_kommunes, kommune);
                }
            }

            return -1;
        }

        public string[] GetBvtjenesteNavns() => _bvtjenestes?.Select(bt => bt.EnhetsnavnOgBydelsnavn).ToArray() ?? new[] { Language.NO["NoData"] };

        public string[] GetBvtjenesteNavnsByKommunenavn(string kommunenavn) =>
            _bvtjenestes == null
                ? new[] { Language.NO["NoData"] }
                : string.IsNullOrEmpty(kommunenavn)
                    ? _bvtjenestes.Select(k => k.EnhetsnavnOgBydelsnavn).ToArray()
                    : _bvtjenestes.Where(k => k.Kommunenavns.Contains(kommunenavn)).Select(k => k.EnhetsnavnOgBydelsnavn).ToArray();

        public int GetBvtjenesteEnhetByNavn(string navn) => _bvtjenestes?.FirstOrDefault(k => k.EnhetsnavnOgBydelsnavn.Equals(navn, StringComparison.OrdinalIgnoreCase))?.EnhetPk ?? -1;

        public async Task FetchVedtakAllTypesByBestillingstypePk(int bestillingstypePk)
        {
            _logger.LogInformation("Entering {Method}", nameof(FetchVedtakAllTypesByBestillingstypePk));

            var vedtakFattetAvNHjemmelSimpleDtoResponse = await _httpService.HttpGet<List<VedtakFattetAvNHjemmelSimpleDto>>("vedtakfattetavnhjemmels");
            if (vedtakFattetAvNHjemmelSimpleDtoResponse.IsSuccess)
            {
                _vedtakFattetAvNHjemmels = vedtakFattetAvNHjemmelSimpleDtoResponse.Data
                    .Where(vn => vn.BestillingTypeFk == bestillingstypePk)
                    .ToArray();


                var vedtakFattetAvTypeSimpleDtoResponse = await _httpService.HttpGet<List<VedtakFattetAvTypeSimpleDto>>("vedtakfattetavtypes");
                if (vedtakFattetAvTypeSimpleDtoResponse.IsSuccess)
                {
                    HashSet<int> vedtakFattetTypeAvFkSet = new HashSet<int>(_vedtakFattetAvNHjemmels
                        .Where(vn => vn.BestillingTypeFk == bestillingstypePk && vn.VedtakFattetTypeAvFk != null)
                        .Select(vn => vn.VedtakFattetTypeAvFk)
                        .Distinct());

                    _vedtakFattetAvTypes = vedtakFattetAvTypeSimpleDtoResponse.Data
                        .Where(v => vedtakFattetTypeAvFkSet.Contains(v.Pk))
                        .ToArray();
                }

                var vedtakOmTypeSimpleDtoResponse = await _httpService.HttpGet<List<VedtakOmTypeSimpleDto>>("vedtakomtypes");
                if (vedtakOmTypeSimpleDtoResponse.IsSuccess)
                {
                    _vedtakOmTypes = vedtakOmTypeSimpleDtoResponse.Data.DistinctBy(v => v.Verdi).OrderBy(v => v.Verdi).ToArray();
                }

                var hjemmelTypeSimpleDtoResponse = await _httpService.HttpGet<List<HjemmelTypeSimpleDto>>("hjemmeltypes");
                if (hjemmelTypeSimpleDtoResponse.IsSuccess)
                {
                    HashSet<int> hjemmelTypeFkSet = new HashSet<int>(_vedtakFattetAvNHjemmels
                        .Where(vn => vn.BestillingTypeFk == bestillingstypePk && vn.HjemmelTypeFk != null)
                        .Select(vn => vn.HjemmelTypeFk)
                        .Distinct());

                    _hjemmelTypes = hjemmelTypeSimpleDtoResponse.Data
                        .Where(h => hjemmelTypeFkSet.Contains(h.Pk))
                        .ToArray();
                }
            }
        }

        public string[] GetVedtakFattetAvTypeVerdis() => _vedtakFattetAvTypes?.Select(v => v.Verdi).ToArray() ?? new[] { Language.NO["NoData"] };

        public int GetVedtakFattetAvTypePkByVerdi(string verdi) => _vedtakFattetAvTypes?.FirstOrDefault(k => k.Verdi.Equals(verdi, StringComparison.OrdinalIgnoreCase))?.Pk ?? -1;

        public string[] GetVedtakOmTypeVerdis() => _vedtakOmTypes?.Select(v => v.Verdi).ToArray() ?? new[] { Language.NO["NoData"] };

        public string[] GetVedtakOmTypeVerdisToDisplay()
        {
            // We only want a selection of VedtakOmType to display in the dropdown
            string[] typesToDisplay = Language.NO["VedtakOmTypesToDisplay"].Split(',');

            var filteredTypeList = _vedtakOmTypes?
                .Where(v => typesToDisplay.Contains(v.Verdi.Trim(), StringComparer.OrdinalIgnoreCase))
                .Select(v => v.Verdi)
                .OrderBy(v => v)
                .ToList();

            var lastItem = Language.NO["VedtakOmTypesToDisplayNA"];
            if (!filteredTypeList.Contains(lastItem))
            {
                filteredTypeList.Add(lastItem);
            }

            var filteredTypes = filteredTypeList.ToArray();

            return filteredTypes ?? new[] { Language.NO["NoData"] };
        }

        public int GetVedtakOmTypePkByVerdi(string verdi) => _vedtakOmTypes?.FirstOrDefault(k => k.Verdi.Equals(verdi, StringComparison.OrdinalIgnoreCase))?.Pk ?? -1;

        public string[] GetHjemmelTypeVerdis(string vedtakFattetAvType)
        {
            int vedtakFattetAvTypePK = _vedtakFattetAvTypes?
                                        .FirstOrDefault(v => v.Verdi.Equals(vedtakFattetAvType, StringComparison.OrdinalIgnoreCase))?
                                        .Pk ?? 0;

            int[] hjemmelTypeFKs = _vedtakFattetAvNHjemmels
                                    .Where(v => v.VedtakFattetTypeAvFk == vedtakFattetAvTypePK)
                                    .Select(v => v.HjemmelTypeFk)
                                    .ToArray();

            string[] hjemmelTypeVerdis = _hjemmelTypes
                                        .Where(h => hjemmelTypeFKs.Contains(h.Pk))
                                        .Select(h => h.Verdi)
                                        .ToArray();

            return hjemmelTypeVerdis;
        }

        public int GetHjemmelTypePkByVerdi(string verdi) => _hjemmelTypes?.FirstOrDefault(k => k.Verdi.Equals(verdi, StringComparison.OrdinalIgnoreCase))?.Pk ?? -1;

    }
}