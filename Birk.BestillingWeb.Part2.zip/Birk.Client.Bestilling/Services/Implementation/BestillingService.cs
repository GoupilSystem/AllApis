﻿using Birk.Client.Bestilling.Models.Requests;
using Birk.Client.Bestilling.Models.Responses;
using Birk.Client.Bestilling.Models;
using Birk.Client.Bestilling.Services.Interfaces;
using Birk.Client.Bestilling.Utils.Mappers;

namespace Birk.Client.Bestilling.Services.Implementation
{
    public class BestillingService : IBestillingService
    {
        private readonly IHttpService _httpService;
        private readonly ILogger<BestillingService> _logger;

        public BestillingService(IHttpService httpService, ILogger<BestillingService> logger)
        {
            _httpService = httpService;
            _logger = logger;
        }

        public async Task<List<BestillingItem>> List()
        {
            _logger.LogInformation("Entering {Method} in BestillingService", nameof(List));

            List<BestillingItem> bestillingItemList = new();

            var response = await _httpService.HttpGet<BestillingListResponse>("Bestillings");
            var bestillings = response.Data.Bestillings;
            foreach (var bestilling in bestillings)
            {
                bestillingItemList.Add(BestillingMapper.DtoToItem(bestilling));
            }
            return bestillingItemList;
        }

        public async Task<int> Create(CreateBestillingRequest request)
        {
            _logger.LogInformation("Entering {Method} in BestillingService", nameof(Create));

            var response = await _httpService.HttpPost<CreateBestillingResponse>("Bestillings", request);

            return response.Data.Bestilling.Pk;
        }
    }
}
