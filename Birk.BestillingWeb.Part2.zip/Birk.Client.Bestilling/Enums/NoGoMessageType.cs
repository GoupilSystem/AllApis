﻿namespace Birk.Client.Bestilling.Enums
{
    public enum NoGoMessageType
    {
        Error = 1,
        IncompleteField = 2
    }
}