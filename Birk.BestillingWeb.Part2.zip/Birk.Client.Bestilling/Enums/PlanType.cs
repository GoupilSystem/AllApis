﻿namespace Birk.Client.Bestilling.Enums
{
    public enum PlanType
    {
        None = 1,
        BehovMeldt = 2,
        Foreligger = 3
    }
}
