﻿namespace Birk.Client.Bestilling.Enums
{
    public enum Panel
    { 
        Bestillingstype = 1,
        KommuneBvtjeneste = 2,
        Kontakt = 3,
        SøkBarn = 4,
        Vedtak = 5,
        Bakgrunn = 6,
        Bistands = 7,
        Tiltak = 8,
        Plan = 9,
        Medvirkning = 10
    }
}
