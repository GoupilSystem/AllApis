﻿namespace Birk.Client.Bestilling.Enums
{
    public enum MedvirkningType
    {
        None = 0,
        Barnet = 1,
        Foreldre = 2,
        Mor = 3,
        Far = 4,
        Verge = 5,
        Tillitsperson = 6
    }
}
