﻿namespace Birk.Client.Bestilling.Enums
{
    public enum GuiType
    {
        Label,
        Dropdown,
        Title,
        Input,
        Button,
        CheckBox,
        TextArea,
        DatePicker,
        RadioButton
    }
}
