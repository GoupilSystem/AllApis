﻿namespace Birk.Client.Bestilling.Enums
{
    public enum BarnType
    {
        None = 0,
        Ordinær = 1,
        Asylsøker = 2,
        Ufødt = 3,
    }
}
