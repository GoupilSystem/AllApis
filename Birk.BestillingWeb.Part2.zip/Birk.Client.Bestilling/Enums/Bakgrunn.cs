﻿namespace Birk.Client.Bestilling.Enums
{
    public enum Bakgrunn
    {
        None = 1,
        Atferdt = 2,
        Hjemme = 3
    }
}
