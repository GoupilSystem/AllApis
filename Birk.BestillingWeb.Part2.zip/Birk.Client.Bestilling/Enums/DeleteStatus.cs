﻿namespace Birk.Client.Bestilling.Enums
{
    public enum DeleteStatus
    {
        Deleted,
        None
    }
}
