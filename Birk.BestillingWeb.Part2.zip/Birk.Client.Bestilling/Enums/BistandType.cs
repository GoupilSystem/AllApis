﻿namespace Birk.Client.Bestilling.Enums
{
    public enum BistandType
    {
        None = 0,
        Institusjon = 1,
        Fosterhjem = 2,
        Familieråd = 3,
        Tilskudd = 4,
        ForeldreOgBarnsenter = 5,
        HjelpetiltakHjemmet = 6,
        Annet = 7
    }
}
