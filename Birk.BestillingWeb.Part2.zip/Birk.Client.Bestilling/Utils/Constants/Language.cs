﻿using System.Collections.ObjectModel;

namespace Birk.Client.Bestilling.Utils.Constants
{
    public static class Language
    {
        private static readonly Lazy<ReadOnlyDictionary<string, string>> _NO = new Lazy<ReadOnlyDictionary<string, string>>(() =>
        {
            var dictionary = new Dictionary<string, string>
            {
                // Top panel
                { "BirkId", "BIRK-ID: " },
                { "Kjønn", "Kjønn: " },
                { "Fødselsdato", "Fødselsdato: " },
                { "Alder", "Alder: " },
                
                // Velg bestillingstype
                { "BestillingstypeTitle", "Bestillingstype" },
                { "BestillingstypePlaceholder", "Velg bestillingstype" },
            
                // KommuneBvtjenestePanel
                { "KommuneTitle", "Hvilken kommune er ansvarlig for bestillingen?" },
                { "VelgKommuneLabel", "Velg ansvarlig kommune " },
                { "VelgBarnevernLabel", "Velg barneverntjeneste/bydel " },

                // KontaktPanel
                { "KontaktpersonLabel", "Kontaktperson " },
                { "KontaktpersonPlaceholder", "Skriv inn navn på kontaktperson" },
                { "TelefonLabel", "Telefon/e-post " },
                { "TelefonPlaceholder", "Skriv inn kontaktinfo" },
                { "KontaktlederLabel", "Nærmeste leder til kontaktperson" },
                { "KontaktlederPlaceholder", "Skriv inn navn på nærmeste leder" },

                // SøkBarnPanel
                { "HvemGjelderTitle", "Hvem gjelder bestillingen?" },
                { "HvemGjelderLabel", "Søk opp barn eller mor til ufødt barn i Birk. For å søke, bruk enten" +
                    "<ul class=\"bullet-list\"><li>Fødselsnummer</li><li>D-nummer/DUF-nummer</li><li>Fornavn og etternavn</li><li>BirkId</li></ul>" },
                { "SøkBarnTitle", "Søk opp barnet i Birk" },
                { "SøkBarnLabel", "Søk opp barn eller mor til ufødt barn i Birk. Bruk fødselsnummer for å søke." +
                    "<br><b>Dersom barnet ikke er registrert fører søket deg til manuell registrering.</b>"},
                { "Søk", "Søk" },
                { "SøkBarnButton", "Søk" },
                { "NyttSøkBarnButton", "Nytt søk" },
                { "NotNumericValue", "OBS! Kun tall i dette feltet"},
                { "FnrNot11DigitsWarning", "OBS! Fødselsnummer skal ha 11 siffer"},
                { "FnrNotValid", "OBS! Fødselsnummer er ugyldig"},
                { "PersonNotFoundWarning", "OBS! Det er ingen barn med dette fødselsnummeret i Birk-systemet"},
                { "UkjentFnr", "Ukjent fødselsnummer"},
                { "BarnNotFound", "Barnet finnes ikke" },
                { "BarnAPINoAnswer", "BarnAPI svarer ikke" },
                
                // Barnopplysning
                { "BarnInfoTitle", "Informasjon om barnet" },
                { "Fornavn", "Fornavn"},
                { "FornavnPlaceholder", "Skriv inn fornavn"},
                { "Etternavn", "Etternavn"},
                { "EtternavnPlaceholder", "Skriv inn etternavn"},
                { "Fødselsnummer", "Fødselsnummer" },
                { "FødselsnummerPlaceholder", "Skriv inn fødselsnummer" },
                { "BirkIdLabel", "BirkId"},
                { "BirkIdPlaceholder", "Ikke registrert i Birk"},
                { "UsikkertFnr", "Usikkert fødselsnummer"},
                { "Sikkerhetsnivå", "Sikkerhetsnivå" },
                { "SikkerhetnivåTypes", "Ordinært sikkerhetsnivå|Skjult adresse|Sperret adresse, fortrolig|Sperret adresse, strengt fortrolig" },
                
                // VedtakPanel
                { "VedtakTitle", "Inneholder henvisningen et gyldig vedtak? " },
                { "Vedtaksdato", "Datert " },
                { "VedtakFattetAvType", "Vedtak er fattet av " },
                { "VedtakFattetAvTypePlaceholder", "Velg hvem som har fattet vedtaket" },
                { "VedtakOmType", "Vedtak om "},
                { "VedtakOmTypePlaceholder", "Velg hvilke type vedtak"},
                { "VedtakOmTypesToDisplay", "Fosterhjemsplassering,Institusjonsplassering,Hjelpetiltak"},
                { "VedtakOmTypesToDisplayNA", "Ikke spesifisert"},
                { "HjemmelType", "Vedtakshjemmel " },
                { "HjemmelTypePlaceholder", "Velg vedtakshjemmel" },
                { "Vedtaksoppsummering", "Skriv en kort oppsummering av vedtaket" },
                { "VedtaksoppsummeringPlaceholder", "Skriv en kort oppsummering" },

                // BakgrunnPanel
                { "BakgrunnTitle", "Bakgrunn for henvisning " },
                { "BakgrunnRadioGroupBtn1", "Alvorlige atferdsvansker og/eller vedvarende rusbruk" },
                { "BakgrunnRadioGroupBtn2", "Forhold ved omsorgen i hjemmet" },

                // BistandsPanel
                { "BistandsTitle", "Hva slags bistand er det kommunen søker om? " },
                { "BistandsCheckBox1", "Institusjon" },
                { "BistandsCheckBox2", "Fosterhjem" },
                { "BistandsCheckBox3", "Familieråd" },
                { "BistandsCheckBox4", "Tilskudd" },
                { "BistandsCheckBox5", "Foreldre- og barnsenter" },
                { "BistandsCheckBox6", "Hjelpetiltak i hjemmet" },
                { "BistandsCheckBox7", "Annet" },

                // TiltakPanel
                { "TiltakTitle", "Har barnet tiltaksplan? " },

                // PlanPanel
                { "PlanTitle", "Individuell plan " },
                { "PlanRadioGroupBtn2", "Behov meldt" },
                { "PlanRadioGroupBtn3", "Foreligger" },
                { "BehovMeldtDateLabel", "Behov meldt til barnevernstjenesten dato " },
                { "GyldigFraDato", "Gyldig fra dato " },
                { "PlansKoordinator", "Koordinator for individuell plan" },
                { "PlansKoordinatorPlaceholder", "Skriv inn navn på koordinator" },
                { "KoordinatorsArbeidssted", "Koordinators arbeidssted" },
                { "KoordinatorsArbeidsstedPlaceholder", "Skriv inn instans" },
                { "ExistingPlanWarning", "Individuell plan foreligger allerede på dette barnet i BiRK." },

                // MedvirkningsPanel
                { "MedvirkningsTitle", "Hvem har deltatt i prosessen forut for å henvise barnet til Bufetat?" },
                { "MedvirkningsCheckBox1", "Barnet selv" },
                { "MedvirkningsCheckBox2", "Mor" },
                { "MedvirkningsCheckBox3", "Far" },
                { "MedvirkningsCheckBox4", "Tillitsperson" },
                { "MedvirkningsCheckBox5", "Verge" },
                { "MedvirkningsCheckBox6", "Andre" },

                // Dates
                { "ØnsketOppstart", "Ønsket oppstart"},
                
                // Merknad
                { "MerknadLabel", "Annen informasjon"},
                { "MerknadPlaceholder", "Skriv inn en merknad"},

                // Create Bestilling
                { "CreateBestilling", "Fullfør registrering"},

                // Modal
                { "NoGoModalErrorHeader", "Obs! Feil i registrering" },
                { "NoGoModalIncompleteHeader", "Obs! Manglende registreringer" },
                { "NoGoModalErrorFields", "Følgende felt har feil i registrering:" },
                { "NoGoModalIncompleteFields", "Følgende felt er ikke utfylt:" },
                { "CreateResultModalHeader", "Create result header"},
                { "CreateResultModalBody", "Bestilling was created with Pk value"},

                // NoGo - Validation error
                { "RegistreringAv", "Registrering av" },
                { "IkkeUtfylt", "Ikke utfylt:" },
                { "Feil", "Feil:" },
                { "NoGo.KommuneBvtjeneste.SelectedKommune", "Kommune"},
                { "NoGo.KommuneBvtjeneste.SelectedBvtjeneste", "Barnevernstjeneste"},
                { "NoGo.Kontakt.PersonNavn", "Navn kontaktperson"},
                { "NoGo.SøkBarn.SøkStatus", "Barn med en gyldig fødselsnummer" },
                { "NoGo.Vedtak.IsSelected", "Vedtak" },
                { "NoGo.Vedtak.Vedtaksdato", "Vedtaksdato" },
                { "NoGo.Vedtak.VedtakFattetAvType", "Vedtak fattet av type" },
                { "NoGo.Vedtak.HjemmelType", "Vedtak hjemmeltype" },
                { "NoGo.Vedtak.VedtakOmType", "Vedtak om type" },
                { "NoGo.Bakgrunn.IsSelected", "Bakgrunn" },
                { "NoGo.Tiltak.IsSelected", "Tiltak" },
                { "NoGo.Bistands.Count", "Bistand" },
                { "NoGo.Plan.PlanType", "Plan type" },
                { "NoGo.Plan.Plansdato", "Plansdato" },
                { "NoGo.Plan.PlansKoordinator", "Planskoordinator" },
                { "NoGo.Plan.PlansKoordinatorsArbeidssted", "Plan Planskoordinatorsarbeidssted" },

                // Icons as markup string
                { "RedStarTopSize8", "<i class=\"fas fa-star top size8\" style=\"color: red;\"></i>" }, // Red cannot pass as a class
                { "WarningSize8", "<i class=\"fas fa-exclamation-circle size8\"></i>" },

                // GUI
                { "Ja", "Ja" },
                { "Nei", "Nei" },
                { "NoData", "No data" },
                { "Ok", "Ok"},

                // Info
                { "InfoSikkerhetsnivå", "Beskrivelse av hva du skal gjøre hvis det er skjerpet sikkerhetsnivå!" +
                    "<ul class=\"bullet-list\"><li>Melde inn i ephorte</li><li>Melde sikkerhetsbehov og hvem som skal ha tilgang</li></ul>" },
                { "InfoTiltak", "Tiltaksplanen er et selvstendig dokument. Den er ikke et enkeltvedtak og skal heller ikke være en del av et vedtak." +
                    "<br/><br/>Loven forutsetter imidlertid at tiltaksplanen skal foreligge samtidig med vedtaket, og <b>det bør derfor fremgå av vedtaket at tiltaksplan er utarbeidet.</b>" },

                // HttpService problems
                { "HttpProblemTitle", "Error while fetching object(s) of type: {0}" },
                { "HttpProblemDetail", "An error occurred while making the {0} request: {1}" },

                // GUI component problems
                { "UnsupportedComponentType", "Unsupported component type: {0}" },

                // Development
                { "TestUser", "Service bruker" }
            };
            return new ReadOnlyDictionary<string, string>(dictionary);
        });

        public static ReadOnlyDictionary<string, string> NO => _NO.Value;
    }
}   