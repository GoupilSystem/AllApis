﻿using Birk.Client.Bestilling.Models;
using Birk.Client.Bestilling.Models.PanelModels;

namespace Birk.Client.Bestilling.Utils.Validators
{
    public static class BarnValidator
    {
        public static bool IsBarnValid(BarnPanelModel barn)
        {
            if (barn == null) return false;

            return (!string.IsNullOrEmpty(barn.Etternavn)
                && !string.IsNullOrEmpty(barn.Fornavn));
        }
    }
}
