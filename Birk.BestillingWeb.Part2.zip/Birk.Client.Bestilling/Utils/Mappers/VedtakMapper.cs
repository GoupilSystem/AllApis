﻿using Birk.Client.Bestilling.Models.Dtos.BestillingDtoTypes;
using Birk.Client.Bestilling.Models.PanelModels;
using Birk.Client.Bestilling.Services.Implementation;

namespace Birk.Client.Bestilling.Utils.Mappers
{
    public static class VedtakMapper
    {
        public static List<Vedtak> MapVedtak(
            VedtakPanelModel vedtak, 
            int barnPk,
            int vedtakFattetAvTypeFk,
            int vedtakOmTypeFk,
            int hjemmelTypeFk,
            string regAv)
        {
            if (vedtak == null || !vedtak.IsSelected)
            {
                return new List<Vedtak>();
            }

            return new List<Vedtak>
            {
                new Vedtak
                {
                    VedtakFattetAvTypeFk = vedtakFattetAvTypeFk,
                    VedtakOmTypeFk = vedtakOmTypeFk,
                    HjemmelTypeFk = hjemmelTypeFk,
                    BarnFk = barnPk,
                    VedtakFattetdato = DateTime.Now,
                    RegAv = regAv,
                    RegDato = DateTime.Now,
                    Merknad = vedtak.VedtaksOppsummering
                }
            };
        }
    }
}
