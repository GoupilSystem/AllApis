﻿using Birk.Client.Bestilling.Models.Dtos.BestillingDtoTypes;

namespace Birk.Client.Bestilling.Utils.Mappers
{
    public static class MedvirkningMapper
    {
        private static readonly Dictionary<int, int> UIMapping = new Dictionary<int, int>
        {
            {1, 1}, // MedvirkningsCheckBox1 maps to Barnet
            {2, 3}, // MedvirkningsCheckBox2 maps to Mor
            {3, 4}, // MedvirkningsCheckBox3 maps to Far
            {4, 6}, // MedvirkningsCheckBox4 maps to Tillitsperson
            {5, 5}  // MedvirkningsCheckBox5 maps to Verge
        };

        private static int UIToDatabaseOrder(int uiOrder)
        {
            if (UIMapping.ContainsKey(uiOrder))
            {
                return UIMapping[uiOrder];
            }

            throw new InvalidOperationException($"No mapping found for UI order: {uiOrder}");
        }

        public static List<BestillingNMedvirkningType> MapMedvirknings(string regAv, List<bool> isCheckedList)
        {
            if (isCheckedList == null)
            {
                return new List<BestillingNMedvirkningType>();
            }

            return isCheckedList
                .Select((isChecked, index) => isChecked
                    ? new BestillingNMedvirkningType
                    {
                        RegAv = regAv,
                        MedvirkningTypeFk = UIToDatabaseOrder(index)
                    }
                    : null)
                .Where(bnb => bnb != null)
                .ToList();
        }
    }
}
