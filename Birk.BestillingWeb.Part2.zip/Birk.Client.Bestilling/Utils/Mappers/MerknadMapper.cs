﻿using Birk.Client.Bestilling.Models.Dtos.BestillingDtoTypes;

namespace Birk.Client.Bestilling.Utils.Mappers
{
    public static class MerknadMapper
    {
        public static List<MerknadNBestilling> MapMerknad(string regAv, string merknad)
        {
            if (string.IsNullOrEmpty(merknad))
            {
                return new List<MerknadNBestilling>();
            }

            var regDato = DateTime.Now;

            return new List<MerknadNBestilling>
            {
                new MerknadNBestilling
                {
                    RegAv = regAv,
                    RegDato = regDato,
                    Merknad = new Merknad
                    {
                        MerknadTypeFk = 1,
                        Tekst = merknad,
                        GyldigFradato = regDato,
                        RegAv = regAv,
                        RegDato = regDato
                    }
                }
            };
        }
    }
}
