﻿using Birk.Client.Bestilling.Models.Dtos.BestillingDtoTypes;
using Birk.Client.Bestilling.Models.PanelModels;

namespace Birk.Client.Bestilling.Utils.Mappers
{
    public static class BistandMapper
    {
        private static readonly Dictionary<int, int> UIMapping = new Dictionary<int, int>
        {
            {1, 1}, // BistandsCheckBox1 maps to Institusjon
            {2, 2}, // BistandsCheckBox2 maps to Fosterhjem
            {3, 9}, // BistandsCheckBox3 maps to Familieråd
            {4, 7}, // BistandsCheckBox4 maps to Tilskudd
            {5, 3}, // BistandsCheckBox5 maps to Foreldre og barn-senter
            {6, 4}, // BistandsCheckBox6 maps to Hjelpetiltak i hjemmet
            {7, 8}  // BistandsCheckBox7 maps to Annet
        };

        private static int UIToDatabaseOrder(int uiOrder)
        {
            if (UIMapping.ContainsKey(uiOrder))
            {
                return UIMapping[uiOrder];
            }

            throw new InvalidOperationException($"No mapping found for UI order: {uiOrder}");
        }

        public static List<BestillingNBistand> MapBistands(string regAv, BistandsPanelModel bistands)
        {
            var regDato = DateTime.Now;

            return bistands
                .Select((isChecked, index) => isChecked
                    ? new BestillingNBistand
                    {
                        RegAv = regAv,
                        RegDato = regDato,
                        BistandTypeFk = UIToDatabaseOrder(index),
                        BistandKommuneOppstartDato = bistands.ØnsketOppstart
                    }
                    : null)
                .Where(bnb => bnb != null)
                .ToList();
        }
    }


}
