﻿using Birk.Client.Bestilling.Enums;
using Birk.Client.Bestilling.Models.Dtos;
using Birk.Client.Bestilling.Models.PanelModels;
using Birk.Client.Bestilling.Utils.Helpers;

namespace Birk.Client.Bestilling.Utils.Mappers
{
    public static class BarnMapper
    {
        public static BarnPanelModel DtoToViewModel(this BarnOgPersonDto dto)
        {
            return new BarnPanelModel
            {
                Pk = dto.Pk,
                BirkId = dto.BirkId,
                Fornavn = dto.Fornavn,
                Etternavn = dto.Etternavn,
                KjønnTypeFk = dto.KjønnTypeFk,
                Født = dto.Født,
                Fødselsnummer = dto.Fødselsnummer,
                Personnummer = dto.Personnummer,
                HasExistingIndividuellHelsePlan = dto.HasExistingIndividuellHelsePlan
            };
        }

        public static CreateBarnDto PanelModelToCreateBarnDto(this BarnPanelModel barn, int ansvarligKommuneFk, string regAv)
        {
            if (barn == null)
            {
                throw new ArgumentNullException(nameof(barn));
            }

            return new CreateBarnDto
            {
                BarnTypeFk = (int)BarnType.Ordinær,
                KjønnTypeFk = barn.KjønnTypeFk ?? 0,
                Født = barn.Født ?? DateTime.MinValue,
                Etternavn = barn.Etternavn,
                Fornavn = barn.Fornavn,
                HjemmstedsKommunePk = ansvarligKommuneFk,
                Personnummer = StringHelper.ConvertFnrToPersonnummer(barn.Fødselsnummer),
                RegAv = regAv,
                RegDato = DateTime.Now,
                Sikkerhetsnivå = 0,
            };
        }
    }
}