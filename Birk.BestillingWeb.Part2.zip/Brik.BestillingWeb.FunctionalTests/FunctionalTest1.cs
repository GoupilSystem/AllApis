namespace Birk.BestillingWeb.FunctionalTests
{
    public class FunctionalTest1
    {
        public class UnitTest
        {
            [Fact]
            public void Test1()
            {
                var gh = 0;
                Assert.True(gh == 0);
            }
        }
    }
}