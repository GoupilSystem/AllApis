# Status pipeline Develop
[![Build Status](https://dev.azure.com/Smidig/Birk/_apis/build/status/Api/Birk.Kodeverk.Api?branchName=develop)](https://dev.azure.com/Smidig/Birk/_build/latest?definitionId=384&branchName=develop)

# Status pipeline Main 
[![Build Status](https://dev.azure.com/Smidig/Birk/_apis/build/status/Api/Birk.Kodeverk.Api?branchName=main)](https://dev.azure.com/Smidig/Birk/_build/latest?definitionId=384&branchName=main)

# Introduksjon
Dette repository inneholder Api for Birk.Kodeverk

# Konfigurasjon
- Set "ConnectionStrings:SQLDbConnection" til riktige verdi for å kjøre database.
- Set Visual launch settings til Solution Platform: AnyCPU, StartUp Project: Birk.KodeverkAPI.Api.