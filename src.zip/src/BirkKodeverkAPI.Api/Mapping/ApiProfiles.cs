﻿using AutoMapper;
using BirkKodeverkAPI.Api.Dtos;
using BirkKodeverkAPI.Api.Models;
using BirkKodeverkAPI.Api.Models;
using System.Drawing.Drawing2D;

namespace BirkKodeverkAPI.Api.Mapping
{
    public class ApiProfiles : Profile
    {
        public ApiProfiles()
        {
            CreateMap<Base, BaseDto>()
                .ForMember(dest => dest.EndretAv, opt => opt.MapFrom(src => src.EndretAv))
                .ForMember(dest => dest.EndretDato, opt => opt.MapFrom(src => src.EndretDato))
                .ForMember(dest => dest.RegAv, opt => opt.MapFrom(src => src.RegAv))
                .ForMember(dest => dest.RegDato, opt => opt.MapFrom(src => src.RegDato));

            CreateMap<ExtendedBase, ExtendedBaseDto>()
                .ForMember(dest => dest.Verdi, opt => opt.MapFrom(src => src.Verdi))
                .ForMember(dest => dest.Beskrivelse, opt => opt.MapFrom(src => src.Beskrivelse))
                .ForMember(dest => dest.Rekkefølge, opt => opt.MapFrom(src => src.Rekkefølge))
                .ForMember(dest => dest.GyldigFraDato, opt => opt.MapFrom(src => src.GyldigFraDato))
                .ForMember(dest => dest.GyldigTilDato, opt => opt.MapFrom(src => src.GyldigTilDato))
                .IncludeBase<Base, BaseDto>();

            CreateMap<VGetEnhetAdresse, BarneverntjenesteDto>()
                .ForMember(dest => dest.EnhetsnavnOgBydelsnavn, opt => opt.MapFrom(src => src.EnhetsnavnOgBydelsnavn));

            CreateMap<BarnType, BarnTypeDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.BarnTypePk))
                .IncludeBase<ExtendedBase, ExtendedBaseDto>();

            CreateMap<BestillingnAarsakType, BestillingnAarsakTypeDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.BestillingnAarsakTypePk))
                .ForMember(dest => dest.BestillingFk, opt => opt.MapFrom(src => src.BestillingFk))
                .ForMember(dest => dest.AarsakTypeFk, opt => opt.MapFrom(src => src.AarsakTypeFk))
                .IncludeBase<Base, BaseDto>();

            CreateMap<BestillingType, BestillingTypeDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.BestillingTypePk))
                .IncludeBase<ExtendedBase, ExtendedBaseDto>();

            CreateMap<BistandType, BistandTypeDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.BistandTypePk))
                .IncludeBase<ExtendedBase, ExtendedBaseDto>();

            CreateMap<Fylke, FylkeDto>()
                .ForMember(dest => dest.FylkeFK, opt => opt.MapFrom(src => src.FylkePk))
                .ForMember(dest => dest.Navn, opt => opt.MapFrom(src => src.Navn))
                .ForMember(dest => dest.RegionFk, opt => opt.MapFrom(src => src.RegionFk))
                .ForMember(dest => dest.Endretdato, opt => opt.MapFrom(src => src.Endretdato));

            CreateMap<HjemmelType, HjemmelTypeDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.HjemmelTypePk))
                .IncludeBase<ExtendedBase, ExtendedBaseDto>();

            CreateMap<Region, RegionDto>()
                .ForMember(dest => dest.RegionFK, opt => opt.MapFrom(src => src.RegionPk))
                .ForMember(dest => dest.Beskrivelse, opt => opt.MapFrom(src => src.Beskrivelse))
                .ForMember(dest => dest.Verdi, opt => opt.MapFrom(src => src.Verdi))
                .ForMember(dest => dest.EndretAv, opt => opt.MapFrom(src => src.EndretAv))
                .ForMember(dest => dest.EndretDato, opt => opt.MapFrom(src => src.EndretDato))
                .ForMember(dest => dest.RegAv, opt => opt.MapFrom(src => src.RegAv))
                .ForMember(dest => dest.RegDato, opt => opt.MapFrom(src => src.RegDato));

            CreateMap<Region, FylkeDto>()
               .ForMember(dest => dest.RegionFk, opt => opt.MapFrom(src => src.RegionPk))
               .AfterMap((src, dest, context) => dest.Region = context.Mapper.Map<RegionDto>(src));

            CreateMap<VedtakFattetAvnHjemmel, VedtakFattetAvnHjemmelDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.VedtakFattetAv_n_HjemmelPk))
                .ForMember(dest => dest.VedtakFattetTypeAvFk, opt => opt.MapFrom(src => src.VedtakFattetTypeAvFk))
                .ForMember(dest => dest.HjemmelTypeFk, opt => opt.MapFrom(src => src.HjemmelTypeFk))
                .ForMember(dest => dest.BestillingTypeFk, opt => opt.MapFrom(src => src.BestillingTypeFk))
                .IncludeBase<Base, BaseDto>(); 

            CreateMap<VedtakFattetAvType, VedtakFattetAvTypeDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.VedtakFattetAvTypePk))
                .IncludeBase<ExtendedBase, ExtendedBaseDto>();

            CreateMap<VedtakOmType, VedtakOmTypeDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.VedtakOmTypePk))
                .IncludeBase<ExtendedBase, ExtendedBaseDto>();

            CreateMap<AarsakType, AarsakTypeDto>()
                .ForMember(dest => dest.Pk, opt => opt.MapFrom(src => src.AarsakTypePk))
                .IncludeBase<ExtendedBase, ExtendedBaseDto>();
        }
    }
}
