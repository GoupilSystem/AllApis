﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class AarsakType : ExtendedBase
    {
        public AarsakType() { }
        public AarsakType(int årsakTypePk, ExtendedBase e)
            : base(e.Verdi, e.Beskrivelse, e.Rekkefølge, e.GyldigFraDato, e.GyldigTilDato, e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            AarsakTypePk = årsakTypePk;
        }

        [Key]
        public int AarsakTypePk  { get; set; }
    }
}
