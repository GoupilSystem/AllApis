﻿namespace BirkKodeverkAPI.Api.Models
{
    public class ExtendedBase : Base
    {
        public ExtendedBase() { }
        public ExtendedBase(string? verdi, string? beskrivelse, int? Rekkefølge, DateTime? gyldigFraDato, DateTime? gyldigTilDato,
            string? regAv, DateTime? regDato, string? endretAv, DateTime? endretDato)
            : base(regAv, regDato, endretAv, endretDato)
        {
            Verdi = verdi;
            Beskrivelse = beskrivelse;
            Rekkefølge = Rekkefølge;
            GyldigFraDato = gyldigFraDato;
            GyldigTilDato = gyldigTilDato;
        }

        public string? Verdi { get; set; }
        public string? Beskrivelse { get; set; }
        public int? Rekkefølge { get; set; }
        public DateTime? GyldigFraDato { get; set; }
        public DateTime? GyldigTilDato { get; set; }
    }
}
