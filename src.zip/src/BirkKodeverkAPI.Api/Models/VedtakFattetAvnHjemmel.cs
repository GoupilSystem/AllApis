﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class VedtakFattetAvnHjemmel : Base
    {
        public VedtakFattetAvnHjemmel() { }
        public VedtakFattetAvnHjemmel(int vedtakFattetAv_n_HjemmelPk, int? bestillingTypeFk, int? hjemmelTypeFk, int? vedtakFattetTypeAvFk,
            Base e)
            : base(e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            VedtakFattetAv_n_HjemmelPk = vedtakFattetAv_n_HjemmelPk;            
            BestillingTypeFk = bestillingTypeFk;
            HjemmelTypeFk = hjemmelTypeFk;
            VedtakFattetTypeAvFk = vedtakFattetTypeAvFk;
        }

        [Key]
        public int VedtakFattetAv_n_HjemmelPk { get; set; }
        public int? BestillingTypeFk { get; set; }
        public int? HjemmelTypeFk { get; set; }
        public int? VedtakFattetTypeAvFk { get; set; }
    }
}