﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class BestillingnAarsakType : Base
    {
        public BestillingnAarsakType() { }
        public BestillingnAarsakType(int bestillingnAarsakTypePk, int? bestillingFk, int? aarsakTypeFk, Base e)
            : base(e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            BestillingnAarsakTypePk = bestillingnAarsakTypePk;
            BestillingFk = bestillingFk;
            AarsakTypeFk = aarsakTypeFk;
        }

        [Key]
        public int BestillingnAarsakTypePk { get; set; }
        public int? BestillingFk { get; set; }
        public int? AarsakTypeFk { get; set; }
    }
}