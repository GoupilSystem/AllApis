﻿namespace BirkKodeverkAPI.Api.Models
{
    public class Base
    {
        public Base() { }
        public Base(string? regAv, DateTime? regDato, string? endretAv, DateTime? endretDato) 
        {
            RegAv = regAv;
            RegDato = regDato;
            EndretAv = endretAv;
            EndretDato = endretDato;
        }

        public string? RegAv { get; set; }
        public DateTime? RegDato { get; set; }
        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
    }
}
