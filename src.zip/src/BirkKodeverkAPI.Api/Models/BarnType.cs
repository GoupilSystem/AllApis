﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class BarnType : ExtendedBase
    {
        public BarnType() { }
        public BarnType(int barnTypePk, ExtendedBase e)
            : base(e.Verdi, e.Beskrivelse, e.Rekkefølge, e.GyldigFraDato, e.GyldigTilDato, e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            BarnTypePk = barnTypePk;
        }

        [Key]
        public int BarnTypePk { get; set; }
    }
}
