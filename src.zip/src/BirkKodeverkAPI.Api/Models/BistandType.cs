﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class BistandType : ExtendedBase
    {
        public BistandType() { }
        public BistandType(int bistandTypePk, int? tjenesteKategoriTypeFk, ExtendedBase e)
            : base(e.Verdi, e.Beskrivelse, e.Rekkefølge, e.GyldigFraDato, e.GyldigTilDato, e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            BistandTypePk = bistandTypePk;
            TjenesteKategoriTypeFk = tjenesteKategoriTypeFk;
        }

        [Key]
        public int BistandTypePk { get; set; }
        public int? TjenesteKategoriTypeFk { get; set; }
    }
}