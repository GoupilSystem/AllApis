﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class VedtakFattetAvType : ExtendedBase
    {
        public VedtakFattetAvType() { }
        public VedtakFattetAvType(int vedtakFattetAvTypePk, ExtendedBase e)
            : base(e.Verdi, e.Beskrivelse, e.Rekkefølge, e.GyldigFraDato, e.GyldigTilDato, e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            VedtakFattetAvTypePk = vedtakFattetAvTypePk;
        }

        [Key]
        public int VedtakFattetAvTypePk { get; set; }
    }
}