﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class VedtakOmType : ExtendedBase
    {
        public VedtakOmType() { }
        public VedtakOmType(int vedtakOmTypePk, ExtendedBase e)
            : base(e.Verdi, e.Beskrivelse, e.Rekkefølge, e.GyldigFraDato, e.GyldigTilDato, e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            VedtakOmTypePk = vedtakOmTypePk;
        }

        [Key]
        public int VedtakOmTypePk { get; set; }
    }
}