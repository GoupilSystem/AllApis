﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class BestillingType : ExtendedBase
    {
        public BestillingType() { }
        public BestillingType(int bestillingTypePk, ExtendedBase e)
            : base(e.Verdi, e.Beskrivelse, e.Rekkefølge, e.GyldigFraDato, e.GyldigTilDato, e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            BestillingTypePk = bestillingTypePk;
        }

        [Key]
        public int BestillingTypePk { get; set; }
    }
}