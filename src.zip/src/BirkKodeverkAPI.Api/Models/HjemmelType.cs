﻿using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Models
{
    public class HjemmelType : ExtendedBase
    {
        public HjemmelType() { }
        public HjemmelType(int hjemmelTypePk, ExtendedBase e)
            : base(e.Verdi, e.Beskrivelse, e.Rekkefølge, e.GyldigFraDato, e.GyldigTilDato, e.RegAv, e.RegDato, e.EndretAv, e.EndretDato)
        {
            HjemmelTypePk = hjemmelTypePk;
        }

        [Key]
        public int HjemmelTypePk  { get; set; }
    }
}
