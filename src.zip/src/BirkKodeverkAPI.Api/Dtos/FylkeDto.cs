﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class FylkeDto
    {
        public int FylkeFK { get; set; }
        public string? Navn { get; set; }
        public int? RegionFk { get; set; }
        public DateTime? Endretdato { get; set; }
        public RegionDto? Region { get; set; }
    }
}