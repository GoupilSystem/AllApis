﻿using BirkKodeverkAPI.Api.Models;

namespace BirkKodeverkAPI.Api.Dtos
{
    public class VedtakFattetAvnHjemmelDto : BaseDto
    {
        public int Pk { get; set; }
        public int? BestillingTypeFk { get; set; }
        public int? HjemmelTypeFk { get; set; }
        public int? VedtakFattetTypeAvFk { get; set; }

    }
}