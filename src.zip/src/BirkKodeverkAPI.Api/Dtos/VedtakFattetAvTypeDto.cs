﻿using BirkKodeverkAPI.Api.Models;

namespace BirkKodeverkAPI.Api.Dtos
{
    public class VedtakFattetAvTypeDto : ExtendedBaseDto
    {
        public int Pk { get; set; }
    }
}
