﻿using BirkKodeverkAPI.Api.Models;

namespace BirkKodeverkAPI.Api.Dtos
{
    public class VedtakOmTypeDto : ExtendedBaseDto
    {
        public int Pk { get; set; }
    }
}
