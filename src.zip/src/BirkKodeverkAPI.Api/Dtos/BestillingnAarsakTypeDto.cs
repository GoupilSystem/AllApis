﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class BestillingnAarsakTypeDto : BaseDto
    {
        public int Pk { get; set; }
        public int? BestillingFk { get; set; }
        public int? AarsakTypeFk { get; set; }
    }
}