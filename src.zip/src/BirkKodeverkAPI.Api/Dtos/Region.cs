﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class RegionDto : BaseDto
    {
        public int RegionFK { get; set; }
        public string? Beskrivelse { get; set; }
        public string? Verdi { get; set; }
    }
}
