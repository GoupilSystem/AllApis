﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class BarnTypeDto : ExtendedBaseDto
    {
        public int Pk { get; set; }
    }
}
