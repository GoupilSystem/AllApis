﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class AarsakTypeDto : ExtendedBaseDto
    {
        public int Pk { get; set; }
    }
}
