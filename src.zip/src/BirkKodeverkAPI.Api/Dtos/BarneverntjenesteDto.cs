﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class BarneverntjenesteDto
    {
        public string EnhetsnavnOgBydelsnavn { get; set; }

        public bool ErBydelObligatorisk { get; set; }

        public string Kommunenavn { get; set; }

        public string Bydelsnavn { get; set; }

        public string BydelsnavnMedParentes { get; set; }

        public int? Bydelpk { get; set; }

        public int KommunePk { get; set; }

        public int EnhetPk { get; set; }

        public int Virksomhettypefk { get; set; }

        public string Virksomhetstype { get; set; }

        public int EnhetsTypePk { get; set; }

        public string EnhetsType { get; set; }

        public string Enhetsnavn { get; set; }

        public int AdresseTypePk { get; set; }

        public string AdresseType { get; set; }

        public string Adresse { get; set; }

        public string Postnummer { get; set; }

        public string Poststed { get; set; }

        public string Mobil { get; set; }

        public string Telefon { get; set; }

        public string Jobbtlf { get; set; }

        public string Epost { get; set; }

        public bool? ErAktiv { get; set; }

        public DateTime? BekreftetAdresseDato { get; set; }
    }
}
