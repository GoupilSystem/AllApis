﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class KommuneDto
    {
        public int Pk { get; set; }
        public int? BufRegionFk { get; set; }
        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
        public bool? ErBydelObligatorisk { get; set; }
        public string? FakturaReferanse { get; set; }
        public int? FosterhjemstjenesteFk { get; set; }
        public DateTime? Fradato { get; set; }
        public FylkeDto? Fylke { get; set; }
        public int? FylkeFk { get; set; }
        public int? InntaksenhetFakturaFk { get; set; }
        public int? InntaksenhetFk { get; set; }
        public int? KommuneInntakFk { get; set; }
        public string Navn { get; set; }
        public string? Nummer { get; set; }
        public string? Kundenummer { get; set; }
        public int? Rekkefolge { get; set; }
        public string? RegAv { get; set; }
        public DateTime? RegDato { get; set; }
        public DateTime? Tildato { get; set; }
    }
}
