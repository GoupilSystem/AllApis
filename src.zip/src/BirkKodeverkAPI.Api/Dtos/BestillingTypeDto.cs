﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class BestillingTypeDto : ExtendedBaseDto
    {
        public int Pk { get; set; }
    }
}
