﻿namespace BirkKodeverkAPI.Api.Dtos
{
    public class HjemmelTypeDto : ExtendedBaseDto
    {
        public int Pk { get; set; }
    }
}
