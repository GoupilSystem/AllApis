﻿using BirkKodeverkAPI.Api.Models;
using System.ComponentModel.DataAnnotations;

namespace BirkKodeverkAPI.Api.Dtos
{
    public class BistandTypeDto : ExtendedBaseDto
    {
        public int Pk { get; set; }
        public int? TjenesteKategoriTypeFk { get; set; }
    }
}