using AutoMapper;
using BirkKodeverkAPI.Api.Enums;
using BirkKodeverkAPI.Api.Mapping;
using BirkKodeverkAPI.Api.Models;
using BirkKodeverkAPI.Api.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.HeaderPropagation;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Prometheus;
using Serilog;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;


var builder = WebApplication.CreateBuilder(args);

// Configure services

// Authentication
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidateActor = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
    };
});
builder.Services.AddAuthorization();

// Logging
builder.Services.AddHttpContextAccessor();
// CorrelationId
builder.Services.AddHeaderPropagation(options =>
{
    options.Headers.Add("Custom-correlation-ID");

});
// Serilog
var logger = new LoggerConfiguration()
  .ReadFrom.Configuration(builder.Configuration)
  .CreateLogger();
builder.Logging.ClearProviders();
builder.Logging.AddSerilog(logger);

// Data
var sqlConBuilder = new SqlConnectionStringBuilder() { ConnectionString = builder.Configuration.GetConnectionString("SQLDbConnection") };
builder.Services.AddDbContext<ApiDbContext>(options => options.UseSqlServer(sqlConBuilder.ConnectionString));
builder.Services.AddScoped<IApiRepository, ApiRepository>();
builder.Services.AddScoped(provider => new MapperConfiguration(mc => { mc.AddProfile(new ApiProfiles()); }).CreateMapper());

//CORS
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder => builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
});

// Swagger
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo { Title = "BirkKodeverkAPI", Version = "v1" });
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Name = "Authorization",
        Description = "Bearer Authentication with JWT Token",
        Type = SecuritySchemeType.Http
    });
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Id = "Bearer",
                    Type = ReferenceType.SecurityScheme
                }
            },
            new List<string>()
        }
    });
});

// Configure

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
// Amongst other things for CorrelationId
app.UseHeaderPropagation();

// MapGroup will set extensions to all endpoints in the group
var clients = app.MapGroup("")
    .AddEndpointFilterFactory((handlerContext, next) =>
    {
        var loggerFactory = handlerContext.ApplicationServices.GetRequiredService<ILoggerFactory>();
        var logger = loggerFactory.CreateLogger("RequestAuditor");
        return (invocationContext) =>
        {
            logger.LogInformation($"Received a request for: {invocationContext.HttpContext.Request.Path}");
            return next(invocationContext);
        };
    });

// No need for await in NET 7
clients.MapGet("/barneverntjenestes", (IApiRepository repo) => repo.Barneverntjenestes());
clients.MapGet("/barneverntjenestesbykommunenavn", (IApiRepository repo, string kommunenavn) => repo.BarneverntjenestesByKommunenavn(kommunenavn));
clients.MapGet("/barntypes", (IApiRepository repo) => repo.BarnTypes());
clients.MapGet("/bestillingnaarsaktypes", (IApiRepository repo) => repo.BestillingnAarsakTypes());
clients.MapGet("/bestillingtypes", (IApiRepository repo) => repo.BestillingTypes());
clients.MapGet("/bistandtypes", (IApiRepository repo) => repo.BistandTypes());
clients.MapGet("/hjemmeltypes", (IApiRepository repo) => repo.HjemmelTypes());
clients.MapGet("/kommunes", (IApiRepository repo) => repo.Kommunes());
clients.MapGet("/kommunebykommunepk", (IApiRepository repo, string kommunePk) =>
    repo.KommuneByField(new KeyValuePair<FilterKey, string>(FilterKey.KommunePk, kommunePk)));
clients.MapGet("/kommunebykommunenavn", (IApiRepository repo, string kommunenavn) =>
    repo.KommuneByField(new KeyValuePair<FilterKey, string>(FilterKey.Kommunenavn, kommunenavn)));
clients.MapGet("/kommunebykommunenummer", (IApiRepository repo, string kommunenummer) =>
    repo.KommuneByField(new KeyValuePair<FilterKey, string>(FilterKey.Kommunenummer, kommunenummer)));
clients.MapGet("/vedtakfattetavnhjemmels", (IApiRepository repo) => repo.VedtakFattetAvnHjemmels());
clients.MapGet("/vedtakfattetavtypes", (IApiRepository repo) => repo.VedtakFattetAvTypes());
clients.MapGet("/vedtakomtypes", (IApiRepository repo) => repo.VedtakOmTypes());
clients.MapGet("/aarsaktypes", (IApiRepository repo) => repo.AarsakTypes());

if (app.Environment.IsDevelopment())
{
    clients.MapPost("/login", (Login login, IApiRepository repo) => Login(login, repo));
    clients.MapGet("/testadmin",
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Admin")]
    (IApiRepository repo) => repo.TestAdmin());
    clients.MapGet("/testuser",
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "User, Admin")]
    (IApiRepository repo) => repo.TestUser());
}

//Catch http metrics and expose metrics endpoint for Prometheus
app.UseRouting();
app.UseHttpMetrics();
app.MapMetrics();

app.UseAuthorization();
app.UseAuthentication();

app.UseCors();

IResult Login(Login login, IApiRepository repo)
{
    if (!string.IsNullOrEmpty(login.Username) &&
        !string.IsNullOrEmpty(login.Password))
    {
        var loggedInUser = repo.GetUser(login);
        if (loggedInUser is null) return Results.NotFound("User not found");

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, loggedInUser.Username),
            new Claim(ClaimTypes.Email, loggedInUser.EmailAddress),
            new Claim(ClaimTypes.GivenName, loggedInUser.GivenName),
            new Claim(ClaimTypes.Surname, loggedInUser.Surname),
            new Claim(ClaimTypes.Role, loggedInUser.Role)
        };

        var token = new JwtSecurityToken
        (
            issuer: builder.Configuration["Jwt:Issuer"],
            audience: builder.Configuration["Jwt:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddDays(60),
            notBefore: DateTime.UtcNow,
            signingCredentials: new SigningCredentials(
                new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])),
                SecurityAlgorithms.HmacSha256)
        );

        var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

        return Results.Ok(tokenString);
    }
    return Results.BadRequest("Invalid user credentials");
}


app.Run();

// Required for IntegrationTests otherwise we have a reference problem
public partial class Program { }