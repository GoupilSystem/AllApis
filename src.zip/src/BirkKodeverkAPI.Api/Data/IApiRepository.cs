﻿using BirkKodeverkAPI.Api.Dtos;
using BirkKodeverkAPI.Api.Enums;
using BirkKodeverkAPI.Api.Models;

namespace BirkKodeverkAPI.Api.Data
{
    public interface IApiRepository
    {
        Task<List<BarneverntjenesteDto>> Barneverntjenestes();
        Task<List<BarneverntjenesteDto>> BarneverntjenestesByKommunenavn(string kommunenavn);
        Task<List<BarnTypeDto>> BarnTypes();        
        Task<List<BestillingnAarsakTypeDto>> BestillingnAarsakTypes();
        Task<List<BestillingTypeDto>> BestillingTypes();
        Task<List<BistandTypeDto>> BistandTypes();
        Task<List<HjemmelTypeDto>> HjemmelTypes();
        Task<List<KommuneDto>> Kommunes();
        Task<KommuneDto> KommuneByField(KeyValuePair<FilterKey, string> filter);
        Task<List<VedtakFattetAvnHjemmelDto>> VedtakFattetAvnHjemmels();
        Task<List<VedtakFattetAvTypeDto>> VedtakFattetAvTypes();
        Task<List<VedtakOmTypeDto>> VedtakOmTypes();
        Task<List<AarsakTypeDto>> AarsakTypes();
        User GetUser(Login login);
        string TestAdmin();
        string TestUser();
    }
}
