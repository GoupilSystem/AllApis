﻿using AutoMapper;
using BirkKodeverkAPI.Api.Dtos;
using BirkKodeverkAPI.Api.Enums;
using BirkKodeverkAPI.Api.Models;
using Microsoft.EntityFrameworkCore;



namespace BirkKodeverkAPI.Api.Data
{
    public class ApiRepository : IApiRepository
    {
        private readonly ApiDbContext _context;
        private readonly IMapper _mapper;
        private readonly ILogger<IApiRepository> _logger;

        public ApiRepository(ApiDbContext context, IMapper mapper, ILogger<IApiRepository> logger)
        {
            _context = context;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<List<BarneverntjenesteDto>> Barneverntjenestes()
        {
            _logger.LogInformation("Method reached: {Method}", nameof(Barneverntjenestes));

            var barneverntjenestes = await _context.VGetEnhetAdresse.ToListAsync();
            return barneverntjenestes.Select(b => _mapper.Map<BarneverntjenesteDto>(b)).Distinct().ToList();
        }

        public async Task<List<BarneverntjenesteDto>> BarneverntjenestesByKommunenavn(string kommunenavn)
        {
            _logger.LogInformation("Method reached: {Method}", nameof(BarneverntjenestesByKommunenavn));

            var barneverntjenestes = await _context.VGetEnhetAdresse.Where(v => v.Kommunenavn == kommunenavn).ToListAsync();
            return barneverntjenestes.Select(b => _mapper.Map<BarneverntjenesteDto>(b)).Distinct().ToList();
        }

        public async Task<List<BarnTypeDto>> BarnTypes()
        {
            _logger.LogInformation("Method reached: {Method}", nameof(BarnTypes));

            var barnTypes = await _context.BarnType.ToListAsync();
            return barnTypes.Select(bt => _mapper.Map<BarnTypeDto>(bt)).ToList();
        }

        public async Task<List<BestillingnAarsakTypeDto>> BestillingnAarsakTypes()
        {
            var bestilling_n_ÅrsakTypes = await _context.BestillingnAarsakType.ToListAsync();
            return bestilling_n_ÅrsakTypes.Select(bt => _mapper.Map<BestillingnAarsakTypeDto>(bt)).ToList();
        }

        public async Task<List<BestillingTypeDto>> BestillingTypes()
        {
            _logger.LogInformation("Method reached: {Method}", nameof(BestillingTypes));

            var bestillingTypes = await _context.BestillingType.ToListAsync();
            return bestillingTypes.Select(b => _mapper.Map<BestillingTypeDto>(b)).ToList();
        }

        public async Task<List<BistandTypeDto>> BistandTypes()
        {
            var bistandTypes = await _context.BistandType.ToListAsync();
            return bistandTypes.Select(b => _mapper.Map<BistandTypeDto>(b)).ToList();
        }

        public async Task<List<HjemmelTypeDto>> HjemmelTypes()
        {
            var hjemmelTypes = await _context.HjemmelType.ToListAsync();
            return hjemmelTypes.Select(k => _mapper.Map<HjemmelTypeDto>(k)).ToList();
        }

        public async Task<List<KommuneDto>> Kommunes()
        {
            var kommunes = await (_context.Kommune
                .Where(k => k.FylkeFk != null)
                .Include(k => k.FylkeFkNavigation)
                .ThenInclude(k => k.RegionFkNavigation)
                .Select(k => new KommuneDto()
                {
                    Pk = k.KommunePk,
                    BufRegionFk = k.BufRegionFk,
                    EndretAv = k.EndretAv,
                    EndretDato = k.EndretDato,
                    ErBydelObligatorisk = k.ErBydelObligatorisk,
                    FakturaReferanse = k.FakturaReferanse,
                    FosterhjemstjenesteFk = k.FosterhjemstjenesteFk,
                    Fradato = k.Fradato,
                    FylkeFk = k.FylkeFk,
                    Fylke = k.FylkeFk != null
                        ? _mapper.Map(k.FylkeFkNavigation.RegionFkNavigation, _mapper.Map<FylkeDto>(k.FylkeFkNavigation))
                        : null,
                    InntaksenhetFakturaFk = k.InntaksenhetFakturaFk,
                    InntaksenhetFk = k.InntaksenhetFk,
                    KommuneInntakFk = k.KommuneInntakFk,
                    Kundenummer = k.Kundenummer,
                    Nummer = k.Kommunenummer,
                    Navn = k.Kommunenavn,
                    Rekkefolge = k.Rekkefolge,
                    RegAv = k.RegAv,
                    Tildato = k.Tildato
                }))
                .ToListAsync();

            return kommunes;
        }
        
        public async Task<KommuneDto> KommuneByField(KeyValuePair<FilterKey, string> filter)
        {
            var query = _context.Kommune.AsQueryable();

            switch (filter.Key)
            {
                case FilterKey.KommunePk:
                    if (int.TryParse(filter.Value, out int pkValue))
                    {
                        query = query.Where(k => k.KommunePk == pkValue);
                    }                    
                    break;
                case FilterKey.Kommunenummer:
                    query = query.Where(k => k.Kommunenummer == filter.Value);
                    break;
                case FilterKey.Kommunenavn:
                    query = query.Where(k => k.Kommunenavn == filter.Value);
                    break;
                default:
                    break;
            }

            var kommune = await (query
                .Select(k => new KommuneDto()
                {
                    Pk = k.KommunePk,
                    BufRegionFk = k.BufRegionFk,
                    EndretAv = k.EndretAv,
                    EndretDato = k.EndretDato,
                    ErBydelObligatorisk = k.ErBydelObligatorisk,
                    FakturaReferanse = k.FakturaReferanse,
                    FosterhjemstjenesteFk = k.FosterhjemstjenesteFk,
                    Fradato = k.Fradato,
                    FylkeFk = k.FylkeFk,
                    Fylke = k.FylkeFk != null
                        ? _mapper.Map(k.FylkeFkNavigation.RegionFkNavigation, _mapper.Map<FylkeDto>(k.FylkeFkNavigation))
                        : null,
                    InntaksenhetFakturaFk = k.InntaksenhetFakturaFk,
                    InntaksenhetFk = k.InntaksenhetFk,
                    KommuneInntakFk = k.KommuneInntakFk,
                    Kundenummer = k.Kundenummer,
                    Nummer = k.Kommunenummer,
                    Navn = k.Kommunenavn,
                    Rekkefolge = k.Rekkefolge,
                    RegAv = k.RegAv,
                    Tildato = k.Tildato
                }))
                .FirstOrDefaultAsync();

            return kommune;
        }

        public async Task<List<VedtakFattetAvnHjemmelDto>> VedtakFattetAvnHjemmels()
        {
            var vedtakFattetAv_n_Hjemmels = await _context.VedtakFattetAv_n_Hjemmel.ToListAsync();
            return vedtakFattetAv_n_Hjemmels.Select(v => _mapper.Map<VedtakFattetAvnHjemmelDto>(v)).ToList();
        }

        public async Task<List<VedtakFattetAvTypeDto>> VedtakFattetAvTypes()
        {
            var vedtakFattetAvTypes = await _context.VedtakFattetAvType.ToListAsync();
            return vedtakFattetAvTypes.Select(v => _mapper.Map<VedtakFattetAvTypeDto>(v)).ToList();
        }

        public async Task<List<VedtakOmTypeDto>> VedtakOmTypes()
        {
            var vedtakOmTypes = await _context.VedtakOmType.ToListAsync();
            return vedtakOmTypes.Select(v => _mapper.Map<VedtakOmTypeDto>(v)).ToList();
        }

        public async Task<List<AarsakTypeDto>> AarsakTypes()
        {
            var årsakTypes = await _context.AarsakType.ToListAsync();
            return årsakTypes.Select(k => _mapper.Map<AarsakTypeDto>(k)).ToList();
        }

        // Cyril 11.01.2023: Authentication, implementation to finish when Azure ctive Directory is set up

        public static List<User> Users = new()
        {
            new() { Username = "Cyril", EmailAddress = "cyril@email.com", Password = "admin", GivenName = "Cyril", Surname = "Gougou", Role = "Admin" },
            new() { Username = "Guest", EmailAddress = "guest@email.com", Password = "guest", GivenName = "Guest", Surname = "SomeoneNotAdmin", Role = "User" }
        };

        public User GetUser(Login login)
        {
            User user = Users.FirstOrDefault(o => o.Username.Equals(login.Username, StringComparison.OrdinalIgnoreCase)
                && o.Password.Equals(login.Password));

            return user;
        }

        public string TestAdmin() { return "Admin authenticated with success"; }

        public string TestUser() { return "User authenticated with success"; }
    }
}
