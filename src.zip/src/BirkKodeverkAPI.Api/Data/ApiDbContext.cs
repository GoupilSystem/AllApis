﻿using BirkKodeverkAPI.Api.Models;
using BirkKodeverkAPI.Api.Enums;
using BirkKodeverkAPI.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace BirkKodeverkAPI.Api.Data
{
    public class ApiDbContext : DbContext
    {
        public ApiDbContext() { }
        public ApiDbContext(DbContextOptions<ApiDbContext> options) : base (options) { }

        // Important: virtual DbSets to support ToListAsync() and mocking in unit tests
        public virtual DbSet<BarnType> BarnType { get; set; }
        public virtual DbSet<VGetEnhetAdresse> VGetEnhetAdresse { get; set; }
        public virtual DbSet<BestillingnAarsakType> BestillingnAarsakType { get; set; }
        public virtual DbSet<BestillingType> BestillingType { get; set; }
        public virtual DbSet<BistandType> BistandType { get; set; }
        public virtual DbSet<HjemmelType> HjemmelType { get; set; }
        public virtual DbSet<VedtakFattetAvnHjemmel> VedtakFattetAv_n_Hjemmel { get; set; }
        public virtual DbSet<VedtakFattetAvType> VedtakFattetAvType { get; set; }
        public virtual DbSet<VedtakOmType> VedtakOmType { get; set; }
        public virtual DbSet<AarsakType> AarsakType { get; set; }

        public virtual DbSet<Fylke> Fylke { get; set; }
        public virtual DbSet<Kommune> Kommune { get; set; }
        public virtual DbSet<Region> Region { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<VGetEnhetAdresse>(entity =>
            {
                entity
                    .HasNoKey()
                    .ToView("vGetEnhetAdresse");

                entity.Property(e => e.Adresse).HasMaxLength(500);
                entity.Property(e => e.AdresseType)
                    .IsRequired()
                    .HasMaxLength(255);
                entity.Property(e => e.BekreftetAdresseDato).HasColumnType("date");
                entity.Property(e => e.Bydelpk).HasColumnName("bydelpk");
                entity.Property(e => e.Bydelsnavn)
                    .HasMaxLength(255)
                    .HasColumnName("bydelsnavn");
                entity.Property(e => e.BydelsnavnMedParentes)
                    .HasMaxLength(257)
                    .HasColumnName("bydelsnavnMedParentes");
                entity.Property(e => e.EnhetPk).HasColumnName("EnhetPK");
                entity.Property(e => e.EnhetsType)
                    .IsRequired()
                    .HasMaxLength(255);
                entity.Property(e => e.Enhetsnavn).HasMaxLength(255);
                entity.Property(e => e.EnhetsnavnOgBydelsnavn).HasMaxLength(513);
                entity.Property(e => e.Epost).HasMaxLength(255);
                entity.Property(e => e.Jobbtlf).HasMaxLength(255);
                entity.Property(e => e.KommunePk).HasColumnName("KommunePK");
                entity.Property(e => e.Kommunenavn).HasMaxLength(50);
                entity.Property(e => e.Mobil).HasMaxLength(255);
                entity.Property(e => e.Postnummer).HasMaxLength(4);
                entity.Property(e => e.Poststed).HasMaxLength(355);
                entity.Property(e => e.Telefon).HasMaxLength(255);
                entity.Property(e => e.Virksomhetstype)
                    .IsRequired()
                    .HasMaxLength(255);
                entity.Property(e => e.Virksomhettypefk).HasColumnName("virksomhettypefk");
            });

            // Mapping required to avoid class names with special characters ('å') while db table names contain some
            modelBuilder.Entity<BestillingnAarsakType>(entity =>
            {
                entity.HasKey(e => e.BestillingnAarsakTypePk);
                entity.Property(e => e.BestillingnAarsakTypePk).HasColumnName("Bestilling_n_ÅrsakTypePk");
                entity.Property(e => e.AarsakTypeFk).HasColumnName("ÅrsakTypeFk");
                entity.ToTable("Bestilling_n_ÅrsakType");
            });

            modelBuilder.Entity<AarsakType>(entity =>
            {
                entity.HasKey(e => e.AarsakTypePk);
                entity.Property(e => e.AarsakTypePk).HasColumnName("ÅrsakTypePk");
                entity.ToTable("ÅrsakType");
            });

            modelBuilder.Entity<Fylke>(entity =>
            {
                entity.HasKey(e => e.FylkePk);

                entity.HasIndex(e => e.RegionFk, "IX_Fylke_Region").HasFillFactor(90);

                entity.Property(e => e.FylkePk)
                    .ValueGeneratedNever()
                    .HasColumnName("FylkePK");
                entity.Property(e => e.Endretdato)
                    .HasDefaultValueSql("(getdate())")
                    .HasColumnType("datetime");
                entity.Property(e => e.Navn).HasMaxLength(255);
                entity.Property(e => e.RegionFk).HasColumnName("RegionFK");

                entity.HasOne(d => d.RegionFkNavigation).WithMany(p => p.Fylke)
                    .HasForeignKey(d => d.RegionFk)
                    .HasConstraintName("FK_Fylke_Region");
            });

            modelBuilder.Entity<Kommune>(entity =>
            {
                entity.HasKey(e => e.KommunePk);

                entity.ToTable(tb => tb.HasTrigger("tr_KommuneEndringer"));

                entity.HasIndex(e => e.InntaksenhetFk, "IX_Kommune").HasFillFactor(90);

                entity.HasIndex(e => e.BufRegionFk, "IX_Kommune_BufRegion").HasFillFactor(90);

                entity.HasIndex(e => e.FylkeFk, "IX_Kommune_Fylke").HasFillFactor(90);

                entity.HasIndex(e => new { e.Kommunenummer, e.BufRegionFk }, "IX_Kommune_Kommunenummer_BufregionFK").HasFillFactor(90);

                entity.HasIndex(e => e.BufRegionFk, "_dta_index_Kommune_bUFREGIONfk_INNTAKSENHETFK").HasFillFactor(90);

                entity.HasIndex(e => new { e.Kommunenummer, e.BufRegionFk }, "_dta_index_Kommune_kommunenummer_bugregionfk_KommunePK").HasFillFactor(90);

                entity.Property(e => e.KommunePk).HasColumnName("KommunePK");
                entity.Property(e => e.BufRegionFk).HasColumnName("BufRegionFK");
                entity.Property(e => e.EndretAv).HasMaxLength(50);
                entity.Property(e => e.EndretDato).HasColumnType("datetime");
                entity.Property(e => e.ErBydelObligatorisk)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
                entity.Property(e => e.FakturaReferanse).HasMaxLength(50);
                entity.Property(e => e.Fradato).HasColumnType("date");
                entity.Property(e => e.FylkeFk).HasColumnName("FylkeFK");
                entity.Property(e => e.Kommunenavn).HasMaxLength(50);
                entity.Property(e => e.Kommunenummer).HasMaxLength(355);
                entity.Property(e => e.Kundenummer).HasMaxLength(50);
                entity.Property(e => e.RegAv)
                    .HasMaxLength(50)
                    .HasDefaultValueSql("(suser_sname())");
                entity.Property(e => e.RegDato)
                    .HasDefaultValueSql("(getdate())")
                    .HasColumnType("datetime");
                entity.Property(e => e.Tildato).HasColumnType("date");

                entity.HasOne(d => d.FylkeFkNavigation).WithMany(p => p.Kommune)
                    .HasForeignKey(d => d.FylkeFk)
                    .HasConstraintName("FK_Kommune_Fylke");
                entity.Property(e => e.Rekkefolge).HasColumnName("Rekkefølge");
            });

            modelBuilder.Entity<Region>(entity =>
            {
                entity.HasKey(e => e.RegionPk);

                entity.ToTable(tb => tb.HasTrigger("tr_RegionEndringer"));

                entity.Property(e => e.RegionPk).HasColumnName("RegionPK");
                entity.Property(e => e.Beskrivelse).HasMaxLength(50);
                entity.Property(e => e.EndretAv).HasMaxLength(50);
                entity.Property(e => e.EndretDato).HasColumnType("datetime");
                entity.Property(e => e.RegAv)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("(suser_sname())");
                entity.Property(e => e.RegDato)
                    .HasDefaultValueSql("(getdate())")
                    .HasColumnType("datetime");
                entity.Property(e => e.Verdi)
                    .IsRequired()
                    .HasMaxLength(255);
            });
        }
    }
}
