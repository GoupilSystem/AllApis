﻿namespace BirkKodeverkAPI.Api.Enums
{
    public enum FilterKey
    {
        None,
        KommunePk,
        Kommunenavn,
        Kommunenummer
    }
}
