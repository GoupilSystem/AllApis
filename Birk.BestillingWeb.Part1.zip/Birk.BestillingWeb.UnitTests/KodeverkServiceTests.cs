using Birk.Client.Bestilling.Models.Dtos;
using Birk.Client.Bestilling.Models.HttpResults;
using Birk.Client.Bestilling.Services.Implementation;
using Birk.Client.Bestilling.Services.Interfaces;
using Birk.Client.Bestilling.Utils.Constants;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using System.Net;

namespace Birk.BestillingWeb.UnitTests
{
    public class KodeverkServiceTests
    {
        private readonly KodeverkService _kodeverkService;
        private readonly Mock<IHttpService> _httpServiceMock;
        private readonly Logger<KodeverkService> _nullLogger;

        public KodeverkServiceTests()
        {
            _httpServiceMock = new Mock<IHttpService>();
            _nullLogger = new Logger<KodeverkService>(new NullLoggerFactory());
            _kodeverkService = new KodeverkService(_httpServiceMock.Object, _nullLogger);
        }

        [Fact]
        public async Task GetTypes_ReturnsArrayOfStrings_WhenResponseIsSuccess_Test()
        {
            // Arrange
            var expectedData = new List<BestillingTypeSimpleDto>()
            {
                new BestillingTypeSimpleDto() { Verdi = "Type1" },
                new BestillingTypeSimpleDto() { Verdi = "Type2" },
            };
            var response = new HttpResult<List<BestillingTypeSimpleDto>>(true, expectedData);
            _httpServiceMock.Setup(x => x.HttpGet<List<BestillingTypeSimpleDto>>("bestillingtypes")).ReturnsAsync(response);

            // Act
            await _kodeverkService.FetchBestillingstypes();
            var result = _kodeverkService.GetBestillingstypeVerdis();

            // Assert
            Assert.Equal(expectedData.Select(bt => bt.Verdi).ToArray(), result);
        }

        [Fact]
        public async Task GetTypes_ReturnsArrayOfOneString_WhenResponseIsNotSuccess_Test()
        {
            // Arrange
            var response = new HttpResult<List<BestillingTypeSimpleDto>>(false, null);
            _httpServiceMock.Setup(x => x.HttpGet<List<BestillingTypeSimpleDto>>("bestillingtypes")).ReturnsAsync(response);

            // Act
            await _kodeverkService.FetchBestillingstypes();
            var result = _kodeverkService.GetBestillingstypeVerdis();

            // Assert
            Assert.Equal(new[] { Language.NO["NoData"] }, result);
        }

        [Fact]
        public async Task GetKommunesAndBarneverntjenestes_WhenResponsesAreSuccess_PopulatesKomAndBarFields()
        {
            // Arrange
            var expectedKommunes = new List<KommuneSimpleDto>()
            {
                new KommuneSimpleDto() { Navn = "Kommune1" },
                new KommuneSimpleDto() {  Navn = "Kommune2" },
            };
            var kommuneResponse = new HttpResult<List<KommuneSimpleDto>>(true, expectedKommunes);
            _httpServiceMock.Setup(x => x.HttpGet<List<KommuneSimpleDto>>("kommunes")).ReturnsAsync(kommuneResponse);

            var expectedBarneverntjenestes = new List<BvtjenesteSimpleDto>()
            {
                new BvtjenesteSimpleDto() { EnhetsnavnOgBydelsnavn = "Tjeneste 1", Kommunenavns = new[] { "Kommune 1" } },
                new BvtjenesteSimpleDto() { EnhetsnavnOgBydelsnavn = "Tjeneste 2", Kommunenavns = new[] { "Kommune 2" } },
            };

            // !!: We expect BarneverntjenesteSimpleDto type from the service but during the process we get TempBarneverntjenesteDto type from KodeverkApi
            var tempBarneverntjenestes = new List<TempBvtjenesteDto>();
            for (int i = 0; i < expectedBarneverntjenestes.Count; i++)
            {
                tempBarneverntjenestes.Add(new TempBvtjenesteDto()
                {
                    EnhetsnavnOgBydelsnavn = expectedBarneverntjenestes[i].EnhetsnavnOgBydelsnavn,
                    Kommunenavn = expectedBarneverntjenestes[i].Kommunenavns[0]
                });
            }
            var tempBarneverntjenesteResponse = new HttpResult<List<TempBvtjenesteDto>>(true, tempBarneverntjenestes);
            _httpServiceMock.Setup(x => x.HttpGet<List<TempBvtjenesteDto>>("barneverntjenestes")).ReturnsAsync(tempBarneverntjenesteResponse);

            // Act
            await _kodeverkService.FetchKommunesAndBvtjenestes();

            // Assert
            Assert.Equal(expectedKommunes.Select(k => k.Navn).ToArray(), _kodeverkService.GetKommuneNavns());
            Assert.Equal(expectedBarneverntjenestes.Select(bt => bt.EnhetsnavnOgBydelsnavn).ToArray(), _kodeverkService.GetBvtjenesteNavns());
        }

        [Fact]
        public async Task GetKommunesAndBarneverntjenestes_ShouldNotSetKomAndBarArrays_WhenApiResponseIsNotSuccessful()
        {
            // Arrange
            _httpServiceMock.Setup(s => s.HttpGet<List<KommuneSimpleDto>>("kommunes"))
                           .ReturnsAsync(new HttpResult<List<KommuneSimpleDto>>(false, null));

            // Act
            await _kodeverkService.FetchKommunesAndBvtjenestes();

            // Assert
            string[] actualKommunes = _kodeverkService.GetKommuneNavns();
            string[] actualBarneverntjenestes = _kodeverkService.GetBvtjenesteNavns();

            Assert.NotNull(actualKommunes);
            Assert.NotNull(actualBarneverntjenestes);

            string[] expected = new[] { Language.NO["NoData"] };

            Assert.True(actualKommunes.SequenceEqual(expected));
            Assert.True(actualBarneverntjenestes.SequenceEqual(expected));
        }
    }
}