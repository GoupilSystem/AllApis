﻿using System.ComponentModel;

namespace Birk.BarnAPI.Dto
{
    public class PersonDto
    {
        public int Pk { get; set; }
        public int? PartyFk { get; set; }

        // Foreign keys
        public int KjønnTypeFk { get; set; }
        public int? StatborgerskapFk { get; set; }
        public int? SivilstandTypeFk { get; set; }

        public string? Fornavn { get; set; }
        public string? Etternavn { get; set; }
        public DateTime? Født { get; set; }
        public string? Personnummer { get; set; }
        public string Fødselsnummer { get; set; }
        public bool IsPerson { get; set; } = true;
        public string RegAv { get; set; }
        public DateTime RegDato { get; set; }
        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
        public bool? UsikkerFødselsdato { get; set; }
        public bool? UsikkerFødselsnummer { get; set; }
        public string? Dufnummer { get; set; }
        public short? Død { get; set; }
    }

    public class UpdatePersonDto
    {
        // Foreign keys
        public int KjønnTypeFk { get; set; }
        public int? StatborgerskapFk { get; set; }
        public int? SivilstandTypeFk { get; set; }

        public string? Fornavn { get; set; }
        public string? Etternavn { get; set; }
        public DateTime? Født { get; set; }
        public string? Personnummer { get; set; }
        public bool IsPerson { get; set; } = true;
        public string RegAv { get; set; }
        public DateTime RegDato { get; set; }
        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
        public bool UsikkerFødselsdato { get; set; }
        public bool UsikkerFødselsnummer { get; set; }

        public UpdatePersonDto(UpdateBarnDto barnDto)
        {   
        }
    }

    public class CreatePersonDto
    {
        // Foreign keys
        [DefaultValue(1)]
        public int KjønnTypeFk { get; set; }
        [DefaultValue(null)]
        public int? StatborgerskapFk { get; set; }
        [DefaultValue(null)]
        public int? SivilstandTypeFk { get; set; }

        public string? Fornavn { get; set; }
        public string? Etternavn { get; set; }
        public DateTime Født { get; set; }
        [DefaultValue("11111")]
        public string Personnummer { get; set; }
        public bool IsPerson { get; set; } = true;
        public string RegAv { get; set; } = string.Empty;
        public DateTime RegDato { get; set; }
        public string? EndretAv { get; set; }
        public DateTime? EndretDato { get; set; }
        public bool UsikkerFødselsdato { get; set; }
        public bool UsikkerFødselsnummer { get; set; }
        public string? Dufnummer { get; set; }

        public CreatePersonDto() { }

        public CreatePersonDto(CreateBarnDto createBarnDto)
        {
            KjønnTypeFk = createBarnDto.KjønnTypeFk;
            SivilstandTypeFk = createBarnDto.SivilstandTypeFk;
            Fornavn = createBarnDto.Fornavn;
            Etternavn = createBarnDto.Etternavn;
            Født = createBarnDto.Født;
            Personnummer = createBarnDto.Personnummer;
            RegAv = createBarnDto.RegAv;
            RegDato = createBarnDto.RegDato;
            EndretAv = createBarnDto.EndretAv;
            EndretDato = createBarnDto.EndretDato;
            UsikkerFødselsdato = createBarnDto.UsikkerFødselsdato;
            UsikkerFødselsnummer = createBarnDto.UsikkerFødselsnummer;
            Dufnummer = createBarnDto.Dufnummer;
    }
    }

}