﻿using Birk.BarnAPI.Core.Utils;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

namespace Birk.BarnAPI.Dto.Validation
{
    static class ValidationExtension
    {
        [GeneratedCode("System.Text.RegularExpressions", "2.0.0.0"), CompilerGenerated, DebuggerNonUserCode]
        private static class FnrRegex
        {
            public static readonly Regex Value = new Regex("^[0-9]{11}$", RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.CultureInvariant);
        }

        private static class PersonnummerRegex
        {
            public static readonly Regex Value = new Regex("^[0-9]{5}$", RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.CultureInvariant);
        }

        public static bool BeAValidPk(int? argValue)
        {
            return argValue >= 0;
        }

        public static bool BeAValidBirkId(string? argValue)
        {
            if (argValue == null) return false;
            
            var subValues = argValue.Split("-");
            if (subValues.Length != 2 || subValues[0].IndexOf("b", StringComparison.CurrentCultureIgnoreCase) != 0)
            {
                return false;
            }

            subValues[0] = subValues[0].Remove(0, 1);
            for (int i = 0; i < subValues.Length; i++)
            {
                Match match = Regex.Match(subValues[i], i == 0 ? @"^[0-9]{3}$" : @"^[0-9]{4}$");
                if (!match.Success)
                {
                    return false;
                }
            }

            return true;
        }

        public static bool BeAValidFnr(string? fnr)
        {
            if (string.IsNullOrEmpty(fnr)) return false;

            return FnrRegex.Value.IsMatch(fnr);
        }

        public static bool BeAValidDate(DateTime date)
        {
            return !date.Equals(default(DateTime));
        }

        public static bool BeAValidPersonnummer(string? personnummer)
        {
            if (string.IsNullOrEmpty(personnummer)) return false;

            return PersonnummerRegex.Value.IsMatch(personnummer);
        }

        public static string Message(ValidationType validationType)
        {
            switch (validationType)
            {
                case ValidationType.Pk: return string.Format(ApiDict.NO["NegativeNumberError"],
                    ValidationType.Pk.ToString(), "a positive number");
                
                case ValidationType.Fnr: 
                    return string.Format(ApiDict.NO["FormatError"],
                    ValidationType.Fnr.ToString(), "a 11 digits number");
                
                case ValidationType.BirkId: 
                    return string.Format(ApiDict.NO["FormatError"],
                    ValidationType.BirkId.ToString(), "type Bxxx-xxxx where x is a 0-9 digit");

                case ValidationType.Date:
                    return string.Format(ApiDict.NO["FormatError"],
                    ValidationType.Date.ToString(), "valid date with format yyyy-mm-dd");

                case ValidationType.Personnummer:
                    return string.Format(ApiDict.NO["FormatError"],
                    ValidationType.Personnummer.ToString(), "valid personnummer with format xxxxx where x is a 0-9 digit");

                case ValidationType.FødtOgPersonnummer:
                    return string.Format(ApiDict.NO["FormatError"], "Født and personnummer",
                    "a valid date with format yyyy-mm-dd and a valid personnummer with format xxxxx where x is a 0-9 digit");

                default: return ApiDict.NO["UnknownValidationError"];
            }
        }
    }
}
