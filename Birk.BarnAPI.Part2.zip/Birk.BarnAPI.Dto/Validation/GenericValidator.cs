﻿using FluentValidation;

namespace Birk.BarnAPI.Dto.Validation
{
    public class GenericValidator : AbstractValidator<GenericArgument>
    {
        public GenericValidator()
        {
            RuleFor(x => x.NumValue).Must(ValidationExtension.BeAValidPk)
                .When(x => x.ArgType == ValidationType.Pk)
                .WithMessage(x => ValidationExtension.Message(x.ArgType));

            RuleFor(x => x.AlphaValue).Must(ValidationExtension.BeAValidFnr)
                .When(x => x.ArgType == ValidationType.Fnr)
                .WithMessage(x => ValidationExtension.Message(x.ArgType));

            RuleFor(x => x.AlphaValue).Must(ValidationExtension.BeAValidBirkId)
                .When(x => x.ArgType == ValidationType.BirkId)
                .WithMessage(x => ValidationExtension.Message(x.ArgType));

            When(x => x.ArgType == ValidationType.FødtOgPersonnummer, () =>
            {
                RuleFor(x => new { x.DateValue, x.AlphaValue })
                    .Must(m => ValidationExtension.BeAValidDate(m.DateValue))
                    .Must(m => ValidationExtension.BeAValidPersonnummer(m.AlphaValue))
                    .WithMessage(x => ValidationExtension.Message(x.ArgType));
            });
        }
    }
}
