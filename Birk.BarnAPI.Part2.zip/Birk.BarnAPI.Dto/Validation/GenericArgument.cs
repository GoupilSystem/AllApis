﻿namespace Birk.BarnAPI.Dto.Validation
{
    public class GenericArgument
    {
        public ValidationType ArgType { get; set; }
        public string? AlphaValue { get; set; }
        public int? NumValue { get; set; }
        public DateTime DateValue { get; set; }

        public GenericArgument(ValidationType argType, string? alphaValue)
        {
            ArgType = argType;
            AlphaValue = alphaValue;
        }

        public GenericArgument(ValidationType argType, int? numValue)
        {
            ArgType = argType;
            NumValue = numValue;
        }

        public GenericArgument(ValidationType argType, DateTime dateValue, string? alphaValue)
        {
            ArgType = argType;
            DateValue = dateValue;
            AlphaValue = alphaValue;
        }
    }
}
