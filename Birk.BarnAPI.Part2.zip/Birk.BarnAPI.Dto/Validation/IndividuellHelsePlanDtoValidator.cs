﻿using Birk.BarnAPI.Core.Utils;
using FluentValidation;

namespace Birk.BarnAPI.Dto.Validation
{
    public class IndividuellHelsePlanDtoValidator : AbstractValidator<IndividuellHelsePlanDto>
    {
        public IndividuellHelsePlanDtoValidator()
        {
            RuleFor(x => x.BarnFk).NotNull()
                .Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["NullZeroNumberError"], "BarnFk"));
            RuleFor(x => x.RegAv).NotNull();
            RuleFor(x => x.RegDato).NotNull();
        }
    }
}
