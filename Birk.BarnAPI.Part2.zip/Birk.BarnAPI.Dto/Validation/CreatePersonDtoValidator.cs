﻿using Birk.BarnAPI.Core.Utils;
using FluentValidation;

namespace Birk.BarnAPI.Dto.Validation
{
    public class CreatePersonDtoValidator : AbstractValidator<CreatePersonDto>
    {
        public CreatePersonDtoValidator()
        {
            RuleFor(x => x.IsPerson).NotEmpty();
            RuleFor(x => x.UsikkerFødselsdato).NotNull();
            RuleFor(x => x.UsikkerFødselsnummer).NotNull();
            RuleFor(x => x.Født).Must(ValidationExtension.BeAValidDate)
                .WithMessage(ValidationExtension.Message(ValidationType.Date));
            RuleFor(x => x.Personnummer).Must(ValidationExtension.BeAValidPersonnummer)
                .WithMessage(ValidationExtension.Message(ValidationType.Personnummer));
            RuleFor(x => x.RegAv).NotNull();
            RuleFor(x => x.RegDato).NotNull();
            RuleFor(x => x.KjønnTypeFk).NotNull()
                .Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["NullZeroNumberError"], "KjønnTypeFk"));
            RuleFor(x => x.SivilstandTypeFk).Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["ZeroNumberError"], "SivilstandTypeFk"));
        }
    }
}
