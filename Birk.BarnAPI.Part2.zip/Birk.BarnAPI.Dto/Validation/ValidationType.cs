﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Birk.BarnAPI.Dto.Validation
{
    public enum ValidationType
    {
        Pk,
        Fnr,
        FødtOgPersonnummer,
        BirkId,
        Date,
        Personnummer,
        BarnType,
        EtnisitetType,
        FolkeGruppeType,
        SpråkType,
        OpprinnelseslandType,
        ReligionType,
        StatborgerskapType,
        Trossamfunn,
        VerdensdelType,
        VerdensregionType,
        KjønnType,
        Statborgerskap,
        SivilstandType
    }
}
