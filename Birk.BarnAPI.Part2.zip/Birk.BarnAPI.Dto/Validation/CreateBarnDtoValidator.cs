﻿using Birk.BarnAPI.Core.Utils;
using FluentValidation;

namespace Birk.BarnAPI.Dto.Validation
{
    public class CreateBarnDtoValidator : AbstractValidator<CreateBarnDto>
    {
        public CreateBarnDtoValidator()
        {
            // CreateBarnDto not null
            RuleFor(x => x).NotNull();
            // Foreign keys which ane nullable but can't be = 0 in db
            RuleFor(x => x.BarnTypeFk).NotNull()
                .Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["NullZeroNumberError"], "BarnTypeFk"));
            RuleFor(x => x.EtnisitetTypeFk).Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["ZeroNumberError"], "EtnisitetTypeFk"));
            RuleFor(x => x.FolkeGruppeTypeFk).Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["ZeroNumberError"], "FolkeGruppeTypeFk"));
            RuleFor(x => x.ReligionTypeFk).Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["ZeroNumberError"], "ReligionTypeFk"));
            RuleFor(x => x.TrosamfunnFk).Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["ZeroNumberError"], "TrosamfunnFk"));
            RuleFor(x => x.VerdensdelTypeFk).Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["ZeroNumberError"], "VerdensdelTypeFk"));
            RuleFor(x => x.VerdensregionTypeFk).Must(x => x != 0)
                .WithMessage(string.Format(ApiDict.NO["ZeroNumberError"], "VerdensregionTypeFk"));

            // Person
            RuleFor(x => new CreatePersonDto(x)).SetValidator(new CreatePersonDtoValidator());
        }
    }
}
