﻿using Ardalis.Specification.EntityFrameworkCore;
using Birk.BarnAPI.SharedKernel.Interfaces;

namespace Birk.BarnAPI.Infrastructure.Data
{
    public class EfRepository<T> : RepositoryBase<T>, IReadRepository<T>, IRepository<T> where T : class, IAggregateRoot
    {
        public EfRepository(BarnDbContext barnDbContext) : base(barnDbContext)
        {
        }
    }
}