﻿namespace Birk.BarnAPI.Core.ProjectAggregate
{
    public partial class IndividuellHelsePlan
    {
        public void UpdateFrom(IndividuellHelsePlan source)
        {
            Koordinator = source.Koordinator;
            KoordinatorArbeidsted = source.KoordinatorArbeidsted;
            Merknad = source.Merknad;
            GyldigFraDato = source.GyldigFraDato;
            GyldigTilDato = source.GyldigTilDato;
            EndretAv = source.EndretAv;
            EndretDato = source.EndretDato;
            IndividuellHelsePlanStatusTypeFk = source.IndividuellHelsePlanStatusTypeFk;
            BehandletFerdigDato = source.BehandletFerdigDato;
        }
    }
}
