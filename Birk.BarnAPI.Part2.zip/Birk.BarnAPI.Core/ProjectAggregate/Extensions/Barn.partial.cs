﻿namespace Birk.BarnAPI.Core.ProjectAggregate
{
    public partial class Barn
    {
        public void AddOrUpdateHelsePlan(IndividuellHelsePlan newPlan)
        {
            // If there already are existing plan for barn and pkToUpdate is not zero: update
            var pkToUpdate = newPlan.IndividuellHelsePlanPk;
            if (IndividuellHelsePlan != null && pkToUpdate != 0)
            {
                var existingPlan = IndividuellHelsePlan.FirstOrDefault(p => p.IndividuellHelsePlanPk == pkToUpdate);
                if (existingPlan != null)
                {
                    existingPlan.UpdateFrom(newPlan);
                    return;
                }
            }

            // Create a plan
            IndividuellHelsePlan.Add(newPlan);
        }
    }
}
