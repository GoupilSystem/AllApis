﻿using Birk.BarnAPI.SharedKernel.Interfaces;
using Birk.BarnAPI.SharedKernel;

namespace Birk.BarnAPI.Core.ProjectAggregate;

public partial class BarnOgPerson : EntityBase, IAggregateRoot
{
    public int BarnPk { get; set; }

    public int BarnTypeFk { get; set; }

    public string BirkId { get; set; }

    public string RegAv { get; set; }

    public DateTime RegDato { get; set; }

    public string EndretAv { get; set; }

    public DateTime? EndretDato { get; set; }

    public string Fornavn { get; set; }

    public string Etternavn { get; set; }

    public int KjønnTypeFk { get; set; }

    public DateTime? Født { get; set; }

    public string Fødselsnummer { get; set; }

    public string Personnummer { get; set; }

    public bool HasExistingIndividuellHelsePlan { get; set; }
}