﻿using Ardalis.Specification;

namespace Birk.BarnAPI.Core.ProjectAggregate.Specifications
{
    public class BarnByStatusSpec : Specification<Barn>
    {
        public BarnByStatusSpec(int barnStatusType)
        {
            Query.Where(b => b.BarnStatusTypeFk == barnStatusType);

        }
    }
}