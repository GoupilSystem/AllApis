﻿using Ardalis.Specification;
using Birk.BarnAPI.Core.ProjectAggregate;

namespace Birk.BarnAPI.Core.ProjectAggregate.Specifications;

public class BarnByPkSpec : Specification<Barn>, ISingleResultSpecification
{
    public BarnByPkSpec(int barnPk)
    {
        Query
            .Include(b => b.IndividuellHelsePlan)
            .Where(b => b.BarnPk == barnPk);
    }
}
