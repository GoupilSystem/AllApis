﻿using Ardalis.Specification;
using Birk.BarnAPI.Core.ProjectAggregate;
using Microsoft.Extensions.Logging;

namespace Birk.BarnAPI.Core.ProjectAggregate.Specifications;

public class BarnByFnrSpec : Specification<Barn>, ISingleResultSpecification
{
    public BarnByFnrSpec(string fnr)
    {
        Query
            .Include(b => b.PersonFkNavigation)
            .Include(b => b.IndividuellHelsePlan)
            .Where(b => b.PersonFkNavigation.Fødselsnummer == fnr);
    }
}
