﻿using Ardalis.Specification;
using Birk.BarnAPI.Core.ProjectAggregate;

namespace Birk.BarnAPI.Core.ProjectAggregate.Specifications;

public class BarnByBirkIdSpec : Specification<Barn>, ISingleResultSpecification
{
    public BarnByBirkIdSpec(string birkId)
    {
        Query.Where(b => b.BirkId.Trim().ToLower() == birkId.Trim().ToLower());
    }
}
