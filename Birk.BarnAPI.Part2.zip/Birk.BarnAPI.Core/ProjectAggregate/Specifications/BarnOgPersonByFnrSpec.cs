﻿using Ardalis.Specification;
using Birk.BarnAPI.Core.ProjectAggregate;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;

namespace Birk.BarnAPI.Core.ProjectAggregate.Specifications;

public class BarnOgPersonByFnrSpec : Specification<Barn, BarnOgPerson>, ISingleResultSpecification<Barn, BarnOgPerson>
{
    public BarnOgPersonByFnrSpec(string fnr)
    {
        Query
            .Include(b => b.PersonFkNavigation)
            .Include(b => b.IndividuellHelsePlan)
            .Where(b => b.PersonFkNavigation.Fødselsnummer == fnr);

        Selector = barn => new BarnOgPerson
        {
            BarnPk = barn.BarnPk,
            BarnTypeFk = barn.BarnTypeFk,
            BirkId = barn.BirkId,
            RegAv = barn.RegAv,
            RegDato = barn.RegDato,
            EndretAv = barn.EndretAv,
            EndretDato = barn.EndretDato,
            Fornavn = barn.PersonFkNavigation.Fornavn,
            Etternavn = barn.PersonFkNavigation.Etternavn,
            KjønnTypeFk = barn.PersonFkNavigation.KjønnTypeFk,
            Født = barn.PersonFkNavigation.Født,
            Fødselsnummer = barn.PersonFkNavigation.Fødselsnummer,
            Personnummer = barn.PersonFkNavigation.Personnummer,
            HasExistingIndividuellHelsePlan = barn.IndividuellHelsePlan.Count > 0,
        };
    }

    public Expression<Func<Barn, BarnOgPerson>> Selector { get; }
}
