﻿using Ardalis.Specification;
using Birk.BarnAPI.Core.ProjectAggregate;
using Microsoft.Extensions.Logging;

namespace Birk.BarnAPI.Core.ProjectAggregate.Specifications;

public class PersonByFnrSpec : Specification<Person>, ISingleResultSpecification
{
    public PersonByFnrSpec(string fnr)
    {
        Query.Where(p => p.Fødselsnummer == fnr);
    }
}