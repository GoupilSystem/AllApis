﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Birk.BarnAPI.Core.Utils
{
    public static class ApiDict
    {
        

        public static ReadOnlyDictionary<string, string> NO
        {
            get { return _NO; }
        }

        private static readonly ReadOnlyDictionary<string, string> _NO = new ReadOnlyDictionary<string, string>(new Dictionary<string, string>() 
        { 
        
            // Error messages
            { "EmptyError", "{0} is required" },
            { "FormatError", "{0} must be {1}" },
            { "UnknknowValidationError", "Unknown validation error" },
            { "NoNumberError", "{0} must be a number" },
            { "NegativeNumberError", "{0} must be a positive number" },
            { "NullZeroNumberError", "{0} can't be null or equal to 0" },
            { "ZeroNumberError", "{0} can't be equal to 0" },
        });
    }
}
