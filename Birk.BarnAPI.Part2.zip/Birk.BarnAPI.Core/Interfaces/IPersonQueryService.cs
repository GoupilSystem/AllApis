﻿using Ardalis.Result;
using Birk.BarnAPI.Core.ProjectAggregate;

namespace Birk.BarnAPI.Core.Interfaces
{
    /// <summary>
    /// Service for all operations that only retrieves data.
    /// </summary>
    public interface IPersonQueryService
    {
        Task<Result<Person>> GetPersonByFnr(string fnr, CancellationToken cancellationToken = default);
        Task<Result<Person>> GetPersonByFødtOgPersonnummer(DateTime født, string personnummer, CancellationToken cancellationToken = default);
    }
}