﻿using Ardalis.Result;
using Birk.BarnAPI.Core.ProjectAggregate;

namespace Birk.BarnAPI.Core.Interfaces
{
    /// <summary>
    /// Interface for all operations that manipulates data />.
    /// </summary>
    public interface IPersonCommandService
    {
        Task<Result<Person>> CreatePerson(Person person, CancellationToken cancellationToken = default);
    }
}