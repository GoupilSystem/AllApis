﻿using Ardalis.Result;
using Birk.BarnAPI.Core.ProjectAggregate;

namespace Birk.BarnAPI.Core.Interfaces
{
    public interface IBarnCommandService
    {
        Task<Result<Barn>> AddOrUpdateHelsePlan(IndividuellHelsePlan helsePlan, bool canUpdate, CancellationToken cancellationToken = default);
    }
}