﻿using Ardalis.Result;
using Birk.BarnAPI.Core.ProjectAggregate;

namespace Birk.BarnAPI.Core.Interfaces
{
    /// <summary>
    /// Service for all operations that only retrieves data.
    /// </summary>
    public interface IBarnQueryService
    {
        Task<Result<List<Barn>>> GetBarns(int barnsTypeFk, CancellationToken cancellationToken = default);
        Task<Result<Barn>> GetBarnByPk(int pk, CancellationToken cancellationToken = default);
        Task<Result<Barn>> GetBarnByBirkId(string birkId, CancellationToken cancellationToken = default);
        Task<Result<Barn>> GetBarnByFnr(string fnr, CancellationToken cancellationToken = default);
        Task<Result<BarnOgPerson>> GetBarnOgPersonByFnr(string fnr, CancellationToken cancellationToken = default);
    }
}