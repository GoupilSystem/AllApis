﻿using Autofac;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Core.Services.CommandServices;
using Birk.BarnAPI.Core.Services.QueryServices;

namespace Birk.BarnAPI.Core;

public class DefaultCoreModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterType<BarnCommandService>()
            .As<IBarnCommandService>()
            .InstancePerLifetimeScope();

        builder.RegisterType<BarnSearchService>()
            .As<IBarnQueryService>()
            .InstancePerLifetimeScope();

        builder.RegisterType<PersonCommandService>()
            .As<IPersonCommandService>()
            .InstancePerLifetimeScope();

        builder.RegisterType<PersonSearchService>()
            .As<IPersonQueryService>()
            .InstancePerLifetimeScope();
    }
}
