﻿using Ardalis.Result;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.SharedKernel.Interfaces;

namespace Birk.BarnAPI.Core.Services.CommandServices
{
    public class PersonCommandService : IPersonCommandService
    {
        private readonly IRepository<Person> _repository;

        public PersonCommandService(IRepository<Person> repository)
        {
            _repository = repository;
        }

        public async Task<Result<Person>> CreatePerson(Person person, CancellationToken cancellationToken = default)
        {
            var createdPerson = await _repository.AddAsync(person, cancellationToken);

            if (createdPerson == null)
            {
                return Result<Person>.NotFound();
            }

            return new Result<Person>(createdPerson);
        }
    }
}
