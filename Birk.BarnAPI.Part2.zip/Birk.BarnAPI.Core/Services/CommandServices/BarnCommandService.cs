﻿using Ardalis.Result;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Core.ProjectAggregate.Specifications;
using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.SharedKernel.Interfaces;

namespace Birk.BarnAPI.Core.Services.CommandServices
{
    public class BarnCommandService : IBarnCommandService
    {
        private readonly IRepository<Barn> _repository;

        public BarnCommandService(IRepository<Barn> repository)
        {
            _repository = repository;
        }

        public async Task<Result<Barn>> AddOrUpdateHelsePlan(IndividuellHelsePlan helsePlan, bool canUpdate, CancellationToken cancellationToken = default)
        {
            var barnSpec = new BarnByPkSpec(helsePlan.BarnFk);
            var barn = await _repository.FirstOrDefaultAsync(barnSpec, cancellationToken);

            if (barn == null)
            {
                return Result<Barn>.NotFound();
            }
            
            // Cyril Besnard 21.11.2023: Bestillingsveiviser manages only creation of new IndivciduellHelsePlan,
            // it doesn't manage update of already existing plan(s) yet
            if (!canUpdate && barn.IndividuellHelsePlan != null && barn.IndividuellHelsePlan.Count > 0)
            {
                return Result<Barn>.Forbidden();
            }

            barn.AddOrUpdateHelsePlan(helsePlan);

            await _repository.SaveChangesAsync(cancellationToken);
            
            return Result<Barn>.Success(barn);
        }
    }
}
