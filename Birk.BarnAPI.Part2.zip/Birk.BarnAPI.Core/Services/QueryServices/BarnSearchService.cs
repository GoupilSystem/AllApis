﻿using Ardalis.Result;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Core.ProjectAggregate.Specifications;
using Birk.BarnAPI.SharedKernel.Interfaces;
using Microsoft.Extensions.Logging;

namespace Birk.BarnAPI.Core.Services.QueryServices
{
    public class BarnSearchService : IBarnQueryService
    {
        private readonly IRepository<Barn> _repository;

        public BarnSearchService(IRepository<Barn> repository)
        {
            _repository = repository;
        }

        public async Task<Result<List<Barn>>> GetBarns(int barnsTypeFk, CancellationToken cancellationToken = default)
        {
            if (barnsTypeFk <= 0)
            {
                var errors = new List<ValidationError>
                {
                    new() { Identifier = nameof(barnsTypeFk), ErrorMessage = $"{nameof(barnsTypeFk)} is required." }
                };

                return Result<List<Barn>>.Invalid(errors);
            }

            var projectSpec = new BarnByStatusSpec(barnsTypeFk);
            var barns = await _repository.ListAsync(projectSpec, cancellationToken);

            return new Result<List<Barn>>(barns);
        }

        public async Task<Result<Barn>> GetBarnByPk(int pk, CancellationToken cancellationToken = default)
        {
            var barnSpec = new BarnByPkSpec(pk);
            var barn = await _repository.FirstOrDefaultAsync(barnSpec, cancellationToken);

            if (barn == null)
            {
                return Result<Barn>.NotFound();
            }

            return new Result<Barn>(barn);
        }

        public async Task<Result<Barn>> GetBarnByBirkId(string birkId, CancellationToken cancellationToken = default)
        {
            var barnSpec = new BarnByBirkIdSpec(birkId);
            var barn = await _repository.FirstOrDefaultAsync(barnSpec, cancellationToken);

            if (barn == null)
            {
                return Result<Barn>.NotFound();
            }

            return new Result<Barn>(barn);
        }

        public async Task<Result<Barn>> GetBarnByFnr(string fnr, CancellationToken cancellationToken = default)
        {
            var barnSpec = new BarnByFnrSpec(fnr);
            var barn = await _repository.FirstOrDefaultAsync(barnSpec, cancellationToken);

            if (barn == null)
            {
                return Result<Barn>.NotFound();
            }

            return new Result<Barn>(barn);
        }

        public async Task<Result<BarnOgPerson>> GetBarnOgPersonByFnr(string fnr, CancellationToken cancellationToken = default)
        {
            var barnOgPersonSpec = new BarnOgPersonByFnrSpec(fnr);
            var barnOgPerson = await _repository.FirstOrDefaultAsync(barnOgPersonSpec, cancellationToken);

            if (barnOgPerson == null)
            {
                return Result<BarnOgPerson>.NotFound();
            }

            return new Result<BarnOgPerson>(barnOgPerson);
        }

    }

}

