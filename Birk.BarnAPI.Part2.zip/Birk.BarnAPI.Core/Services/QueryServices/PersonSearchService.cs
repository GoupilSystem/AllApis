﻿using Ardalis.Result;
using Azure.Core;
using Birk.BarnAPI.Core.Interfaces;
using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Core.ProjectAggregate.Specifications;
using Birk.BarnAPI.SharedKernel.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Birk.BarnAPI.Core.Services.QueryServices
{
    public class PersonSearchService : IPersonQueryService
    {
        private readonly IRepository<Person> _repository;

        public PersonSearchService(IRepository<Person> repository)
        {
            _repository = repository;
        }

        public async Task<Result<Person>> GetPersonByFnr(string fnr, CancellationToken cancellationToken = default)
        {
            var personSpec = new PersonByFnrSpec(fnr);
            var person = await _repository.FirstOrDefaultAsync(personSpec, cancellationToken);

            if (person == null)
            {
                return Result<Person>.NotFound();
            }

            return new Result<Person>(person);
        }

        public async Task<Result<Person>> GetPersonByFødtOgPersonnummer(DateTime født, string personnummer,
            CancellationToken cancellationToken = default)
        {
            var fnr = født.ToString("ddMMyy") + personnummer;

            return await GetPersonByFnr(fnr, cancellationToken);
        }
    }
}
