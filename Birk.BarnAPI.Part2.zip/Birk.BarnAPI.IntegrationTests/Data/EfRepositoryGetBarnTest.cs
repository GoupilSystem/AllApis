﻿using Birk.BarnAPI.Core.ProjectAggregate;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace Birk.BarnAPI.IntegrationTests.Data;

public class EfRepositoryGetBarnTest : BaseEfRepoTestFixture
{
    [Fact]
    public async Task GetBarnByPkTest()
    {
        var repository = GetRepository();
        var barnPk = 2;
        var barn = new Barn()
        {
            BarnPk = barnPk,
            RegAv = "Person 2"
        };

        await repository.AddAsync(barn);

        // detach the item so we get a different instance
        _dbContext.Entry(barn).State = EntityState.Detached;

        var barnById = await repository.GetByIdAsync(barnPk);

        Assert.NotSame(barn, barnById);
        Assert.Equal(barn.BarnPk, barnById.BarnPk);
    }
}
