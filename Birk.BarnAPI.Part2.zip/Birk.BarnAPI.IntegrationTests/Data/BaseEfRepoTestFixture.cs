﻿using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Infrastructure.Data;
using Birk.BarnAPI.SharedKernel.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;

namespace Birk.BarnAPI.IntegrationTests.Data;

public abstract class BaseEfRepoTestFixture
{
    protected BarnDbContext _dbContext;

    protected BaseEfRepoTestFixture()
    {
        var options = CreateNewContextOptions();

        _dbContext = new BarnDbContext(options);
    }

    protected static DbContextOptions<BarnDbContext> CreateNewContextOptions()
    {
        // Create a fresh service provider, and therefore a fresh
        // InMemory database instance.
        var serviceProvider = new ServiceCollection()
            .AddEntityFrameworkInMemoryDatabase()
            .BuildServiceProvider();

        // Create a new options instance telling the context to use an
        // InMemory database and the new service provider.
        var builder = new DbContextOptionsBuilder<BarnDbContext>();
        builder.UseInMemoryDatabase("cleanarchitecture")
               .UseInternalServiceProvider(serviceProvider);

        return builder.Options;
    }

    protected EfRepository<Barn> GetRepository()
    {
        return new EfRepository<Barn>(_dbContext);
    }
}
