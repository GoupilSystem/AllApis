﻿using Ardalis.HttpClientTestExtensions;
using Ardalis.Result;
using Birk.BarnAPI.Core.ProjectAggregate;
using Birk.BarnAPI.Core.Utils;
using Birk.BarnAPI.Dto;
using Birk.BarnAPI.Web.Endpoints.BarnEndpoints;
using FluentValidation.Results;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using Xunit;

namespace Birk.BarnAPI.IntegrationTests
{
    public class ValidationResultAsErrors
    {
        public ValidationResultErrors Errors { get; set; }
        public string Title { get; set; }
        public int Status { get; set; }
    }

    public class ValidationResultErrors
    {
        public List<string> AlphaValue { get; set; }
        // Add other properties if needed for different error types
    }

    public class IntegrationTests
    {
        private readonly ApiApplication _app;
        private readonly HttpClient _client;

        public IntegrationTests()
        {
            // Arrange
            _app = new ApiApplication();
            _client = _app.CreateClient();
        }

        [Fact]
        public async Task GetBarnByPk_ReturnsNegativeNumberErrorTest()
        {
            // Arrange
            var barnPk = -1;

            // Act
            var result = await _client.GetAsync($"/Barn/{barnPk}");

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);

            var jsonResult = await result.Content.ReadAsStringAsync();
            Assert.NotNull(jsonResult);

            var validationResult = JsonConvert.DeserializeObject<ValidationResultAsErrors>(jsonResult);
            Assert.Equal(validationResult.Status, (int)HttpStatusCode.BadRequest);
        }

        [Fact]
        public async Task GetBarnByPk_ReturnsNotFoundTest()
        {
            // Arrange
            var pk = 0;

            // Act
            var result = await _client.GetAsync($"/Barn/{pk}");

            // Assert
            Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task GetBarnByBirkId_ReturnsInvalidFormatErrorTest()
        {
            // Arrange
            var birkId = "B0000-0000"; // Bxxxx-xxxx isf. Bxxx-xxxx
            var expectedErrorMessage = string.Format(ApiDict.NO["FormatError"],
                "BirkId", "type Bxxx-xxxx where x is a 0-9 digit");

            // Act
            var result = await _client.GetAsync($"/BarnByBirkId/{birkId}");

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);

            var jsonResult = await result.Content.ReadAsStringAsync();
            Assert.NotNull(jsonResult);

            var validationResult = JsonConvert.DeserializeObject<ValidationResultAsErrors>(jsonResult);
            var alphaValueErrors = validationResult?.Errors?.AlphaValue;
            Assert.True(alphaValueErrors.Any(e => e == expectedErrorMessage));
        }

        [Fact]
        public async Task GetBarnByBirkId_ReturnsNotFoundTest()
        {
            // Arrange
            var birkId = "B000-0000";

            // Act
            var result = await _client.GetAsync($"/BarnByBirkId/{birkId}");

            // Assert
            Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task GetBarnByFnr_ReturnsInvalidFormatErrorTest()
        {
            // Arrange
            var fnr = "111111111111"; // 12 digits isf. 11
            var expectedErrorMessage = string.Format(ApiDict.NO["FormatError"],
                "Fnr", "a 11 digits number");

            // Act
            var result = await _client.GetAsync($"/BarnByFnr/{fnr}");

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);

            var jsonResult = await result.Content.ReadAsStringAsync();
            Assert.NotNull(jsonResult);

            var validationResult = JsonConvert.DeserializeObject<ValidationResultAsErrors>(jsonResult);

            // Access the errors
            var alphaValueErrors = validationResult?.Errors?.AlphaValue;
            Assert.True(alphaValueErrors.Any(e => e == expectedErrorMessage));
        }

        [Fact]
        public async Task GetBarnByFnr_ReturnsNotFoundTest()
        {
            // Arrange
            var fnr = "00000000000";

            // Act
            var result = await _client.GetAsync($"/BarnByFnr/{fnr}");

            // Assert
            Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task GetPersonByFnr_ReturnsInvalidFormatErrorTest()
        {
            // Arrange
            var fnr = "111111111111"; // 12 digits isf. 11
            var expectedErrorMessage = string.Format(ApiDict.NO["FormatError"],
                "Fnr", "a 11 digits number");

            // Act
            var result = await _client.GetAsync($"/PersonByFnr/{fnr}");

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);

            var jsonResult = await result.Content.ReadAsStringAsync();
            Assert.NotNull(jsonResult);

            var validationResult = JsonConvert.DeserializeObject<ValidationResultAsErrors>(jsonResult);
            var alphaValueErrors = validationResult?.Errors?.AlphaValue;
            Assert.True(alphaValueErrors.Any(e => e == expectedErrorMessage));
        }

        [Fact]
        public async Task GetPersonByFnr_ReturnsNotFoundTest()
        {
            // Arrange
            var fnr = "00000000000";

            // Act
            var result = await _client.GetAsync($"/PersonByFnr/{fnr}");

            // Assert
            Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task GetBarnByFødtOgPersonnummer_ReturnsInvalidFormatErrorTest()
        {
            // Arrange
            var født = "01-01-01"; // Invalid date
            var personnummer = "1111c";

            // Act
            var result = await _client.GetAsync($"/PersonByFødtOgPersonnummer/{født}/{personnummer}");

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, result.StatusCode);

            var jsonResult = await result.Content.ReadAsStringAsync();
            Assert.NotNull(jsonResult);

            var validationResult = JsonConvert.DeserializeObject<ValidationResultAsErrors>(jsonResult);
            Assert.Equal(validationResult.Status, (int)HttpStatusCode.BadRequest);
        }

        [Fact]
        public async Task GetBarnByFødtOgPersonnummer_ReturnsNotFoundTest()
        {
            // Arrange
            var født = "01-01-00";
            var personnummer = "99999";

            // Act
            var result = await _client.GetAsync($"/PersonByFødtOgPersonnummer/{født}/{personnummer}");

            // Assert
            Assert.Equal(result.StatusCode, HttpStatusCode.NotFound);
        }

        [Fact]
        public async Task createBarn_ReturnsValidationErrorTest()
        {
            // Arrange
            var createBarnDto = new CreateBarnDto()
            {
                BarnetsSpråkFk = 1,
                BarnTypeFk = 1,
                EtnisitetTypeFk = 1,
                FolkeGruppeTypeFk = 1,
                HjemmespråkFk = 1,
                OpprinnelseslandTypeFk = 1,
                ReligionTypeFk = 1,
                TrosamfunnFk = 1,
                VerdensregionTypeFk = 1,
                VerdensdelTypeFk = 1,
                RegAv = "XCOMMON\\xjamoy",
                RegDato = DateTime.Now,
                
                // Person
                KjønnTypeFk = 1,
                SivilstandTypeFk = 1,
                Fornavn = "string",
                Etternavn = "string",
                Født = DateTime.Now,
                // Invalid Personnummer value
                Personnummer = "ccc",
                EndretAv = "string",
                EndretDato = DateTime.Now,
                UsikkerFødselsdato = true
            };
            var expectedErrorMessage = "Personnummer must be valid personnummer with format xxxxx where x is a 0-9 digit";

            // Act
            var barnRequest = new CreateBarnRequest() { CreateBarnDto = createBarnDto };
            var serializedRequest = JsonConvert.SerializeObject(barnRequest);
            var scRequest = new StringContent(serializedRequest, Encoding.UTF8, "application/json");
            var result = await _client.PostAsync("/Barn", scRequest);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(result.StatusCode, HttpStatusCode.BadRequest);

            var jsonResult = await result.Content.ReadAsStringAsync();
            Assert.NotNull(jsonResult);

            var validationResult = JsonConvert.DeserializeObject<ValidationResultAsErrors>(jsonResult);
            Assert.Equal(validationResult.Status, (int)HttpStatusCode.BadRequest);
        }
    }
}
